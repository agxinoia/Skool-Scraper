// =================================================================================
// LOOM HANDLER
// =================================================================================

export class LoomHandler {
  constructor(utils) {
    this.utils = utils;

    this.GRAPHQL_QUERIES = {
      GetVideoSSR: `
        query GetVideoSSR($videoId: ID!, $password: String) {
          getVideo(id: $videoId, password: $password) {
            __typename
            ... on PrivateVideo {
              id
              status
              message
              __typename
            }
            ... on VideoPasswordMissingOrIncorrect {
              id
              message
              __typename
            }
            ... on RegularUserVideo {
              id
              __typename
              createdAt
              description
              download_enabled
              folder_id
              is_protected
              needs_password
              owner {
                display_name
                __typename
              }
              privacy
              s3_id
              name
              video_properties {
                duration
                height
                width
              }
            }
          }
        }\n`,
    };

    this.APOLLO_VERSION = "0a1856c"; // Note: Check if this needs updating
  }

  async extractInfo(url, password = null) {
    const videoIdMatch = url.match(/\/(?:share|embed)\/([a-f0-9]{32})/);
    if (!videoIdMatch) return null;

    const videoId = videoIdMatch[1];
    const isEmbedUrl = url.includes("/embed/");

    console.log(`🆔 Video ID: ${videoId}`);
    console.log(`🔗 Is embed URL: ${isEmbedUrl}`);

    const [metadataResponse] = await this.callGraphqlApi(
      ["GetVideoSSR"],
      videoId,
      password
    );

    const metadata = metadataResponse.data.getVideo;

    if (metadata.__typename === "VideoPasswordMissingOrIncorrect") {
      throw new Error(
        "This Loom video is password-protected. Please provide the correct password."
      );
    }

    if (metadata.__typename === "PrivateVideo") {
      throw new Error(
        metadata.message || "This video is private and cannot be accessed."
      );
    }

    if (metadata.__typename !== "RegularUserVideo") {
      throw new Error(
        metadata.message || "Could not retrieve Loom video metadata."
      );
    }

    return {
      platform: "Loom",
      url: url,
      id: metadata.id,
      title: metadata.name,
      owner: metadata.owner.display_name,
      duration: metadata.video_properties.duration,
      width: metadata.video_properties.width,
      height: metadata.video_properties.height,
      description: metadata.description,
      isEmbed: isEmbedUrl,
      files: [],
    };
  }

  async callGraphqlApi(operations, videoId, password) {
    console.log("🔍 callLoomGraphqlApi called with:", {
      operations,
      videoId,
      password: password ? "***" : null,
    });

    const body = JSON.stringify(
      operations.map((operationName) => ({
        operationName,
        variables: {
          videoId,
          password,
        },
        query: this.GRAPHQL_QUERIES[operationName],
      }))
    );

    console.log("📤 GraphQL request body:", body);

    try {
      console.log("🌐 Making fetch request to Loom GraphQL...");
      const response = await fetch("https://www.loom.com/graphql", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          Referer: "https://www.loom.com/",
          Origin: "https://www.loom.com",
          "x-loom-request-source": `loom_web_${this.APOLLO_VERSION}`,
          "apollographql-client-name": "web",
          "apollographql-client-version": this.APOLLO_VERSION,
        },
        body,
      });

      console.log(
        "📥 GraphQL response status:",
        response.status,
        response.statusText
      );

      if (!response.ok) {
        throw new Error(
          `GraphQL request failed: ${response.status} ${response.statusText}`
        );
      }

      const jsonResponse = await response.json();
      console.log("✅ GraphQL response data:", jsonResponse);
      return jsonResponse;
    } catch (error) {
      console.error("❌ GraphQL request error:", error);
      throw error;
    }
  }

  async callUrlApi(endpoint, videoId, password) {
    console.log(`🔍 callLoomUrlApi called with:`, {
      endpoint,
      videoId,
      password: password ? "***" : null,
    });

    try {
      const requestBody = {
        anonID: this.utils.uuidv4(),
        deviceID: null,
        force_original: false,
        password: password,
      };

      console.log(`📤 ${endpoint} request body:`, requestBody);
      
      const requestUrl = `https://www.loom.com/api/campaigns/sessions/${videoId}/${endpoint}`;
      console.log(`🌐 Making request to: ${requestUrl}`);

      const response = await fetch(requestUrl, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          Referer: "https://www.loom.com/",
          Origin: "https://www.loom.com",
        },
        body: JSON.stringify(requestBody),
      });

      console.log(
        `📥 ${endpoint} response status:`,
        response.status,
        response.statusText
      );

      if (response.status === 204) {
        console.log(`✅ ${endpoint} returned no content, as expected.`);
        return null;
      }

      if (!response.ok) {
        const responseText = await response.text();
        console.error(`❌ ${endpoint} error response body:`, responseText);
        throw new Error(
          `${endpoint} request failed: ${response.status} ${response.statusText}`
        );
      }

      const json = await response.json();
      console.log(`✅ ${endpoint} response:`, json);
      
      if (!json.url) {
        console.warn(`⚠️ ${endpoint} response missing URL field:`, json);
        return null;
      }
      
      return json.url;
    } catch (error) {
      console.error(`❌ ${endpoint} request error:`, error);
      throw error;
    }
  }

  async downloadVideo(url, password) {
    console.log(`🎬 Starting LOOM download for: ${url}`);

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      downloadCancelled: false,
      activeDownloads: globalState.activeDownloads + 1,
    });

    // Remove duplicate counting for DASH downloads - they handle their own completion notifications
    
    try {
      const videoInfo = await this.extractInfo(url, password);
      if (!videoInfo) throw new Error("Could not extract Loom video metadata.");

      this.utils.sendProgressToPopup(15, "Getting download URLs...");

      console.log(`🔍 Getting download URLs for video ID: ${videoInfo.id}`);
      
      const rawUrl = await this.callUrlApi("raw-url", videoInfo.id, password);
      console.log(`🔗 Raw URL result: ${rawUrl}`);
      
      let transcodedUrl = null;

      try {
        transcodedUrl = await this.callUrlApi(
          "transcoded-url",
          videoInfo.id,
          password
        );
        console.log(`🔗 Transcoded URL result: ${transcodedUrl}`);
      } catch (error) {
        console.warn(
          "⚠️ transcoded-url failed, will use raw-url:",
          error.message
        );
      }

      let downloadUrl = rawUrl || transcodedUrl;
      if (!downloadUrl) {
        throw new Error("Could not retrieve download URL.");
      }

      console.log("🔗 Final Download URL:", downloadUrl);
      console.log("🔍 URL analysis:", {
        isM3U8: downloadUrl.includes(".m3u8"),
        isMPD: downloadUrl.includes(".mpd"),
        hasSplit: downloadUrl.includes("-split"),
        url: downloadUrl
      });

      const fileName = this.utils.sanitizeFileName(videoInfo.title) + ".mp4";

      if (downloadUrl.includes(".m3u8")) {
        await this.downloadHLS(downloadUrl, fileName, videoInfo.isEmbed, videoInfo);
      } else if (downloadUrl.includes(".mpd")) {
        await this.downloadDASH(downloadUrl, fileName, videoInfo.isEmbed, videoInfo);
      } else {
        await this.utils.downloadFile(downloadUrl, fileName);
      }

      // Don't send download complete here - let the actual Chrome download completion handle it
      console.log("📥 Loom processing completed, awaiting Chrome download completion");
    } catch (error) {
      console.error("❌ Loom download failed:", error);
      this.utils.sendDownloadError(`Loom Download Failed: ${error.message}`);
      throw error;
    } finally {
      const globalState = this.utils.getGlobalState();
      // Don't decrement activeDownloads here - DASH downloads handle this via DOWNLOAD_COMPLETE_NOTIFICATION
      // This prevents double-decrementing the counter
      // Don't close offscreen here - let the Chrome download completion handle it
      console.log(`📊 Loom handler finished, activeDownloads: ${globalState.activeDownloads}, keeping offscreen open for Chrome download`);
    }
  }

  async downloadHLS(hlsUrl, fileName, isEmbedUrl, videoInfo = null) {
    console.log("📺 HLS stream detected. Processing manifest...");

    // Handle -split.m3u8 URLs early to prevent 404 errors
    if (hlsUrl.includes("-split.m3u8")) {
      hlsUrl = hlsUrl.replace("-split.m3u8", ".m3u8");
      console.log("🔄 Updated Download URL:", hlsUrl);
    }

    console.log(`🌐 Fetching HLS manifest from: ${hlsUrl}`);
    const response = await fetch(hlsUrl);
    if (!response.ok) {
      console.error(`❌ HLS manifest fetch failed:`, {
        status: response.status,
        statusText: response.statusText,
        url: hlsUrl
      });
      throw new Error(`Failed to fetch HLS manifest: ${response.status} ${response.statusText}`);
    }

    const m3u8Content = await response.text();
    console.log("📋 M3U8 Manifest Content:", m3u8Content);

    const m3u8 = this.parseM3U8(m3u8Content);
    let audioSegments = [];
    let videoSegments = [];

    if (m3u8.isMasterPlaylist) {
      console.log("🎯 Master playlist detected.");
      const masterUrl = new URL(hlsUrl);
      const query = masterUrl.search;

      // Download audio segments first
      for (const audioTrack of m3u8.audioTracks) {
        const audioPlaylistUrl = new URL(audioTrack.uri, hlsUrl);
        audioPlaylistUrl.search = query;
        const audioPlaylistUrlHref = audioPlaylistUrl.href;

        console.log(`🎵 Fetching audio playlist from: ${audioPlaylistUrlHref}`);
        const audioPlaylistResponse = await fetch(audioPlaylistUrlHref);
        const audioPlaylistContent = await audioPlaylistResponse.text();

        const audioPlaylist = this.parseM3U8(audioPlaylistContent);
        if (audioPlaylist.segments && audioPlaylist.segments.length > 0) {
          console.log(
            `✅ Found ${audioPlaylist.segments.length} audio segments`
          );
          const base_url = audioPlaylistUrlHref.substring(
            0,
            audioPlaylistUrlHref.lastIndexOf("/") + 1
          );
          for (const segment of audioPlaylist.segments) {
            const segmentUrl = new URL(segment.uri, base_url);
            segmentUrl.search = query;
            audioSegments.push({ uri: segmentUrl.href });
          }
        }
      }

      // Download video segments - process ALL variants like the original code
      for (const variant of m3u8.variants) {
        const playlistUrl = new URL(variant.uri, hlsUrl);
        playlistUrl.search = query;
        const playlistUrlHref = playlistUrl.href;

        console.log(`📥 Fetching video playlist from: ${playlistUrlHref}`);
        const mediaPlaylistResponse = await fetch(playlistUrlHref);
        const mediaPlaylistContent = await mediaPlaylistResponse.text();

        const mediaPlaylist = this.parseM3U8(mediaPlaylistContent);
        if (mediaPlaylist.segments && mediaPlaylist.segments.length > 0) {
          console.log(
            `✅ Found ${mediaPlaylist.segments.length} video segments from variant ${variant.uri}`
          );
          const base_url = playlistUrlHref.substring(
            0,
            playlistUrlHref.lastIndexOf("/") + 1
          );
          for (const segment of mediaPlaylist.segments) {
            const segmentUrl = new URL(segment.uri, base_url);
            segmentUrl.search = query;
            videoSegments.push({ 
              uri: segmentUrl.href,
              duration: segment.duration || 0
            });
          }
          // Store the mediaPlaylist for duration calculation
          videoInfo._hlsPlaylist = mediaPlaylist;
          // Break after first variant to avoid duplicates
          // If you want highest quality, sort variants by bandwidth first
          break;
        }
      }
    } else {
      console.log("📋 Media playlist detected.");
      if (m3u8.segments && m3u8.segments.length > 0) {
        const playlistUrlObject = new URL(hlsUrl);
        const query = playlistUrlObject.search;
        const base_url = hlsUrl.substring(0, hlsUrl.lastIndexOf("/") + 1);

        for (const segment of m3u8.segments) {
          const segmentUrl = new URL(segment.uri, base_url);
          segmentUrl.search = query;
          videoSegments.push({ 
            uri: segmentUrl.href,
            duration: segment.duration || 0
          });
        }
        // Store the playlist for duration calculation
        videoInfo._hlsPlaylist = m3u8;
      }
    }

    console.log(`🔍 Debug: audio segments:`, audioSegments.length);
    console.log(`🔍 Debug: video segments:`, videoSegments.length);

    // Calculate and compare durations
    const apiDuration = videoInfo?.duration || 0;
    let hlsCalculatedDuration = 0;
    
    // Calculate duration from HLS segments
    if (videoSegments.length > 0) {
      hlsCalculatedDuration = videoSegments.reduce((total, segment) => {
        return total + (segment.duration || 0);
      }, 0);
    } else if (videoInfo._hlsPlaylist && videoInfo._hlsPlaylist.segments) {
      hlsCalculatedDuration = videoInfo._hlsPlaylist.segments.reduce((total, segment) => {
        return total + (segment.duration || 0);
      }, 0);
    }
    
    console.log("🕐 Duration Comparison:");
    console.log("   API Duration:", apiDuration, "seconds (" + Math.floor(apiDuration / 60) + ":" + (apiDuration % 60).toString().padStart(2, '0') + ")");
    console.log("   HLS Calculated Duration:", hlsCalculatedDuration.toFixed(2), "seconds (" + Math.floor(hlsCalculatedDuration / 60) + ":" + (hlsCalculatedDuration % 60).toFixed(0).padStart(2, '0') + ")");
    
    if (Math.abs(apiDuration - hlsCalculatedDuration) > 10) {
      console.warn("⚠️ Large duration discrepancy detected! API vs HLS differs by", Math.abs(apiDuration - hlsCalculatedDuration).toFixed(2), "seconds");
      console.warn("⚠️ Using HLS calculated duration as it's more accurate for actual segments");
      if (hlsCalculatedDuration > 0) {
        videoInfo.duration = hlsCalculatedDuration;
        console.log("✅ Updated videoInfo.duration to HLS calculated duration:", hlsCalculatedDuration);
      }
    }

    if (audioSegments.length === 0 && videoSegments.length === 0) {
      throw new Error("No segments found in HLS manifest.");
    }

    // Simplified routing logic - match your original working code
    if (audioSegments.length > 0 && videoSegments.length > 0) {
      console.log(
        `📦 Found ${audioSegments.length} audio + ${videoSegments.length} video HLS segments - processing as separate streams`
      );
      // DASH processing will handle completion via DOWNLOAD_COMPLETE_NOTIFICATION
      await this.downloadDASHSegments(
        audioSegments,
        videoSegments,
        fileName,
        isEmbedUrl,
        videoInfo,
        hlsUrl // Pass hlsUrl as sourceUrl
      );
    } else if (videoSegments.length > 0) {
      console.log(`📦 Found ${videoSegments.length} video-only segments`);
      await this.downloadHLSSegments(videoSegments, fileName, videoInfo);
    } else if (audioSegments.length > 0) {
      console.log(`📦 Found ${audioSegments.length} audio-only segments`);
      await this.downloadHLSSegments(
        audioSegments,
        fileName.replace(".mp4", "_audio.mp4"),
        videoInfo
      );
    }
  }

  async downloadDASH(dashUrl, fileName, isEmbedUrl, videoInfo = null) {
    console.log("📺 DASH stream detected. Processing manifest...");

    const response = await fetch(dashUrl);
    if (!response.ok) {
      throw new Error(`Failed to fetch DASH manifest: ${response.statusText}`);
    }

    const mpdContent = await response.text();
    console.log("📋 MPD Manifest Content:", mpdContent);

    const manifest = this.parseXML(mpdContent);
    console.log("✅ Parsed MPD object:", manifest);

    const periods = manifest.MPD.Period;
    const masterUrl = new URL(dashUrl);
    const query = masterUrl.search;
    const base_url = dashUrl.substring(0, dashUrl.lastIndexOf("/") + 1);

    const audioAdaptationSet = periods[0].AdaptationSet.find(
      (aset) => aset && aset.getAttribute("contentType") === "audio"
    );
    const videoAdaptationSet = periods[0].AdaptationSet.find(
      (aset) => aset && aset.getAttribute("contentType") === "video"
    );

    if (!videoAdaptationSet || !videoAdaptationSet.representations.length) {
      throw new Error(
        "Could not find video adaptation set or representations in DASH manifest"
      );
    }

    const videoRepresentation = videoAdaptationSet.representations[0];
    const audioRepresentation =
      audioAdaptationSet && audioAdaptationSet.representations?.[0];

    const audioSegments = [];
    const videoSegments = [];

    console.log("🔍 Extracting DASH segments from representations...");

    if (audioRepresentation) {
      audioSegments.push(
        ...this.extractSegments(audioRepresentation, base_url, query, 'audio')
      );
      console.log(`🎵 Found ${audioSegments.length} audio segments`);
    }

    if (videoRepresentation) {
      videoSegments.push(
        ...this.extractSegments(videoRepresentation, base_url, query, 'video')
      );
      console.log(`🎬 Found ${videoSegments.length} video segments`);
    }

    if (videoSegments.length > 0) {
      console.log(
        `📦 Processing ${audioSegments.length} audio + ${videoSegments.length} video DASH segments`
      );
      // DASH processing will handle completion via DOWNLOAD_COMPLETE_NOTIFICATION
      await this.downloadDASHSegments(
        audioSegments,
        videoSegments,
        fileName,
        isEmbedUrl,
        videoInfo,
        mpdContent,
        dashUrl // Pass dashUrl as sourceUrl for DASH
      );
    } else {
      console.error(
        "❌ No DASH segments found, falling back to direct download..."
      );
      await this.utils.downloadFile(dashUrl, fileName);
    }
  }

  // Helper function to extract segments
  extractSegments(representation, baseUrl, query, contentType = 'unknown') {
    const segments = [];
    if (!representation || !representation.innerHTML) return segments;

    const segmentTemplateRegex =
      /<SegmentTemplate[^>]*initialization="([^"]+)"[^>]*media="([^"]+)"(?:[^>]*startNumber="(\d+)")?/;
    const templateMatch = segmentTemplateRegex.exec(representation.innerHTML);

    if (templateMatch) {
      const initialization = templateMatch[1];
      const media = templateMatch[2];
      const startNumber = templateMatch[3] ? parseInt(templateMatch[3], 10) : 1;

      const initUrl = new URL(initialization, baseUrl);
      initUrl.search = query;
      // Add initialization segment with special marker to distinguish it from media segments
      segments.push({ 
        uri: initUrl.href, 
        isInitSegment: true, 
        segmentType: contentType, // Use the passed contentType
        segmentIndex: -1  // Use -1 to mark as init segment
      });

      const segmentTimelineRegex =
        /<SegmentTimeline[^>]*>(.*?)<\/SegmentTimeline>/s;
      const timelineMatch =
        representation.innerHTML.match(segmentTimelineRegex);

      if (timelineMatch) {
        const timelineContent = timelineMatch[1];
        const sTagRegex = /<S\s*([^>]*?)(?:\s*\/>|>[^<]*<\/S>)/g;
        const sTagMatches = [...timelineContent.matchAll(sTagRegex)];

        let segmentIndex = startNumber;
        for (const sMatch of sTagMatches) {
          const attrs = sMatch[1] || "";
          const rMatch = attrs.match(/r="(\d+)"/);
          const repeatCount = rMatch ? parseInt(rMatch[1], 10) : 0;

          let segmentUrl = new URL(
            media.replace(/\$Number\$/, segmentIndex),
            baseUrl
          );
          segmentUrl.search = query;
          segments.push({ 
            uri: segmentUrl.href,
            isInitSegment: false,
            segmentType: contentType, // Use the passed contentType
            segmentIndex: segmentIndex - startNumber  // Make this 0-based for media segments
          });
          segmentIndex++;

          for (let i = 0; i < repeatCount; i++) {
            segmentUrl = new URL(
              media.replace(/\$Number\$/, segmentIndex),
              baseUrl
            );
            segmentUrl.search = query;
            segments.push({ 
              uri: segmentUrl.href,
              isInitSegment: false,
              segmentType: contentType, // Use the passed contentType
              segmentIndex: segmentIndex - startNumber  // Make this 0-based for media segments
            });
            segmentIndex++;
          }
        }
      }
    } else {
      const segmentRegex = /<SegmentURL[^>]*media="([^"]+)"/g;
      let match;
      while ((match = segmentRegex.exec(representation.innerHTML)) !== null) {
        const segmentUrl = new URL(match[1], baseUrl);
        segmentUrl.search = query;
        segments.push({ uri: segmentUrl.href });
      }
    }

    return segments;
  }

  parseM3U8(content) {
    console.log("🔍 Parsing M3U8 content:", content.substring(0, 200) + "...");

    const lines = content
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line);

    const result = {
      isMasterPlaylist: false,
      variants: [],
      segments: [],
      audioTracks: [],
      initializationSegment: null,
    };

    if (content.includes("#EXT-X-STREAM-INF")) {
      result.isMasterPlaylist = true;
      console.log("📋 Detected master playlist");

      // Parse audio tracks
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith("#EXT-X-MEDIA:TYPE=AUDIO")) {
          const line = lines[i];
          const uriMatch = line.match(/URI="([^"]+)"/);
          if (uriMatch) {
            result.audioTracks.push({ uri: uriMatch[1] });
            console.log("🎵 Found audio track:", uriMatch[1]);
          }
        }
      }

      // Parse video variants with bandwidth information
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith("#EXT-X-STREAM-INF")) {
          const streamInfoLine = lines[i];
          const nextLine = lines[i + 1];

          if (nextLine && !nextLine.startsWith("#")) {
            // Extract bandwidth for quality sorting
            const bandwidthMatch = streamInfoLine.match(/BANDWIDTH=(\d+)/);
            const bandwidth = bandwidthMatch
              ? parseInt(bandwidthMatch[1], 10)
              : 0;

            result.variants.push({
              uri: nextLine,
              bandwidth: bandwidth,
            });
          }
        }
      }

      // Sort variants by bandwidth (highest first) for quality selection
      result.variants.sort((a, b) => b.bandwidth - a.bandwidth);
      console.log(
        `📊 Found ${result.variants.length} video variants, sorted by quality`
      );
    } else {
      console.log("📋 Detected media playlist");
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith("#EXT-X-MAP:URI=")) {
          const mapMatch = lines[i].match(/URI="([^"]+)"/);
          if (mapMatch) {
            result.initializationSegment = mapMatch[1];
            console.log(
              "🔧 Found initialization segment:",
              result.initializationSegment
            );
          }
        } else if (lines[i].startsWith("#EXTINF")) {
          const extinfMatch = lines[i].match(/#EXTINF:([0-9.]+),?(.*)?/);
          const nextLine = lines[i + 1];
          if (extinfMatch && nextLine && !nextLine.startsWith("#")) {
            const segmentDuration = parseFloat(extinfMatch[1]);
            result.segments.push({ 
              uri: nextLine,
              duration: segmentDuration
            });
          }
        }
      }
    }

    // Calculate total duration from HLS segments
    let hlsTotalDuration = 0;
    if (result.segments.length > 0) {
      hlsTotalDuration = result.segments.reduce((total, segment) => {
        return total + (segment.duration || 0);
      }, 0);
      console.log("🕐 HLS Total Duration from segments:", hlsTotalDuration.toFixed(2), "seconds");
      console.log("🕐 HLS Duration (formatted):", Math.floor(hlsTotalDuration / 60) + ":" + (hlsTotalDuration % 60).toFixed(0).padStart(2, '0'));
    }

    console.log("✅ Parsed M3U8:", {
      isMasterPlaylist: result.isMasterPlaylist,
      variantCount: result.variants.length,
      segmentCount: result.segments.length,
      audioTrackCount: result.audioTracks.length,
      hasInitializationSegment: !!result.initializationSegment,
      hlsTotalDuration: hlsTotalDuration,
    });

    return result;
  }

  parseXML(xmlString) {
    console.log("🔍 Parsing XML content:", xmlString.substring(0, 200) + "...");

    const adaptationSetRegex =
      /<AdaptationSet[^>]*?contentType="(audio|video)"[^>]*?>(.*?)<\/AdaptationSet>/gs;
    const matches = [...xmlString.matchAll(adaptationSetRegex)];

    const adaptationSets = matches.map((match) => {
      const contentType = match[1];
      const content = match[2];

      const representationRegex =
        /<Representation[^>]*?bandwidth="(\d+)"[^>]*?>(.*?)<\/Representation>/gs;
      const repMatches = [...content.matchAll(representationRegex)];

      const representations = repMatches.map((repMatch) => ({
        bandwidth: parseInt(repMatch[1], 10),
        innerHTML: repMatch[2],
      }));

      representations.sort((a, b) => b.bandwidth - a.bandwidth);

      return {
        getAttribute: (attr) => (attr === "contentType" ? contentType : null),
        representations: representations,
      };
    });

    const audioAdaptationSet = adaptationSets.find(
      (s) => s.getAttribute("contentType") === "audio"
    );
    const videoAdaptationSet = adaptationSets.find(
      (s) => s.getAttribute("contentType") === "video"
    );

    console.log(
      "✅ Parsed XML - Audio sets:",
      !!audioAdaptationSet,
      "Video sets:",
      !!videoAdaptationSet
    );

    return {
      MPD: {
        Period: [
          {
            AdaptationSet: [audioAdaptationSet, videoAdaptationSet].filter(
              Boolean
            ),
          },
        ],
      },
    };
  }

  // Full DASH segment downloading implementation with FastStream offscreen processing
  async downloadDASHSegments(
    audioSegments,
    videoSegments,
    fileName,
    isEmbedUrl = false,
    videoInfo = null,
    mpdContent = null,
    sourceUrl = null
  ) {
    console.log(
      `🔽 Downloading DASH segments using FastStream approach - Audio: ${audioSegments.length}, Video: ${videoSegments.length}`
    );

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      downloadCancelled: false,
      // Don't increment activeDownloads here - already incremented by main download function
    });

    try {
      // Combine all segments for download with proper type identification
      // IMPORTANT: Video segments MUST come first, then audio segments
      // because offscreen script expects indices 0 to videoCount-1 to be video
      const allSegments = [];

      // Add video segments FIRST with type identifier and init segment detection
      videoSegments.forEach((segment, index) => {
        allSegments.push({
          ...segment,
          segmentType: "video",
          segmentIndex: index,
          originalIndex: index, // Keep track of original position
          isInitSegment: index === 0, // First video segment is the init segment
        });
      });

      // Add audio segments AFTER video segments
      audioSegments.forEach((segment, index) => {
        allSegments.push({
          ...segment,
          segmentType: "audio",
          segmentIndex: index,
          originalIndex: index, // Keep track of original position
          isInitSegment: index === 0, // First audio segment is the init segment
        });
      });

      console.log(`📦 Total segments to download: ${allSegments.length}`);

      if (allSegments.length === 0) {
        throw new Error("No segments to download");
      }

      this.utils.sendProgressToPopup(5, "Preparing segment processor...");
      await this.utils.createOffscreenDocument();

      const requestId = this.utils.uuidv4();
      const segmentsKey = `loom_dash_segments_${requestId}`;

      // Download segments in batches and store in IndexedDB
      await this.downloadSegmentBatches(allSegments, segmentsKey);

      const currentGlobalState = this.utils.getGlobalState();
      if (currentGlobalState.downloadCancelled) {
        console.log("⏹️ Download cancelled, aborting processing");
        return;
      }

      this.utils.sendProgressToPopup(85, "Processing DASH segments...");

      // Send to offscreen for processing with corrected parameters
      const response = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          chrome.runtime.onMessage.removeListener(responseListener);
          reject(new Error("Offscreen processing timeout"));
        }, 300000);

        const responseListener = (message) => {
          if (
            message.type === "MERGE_SEGMENTS_RESPONSE" &&
            message.requestId === requestId
          ) {
            clearTimeout(timeout);
            chrome.runtime.onMessage.removeListener(responseListener);
            if (message.success) {
              resolve(message);
            } else {
              reject(
                new Error(
                  message.error?.message || "Offscreen processing failed"
                )
              );
            }
          }
        };

        chrome.runtime.onMessage.addListener(responseListener);

        console.log("🎬 Sending DASH segments to FastStream with duration:", videoInfo?.duration);
        chrome.runtime.sendMessage({
          type: "MERGE_SEPARATE_AV_FASTSTREAM",
          requestId,
          segmentsKey,
          fileName,
          totalSegments: allSegments.length,
          videoCount: videoSegments.length,
          audioCount: audioSegments.length,
          isDashStream: sourceUrl && sourceUrl.includes(".mpd"), // Proper DASH detection based on source URL
          isEmbedSplit: isEmbedUrl,
          videoInfo: videoInfo,
          totalDuration: videoInfo?.duration,
          mpdContent: mpdContent, // Pass MPD content for DASH processing
          sourceUrl: sourceUrl, // Add source URL like working Vimeo handler does
        });
      });

      if (response && response.success) {
        console.log("✅ Offscreen DASH processing completed");
        // Send completion notification to properly decrement active downloads
        chrome.runtime.sendMessage({
          type: "DOWNLOAD_COMPLETE_NOTIFICATION",
          fileName: fileName,
        });
      } else {
        throw new Error("Offscreen DASH processing failed");
      }
    } catch (error) {
      console.error("❌ DASH segments download failed:", error);
      this.utils.sendDownloadError(`DASH Download Failed: ${error.message}`);
      throw error;
    } finally {
      // Don't decrement activeDownloads here - handled by main download function and DOWNLOAD_COMPLETE_NOTIFICATION
      const currentGlobalState = this.utils.getGlobalState();
      // Don't close offscreen here - let the Chrome download completion handle it
      console.log(`📊 Loom HLS handler finished, activeDownloads: ${currentGlobalState.activeDownloads}, keeping offscreen open for Chrome download`);
    }
  }

  async downloadSegmentBatches(segments, segmentsKey) {
    const batchSize = 5;
    let completedSegments = 0;

    for (let i = 0; i < segments.length; i += batchSize) {
      const currentGlobalState = this.utils.getGlobalState();
      if (currentGlobalState.downloadCancelled) {
        console.log("⏹️ Segment download cancelled by user");
        return;
      }

      const batch = segments.slice(i, i + batchSize);
      console.log(
        `📦 Downloading DASH batch ${Math.floor(i / batchSize) + 1}/${Math.ceil(
          segments.length / batchSize
        )} (${batch.length} segments)`
      );

      const batchPromises = batch.map(async (segment, batchIndex) => {
        const segmentNumber = i + batchIndex;

        try {
          const response = await fetch(segment.uri);
          if (!response.ok) {
            throw new Error(
              `Segment ${segmentNumber + 1} download failed: ${response.status}`
            );
          }

          const arrayBuffer = await response.arrayBuffer();
          console.log(
            `✅ ${segment.segmentType} segment ${segmentNumber + 1}/${
              segments.length
            } downloaded (${arrayBuffer.byteLength} bytes)`
          );

          // FIXED: Store metadata wrapper that preserves isInitSegment while providing direct ArrayBuffer access
          const segmentKey = `${segmentsKey}_${segmentNumber}`;
          
          // Create wrapper that allows both direct .data access and preserves metadata
          const segmentWrapper = {
            data: arrayBuffer,  // Direct ArrayBuffer access for FastStream
            isInitSegment: segment.isInitSegment || false,
            segmentType: segment.segmentType,
            segmentIndex: segment.segmentIndex || 0
          };
          
          await this.utils.set(segmentKey, segmentWrapper);

          return true;
        } catch (error) {
          console.error(`❌ Segment ${segmentNumber + 1} failed:`, error);
          throw error;
        }
      });

      await Promise.all(batchPromises);

      completedSegments += batch.length;
      const progress = 20 + (completedSegments / segments.length) * 60;
      this.utils.sendProgressToPopup(
        Math.min(progress, 80),
        `Downloaded ${completedSegments}/${segments.length} DASH segments`
      );

      // Garbage collection
      if (i % (batchSize * 4) === 0 && typeof globalThis.gc === "function") {
        console.log("🗑️ Running garbage collection");
        globalThis.gc();
      }
    }

    console.log(
      `✅ All ${segments.length} DASH segments downloaded and stored`
    );
  }

  // Full HLS segment downloading implementation
  async downloadHLSSegments(segments, fileName, videoInfo = null) {
    console.log(`🔽 Downloading ${segments.length} HLS segments`);
    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      activeDownloads: globalState.activeDownloads + 1,
    });
    console.log(`📊 Active downloads: ${globalState.activeDownloads + 1}`);

    // Create a unique ID for this HLS download to track it
    const hlsDownloadId = `hls_${Date.now()}_${Math.random()
      .toString(36)
      .substr(2, 9)}`;
    this.utils.addActiveDownloadId(hlsDownloadId);
    console.log(`📦 HLS download ID: ${hlsDownloadId}`);

    this.utils.sendProgressToPopup(30, "Downloading video segments...");

    // Check for cancellation
    if (this.utils.getGlobalState().downloadCancelled) {
      console.log("❌ Download cancelled during HLS segment preparation");
      const globalState = this.utils.getGlobalState();
      this.utils.setGlobalState({
        activeDownloads: globalState.activeDownloads - 1,
      });
      throw new Error("Download cancelled");
    }

    try {
      console.log(
        "📦 HLS video detected - downloading segments directly to offscreen document for processing"
      );

      this.utils.sendProgressToPopup(
        0,
        `Starting to download ${segments.length} video segments...`
      );

      this.utils.sendProgressToPopup(5, "Preparing segment processor...");
      await this.utils.createOffscreenDocument();

      const BATCH_SIZE = 10;
      const MAX_CONCURRENT_BATCHES = 1;
      const BATCH_DELAY_MS = 1;

      const requestId = this.utils.uuidv4();
      const segmentsKey = `segments_${requestId}`;

      const abortController = new AbortController();

      this.utils.sendProgressToPopup(10, "Starting segment downloads...");

      const batches = [];
      for (let i = 0; i < segments.length; i += BATCH_SIZE) {
        batches.push({
          startIndex: i,
          segments: segments.slice(i, i + BATCH_SIZE),
        });
      }

      console.log(
        `📦 Processing ${batches.length} batches of ~${BATCH_SIZE} segments each with ${MAX_CONCURRENT_BATCHES} concurrent batches (${BATCH_DELAY_MS}ms delay between batches)`
      );

      let completedSegments = 0;
      const progressLock = { current: 0 };

      const processBatch = async (batch) => {
        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        const { startIndex, segments: batchSegments } = batch;

        const segmentPromises = batchSegments.map(async (segment, index) => {
          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          const segmentNumber = startIndex + index;

          const downloadSegmentWithRetry = async () => {
            const maxRetries = 5;
            const baseRetryDelay = 1000;
            const startTime = Date.now();
            const maxDuration = 60000;

            for (let attempt = 1; attempt <= maxRetries; attempt++) {
              if (Date.now() - startTime > maxDuration) {
                throw new Error(
                  `Segment ${
                    segmentNumber + 1
                  } download timed out after 60 seconds`
                );
              }

              if (this.utils.getGlobalState().downloadCancelled) {
                console.log("🚫 Aborting all segment downloads");
                abortController.abort();
                throw new Error("Download cancelled by user");
              }

              try {
                const response = await fetch(segment.uri, {
                  signal: abortController.signal,
                });

                if (this.utils.getGlobalState().downloadCancelled) {
                  console.log("🚫 Aborting all segment downloads");
                  abortController.abort();
                  throw new Error("Download cancelled by user");
                }

                if (!response.ok) {
                  throw new Error(`HTTP ${response.status}`);
                }

                return response;
              } catch (error) {
                console.log(
                  `⚠️ Segment ${
                    segmentNumber + 1
                  } download attempt ${attempt}/${maxRetries} failed:`,
                  error.message
                );

                if (
                  this.utils.getGlobalState().downloadCancelled ||
                  error.message === "Download cancelled by user" ||
                  (error.name === "AbortError" &&
                    abortController.signal.aborted)
                ) {
                  console.log("🚫 User cancelled download - not retrying");
                  throw error;
                }

                if (Date.now() - startTime > maxDuration) {
                  throw new Error(
                    `Segment ${
                      segmentNumber + 1
                    } download timed out after 60 seconds`
                  );
                }

                if (attempt === maxRetries) {
                  throw new Error(
                    `Segment ${
                      segmentNumber + 1
                    } download failed after ${maxRetries} attempts: ${
                      error.message
                    }`
                  );
                }

                let waitTime = baseRetryDelay * Math.pow(2, attempt - 1);

                if (
                  error.message.includes("429") ||
                  error.message.includes("Too Many Requests")
                ) {
                  waitTime = Math.min(15000, waitTime);
                  console.log(
                    `⏱️ Rate limit detected, waiting ${waitTime}ms before retry...`
                  );
                } else if (
                  error.name === "AbortError" ||
                  error.message.includes("network") ||
                  error.message.includes("timeout") ||
                  error.message.includes("connection")
                ) {
                  const jitter = Math.random() * 0.3;
                  waitTime = Math.min(10000, waitTime * (1 + jitter));
                  console.log(
                    `🔄 Network error detected, waiting ${Math.round(
                      waitTime
                    )}ms before retry...`
                  );
                } else {
                  waitTime = Math.min(8000, waitTime);
                  console.log(`⏳ Retrying in ${waitTime}ms...`);
                }

                await new Promise((resolve) => setTimeout(resolve, waitTime));
              }
            }
          };

          const response = await downloadSegmentWithRetry();

          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          return {
            key: `${segmentsKey}_${segmentNumber}`,
            data: await response.arrayBuffer(),
          };
        });

        const batchData = await Promise.all(segmentPromises);

        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        await Promise.all(
          batchData.map((item) => this.utils.set(item.key, item.data))
        );

        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        completedSegments += batchSegments.length;
        const progressPercent = (completedSegments / segments.length) * 85;
        const currentBatch = Math.ceil(completedSegments / BATCH_SIZE);
        const totalBatches = batches.length;

        progressLock.current = progressPercent;
        this.utils.sendProgressToPopup(
          progressPercent,
          `Downloaded batch ${currentBatch}/${totalBatches} - ${completedSegments}/${segments.length} segments`
        );

        console.log(
          `✅ Batch ${currentBatch}/${totalBatches} completed: ${batchSegments.length} segments (${completedSegments}/${segments.length} total)`
        );
      };

      let batchIndex = 0;
      const processNextBatch = async () => {
        while (
          batchIndex < batches.length &&
          !this.utils.getGlobalState().downloadCancelled
        ) {
          const currentBatchIndex = batchIndex++;
          if (currentBatchIndex >= batches.length) break;

          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("❌ Download cancelled by user");
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          console.log(
            `🔄 Processing batch ${currentBatchIndex + 1}/${batches.length}...`
          );
          await processBatch(batches[currentBatchIndex]);

          if (
            currentBatchIndex < batches.length - 1 &&
            !this.utils.getGlobalState().downloadCancelled
          ) {
            console.log(`⏳ Waiting ${BATCH_DELAY_MS}ms before next batch...`);
            await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY_MS));
          }
        }
      };

      const concurrentProcessors = Array.from(
        { length: MAX_CONCURRENT_BATCHES },
        () => processNextBatch()
      );
      await Promise.all(concurrentProcessors);

      console.log(
        `✅ All ${segments.length} segments downloaded and stored in IndexedDB`
      );

      if (this.utils.getGlobalState().downloadCancelled) {
        console.log("❌ Download cancelled before merging phase");
        throw new Error("Download cancelled by user");
      }

      this.utils.sendProgressToPopup(88, "Merging video segments...");

      const response = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          chrome.runtime.onMessage.removeListener(responseListener);
          clearInterval(cancelCheck);
          reject(new Error("Offscreen processing timeout"));
        }, 300000);

        const cancelCheck = setInterval(() => {
          if (this.utils.getGlobalState().downloadCancelled) {
            clearTimeout(timeout);
            clearInterval(cancelCheck);
            chrome.runtime.onMessage.removeListener(responseListener);
            reject(new Error("Download cancelled by user"));
          }
        }, 500);

        const responseListener = (message) => {
          if (
            message.type === "MERGE_SEGMENTS_RESPONSE" &&
            message.requestId === requestId
          ) {
            clearTimeout(timeout);
            clearInterval(cancelCheck);
            chrome.runtime.onMessage.removeListener(responseListener);
            if (message.success) {
              resolve(message);
            } else {
              reject(
                new Error(
                  message.error?.message || "Offscreen processing failed"
                )
              );
            }
          }
        };

        chrome.runtime.onMessage.addListener(responseListener);

        console.log("🎬 Sending HLS segments to FastStream with duration:", videoInfo?.duration);
        chrome.runtime.sendMessage({
          type: "MERGE_SEGMENTS_FASTSTREAM",
          requestId,
          segmentsKey,
          fileName,
          totalSegments: segments.length,
          videoInfo: videoInfo,
          totalDuration: videoInfo?.duration,
        });
      });

      if (response && response.success) {
        console.log("✅ Offscreen processing completed");
        const { downloadInitiated, results } = response;

        if (!downloadInitiated) {
          console.error("❌ Download was not initiated by offscreen document");
          throw new Error("Download failed to initiate");
        }

        console.log("✅ Download initiated by background script");

        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} completed successfully, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
        // Don't send download complete here - let the actual Chrome download completion handle it
        console.log(`📥 Loom HLS processing completed, awaiting Chrome download completion for: ${fileName}`);
      } else {
        throw new Error("Offscreen processing failed");
      }

      console.log(`✅ Merged HLS download completed: ${fileName}`);
    } catch (error) {
      console.error("❌ HLS segment download failed:", error);

      if (
        error.message === "Download cancelled by user" ||
        error.name === "AbortError"
      ) {
        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} cancelled, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
        console.log(
          "🔄 Keeping downloadCancelled flag true to prevent fallback approaches"
        );
        this.utils.sendDownloadError("Download cancelled by user");
      } else {
        this.utils.sendDownloadError(`HLS download failed: ${error.message}`);
      }

      throw error;
    } finally {
      if (
        this.utils.getGlobalState().activeDownloadIds.has &&
        this.utils.getGlobalState().activeDownloadIds.has(hlsDownloadId)
      ) {
        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} cleanup in finally, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
      }
    }
  }

  async findEmbed(request, sender, sendResponse) {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      if (!tab || !tab.id) {
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No active tab found",
          });
        }
        return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const iframe = document.querySelector(
            'iframe[src*="loom.com/embed"], iframe[src*="loom.com/share"]'
          );
          if (iframe) {
            const src = iframe.src;
            const videoIdMatch = src.match(/(?:embed|share)\/([a-f0-9]{32})/);
            const videoId = videoIdMatch ? videoIdMatch[1] : null;

            let thumbnail = null;

            if (videoId) {
              console.log(
                "🔍 Searching for Loom thumbnail in scripts for video ID:",
                videoId
              );

              const scripts = document.querySelectorAll("script");
              for (const script of scripts) {
                const content = script.textContent || script.innerHTML;
                if (content) {
                  const thumbnailRegex =
                    /https?:\/\/[^"'\s]*loom[^"'\s]*thumbnail[^"'\s]*\.(gif|jpg|jpeg|png|webp)/gi;
                  const thumbnailMatches = content.match(thumbnailRegex);
                  if (thumbnailMatches && thumbnailMatches.length > 0) {
                    const matchWithVideoId = thumbnailMatches.find((url) =>
                      url.includes(videoId)
                    );
                    thumbnail = matchWithVideoId || thumbnailMatches[0];
                    console.log(
                      "✅ Found Loom thumbnail in script:",
                      thumbnail
                    );
                    break;
                  }

                  const cdnRegex =
                    /https?:\/\/cdn\.loom\.com\/[^"'\s]+\.(gif|jpg|jpeg|png|webp)/gi;
                  const cdnMatches = content.match(cdnRegex);
                  if (cdnMatches && cdnMatches.length > 0) {
                    const matchWithVideoId = cdnMatches.find((url) =>
                      url.includes(videoId)
                    );
                    thumbnail = matchWithVideoId || cdnMatches[0];
                    console.log(
                      "✅ Found Loom CDN image in script:",
                      thumbnail
                    );
                    break;
                  }

                  if (
                    content.includes(videoId) &&
                    content.includes("loom.com")
                  ) {
                    const imageRegex =
                      /https?:\/\/[^"'\s]*\.(gif|jpg|jpeg|png|webp)/gi;
                    const imageMatches = content.match(imageRegex);
                    if (imageMatches) {
                      const loomImage = imageMatches.find((url) =>
                        url.includes("loom.com")
                      );
                      if (loomImage) {
                        thumbnail = loomImage;
                        console.log(
                          "✅ Found Loom image URL in script with video ID:",
                          thumbnail
                        );
                        break;
                      }
                    }
                  }
                }
              }

              if (!thumbnail) {
                const allImages = document.querySelectorAll("img");
                for (const img of allImages) {
                  if (
                    img.src &&
                    img.src.includes("loom.com") &&
                    img.src.includes(videoId)
                  ) {
                    thumbnail = img.src;
                    console.log(
                      "✅ Found Loom thumbnail in DOM fallback:",
                      thumbnail
                    );
                    break;
                  }
                }
              }
            }

            return {
              iframeSrc: src,
              videoId: videoId,
              pageUrl: window.location.href,
              pageTitle: document.title,
              thumbnail: thumbnail,
            };
          }

          // Look for video elements with poster attribute
          const videos = document.querySelectorAll("video[poster]");
          for (const video of videos) {
            const poster = video.poster;
            const src = video.src || "";

            if (poster.includes("loom.com") || src.includes("loom.com")) {
              const videoIdMatch = (poster + src).match(/([a-f0-9]{32})/);

              return {
                videoId: videoIdMatch ? videoIdMatch[1] : null,
                pageUrl: window.location.href,
                pageTitle: document.title,
                elementType: "video",
                element: video.className || video.id || "video-element",
                thumbnail: poster,
              };
            }
          }

          const videoElement = document.querySelector(
            "video[data-loom-video-id]"
          );
          if (videoElement) {
            const videoId = videoElement.getAttribute("data-loom-video-id");
            return {
              videoId: videoId,
              pageUrl: window.location.href,
              pageTitle: document.title,
              elementType: "video",
              element:
                videoElement.id || videoElement.className || "video-element",
              thumbnail: videoElement.poster || null,
            };
          }

          const loomVideos = document.querySelectorAll("video");
          for (const video of loomVideos) {
            const src = video.src || video.getAttribute("data-src") || "";
            const poster = video.poster || "";

            if (
              src.includes("loom.com") ||
              poster.includes("loom.com") ||
              video.className.includes("Loom") ||
              video.id.includes("Loom")
            ) {
              let videoId = null;

              let videoIdMatch = src.match(/([a-f0-9]{32})/);
              if (videoIdMatch) {
                videoId = videoIdMatch[1];
              } else {
                videoIdMatch = poster.match(/([a-f0-9]{32})/);
                if (videoIdMatch) {
                  videoId = videoIdMatch[1];
                } else {
                  videoIdMatch = window.location.href.match(/([a-f0-9]{32})/);
                  if (videoIdMatch) {
                    videoId = videoIdMatch[1];
                  }
                }
              }

              let thumbnail = poster;

              if (
                !thumbnail ||
                thumbnail.includes("data:image/gif;base64") ||
                thumbnail.length < 50
              ) {
                const thumbnailSelectors = [
                  'meta[property="og:image"]',
                  'meta[name="twitter:image"]',
                  'img[src*="thumbnails"]',
                  'img[src*="' + videoId + '"]',
                ];

                for (const selector of thumbnailSelectors) {
                  const element = document.querySelector(selector);
                  if (element && (element.content || element.src)) {
                    const foundThumbnail = element.content || element.src;
                    if (
                      foundThumbnail &&
                      !foundThumbnail.includes("data:image/gif;base64")
                    ) {
                      thumbnail = foundThumbnail;
                      console.log(
                        "🖼️ Found better thumbnail via",
                        selector + ":",
                        thumbnail
                      );
                      break;
                    }
                  }
                }
              }

              return {
                videoId: videoId,
                pageUrl: window.location.href,
                pageTitle: document.title,
                elementType: "video",
                element: video.id || video.className || "loom-video-element",
                thumbnail: thumbnail || null,
              };
            }
          }

          return null;
        },
      });

      if (results && results[0] && results[0].result) {
        const embedInfo = results[0].result;
        let videoUrl;
        if (embedInfo.iframeSrc) {
          videoUrl = `https://www.loom.com/share/${embedInfo.videoId}`;
        } else if (embedInfo.videoId) {
          videoUrl = `https://www.loom.com/share/${embedInfo.videoId}`;
        }

        console.log("✅ Sending success response for findLoomEmbed");
        if (sendResponse) {
          sendResponse({
            success: true,
            embedInfo: embedInfo,
            videoUrl: videoUrl,
          });
        }
      } else {
        console.log("❌ No embed found, sending failure response");
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No Loom embed found on this page.",
          });
        }
      }
    } catch (error) {
      console.error("❌ Error in findLoomEmbed promise:", error);
      if (sendResponse) {
        sendResponse({
          success: false,
          error: error.message || "Unknown error occurred",
        });
      }
    }
  }

  extractVideoInfo(request, sender, sendResponse) {

    const videoIdMatch = request.url.match(/\/(?:share|embed)\/([a-f0-9]{32})/);
    if (!videoIdMatch) {
      console.error("❌ Could not extract video ID from URL:", request.url);
      if (sendResponse) {
        sendResponse({
          success: false,
          error: "Could not extract video ID from URL.",
        });
      }
      return;
    }

    const videoId = videoIdMatch[1];
    console.log("✅ Extracted video ID:", videoId);

    this.callGraphqlApi(["GetVideoSSR"], videoId, request.password)
      .then((response) => {
        console.log("📋 Processing GraphQL response for extractVideoInfo");
        console.log(
          "🔍 Full GraphQL response:",
          JSON.stringify(response, null, 2)
        );

        const metadata = response[0].data.getVideo;
        console.log(
          "📊 Raw metadata object:",
          JSON.stringify(metadata, null, 2)
        );

        if (metadata.__typename === "VideoPasswordMissingOrIncorrect") {
          console.warn("🔒 Video is password protected");
          if (sendResponse) {
            sendResponse({
              success: false,
              error:
                "This video is password-protected. Please provide the correct password.",
            });
          }
        } else if (metadata.status === "error") {
          console.error("❌ Video processing error:", metadata.message);
          if (sendResponse) {
            sendResponse({
              success: false,
              error: `Video processing error: ${metadata.message}`,
            });
          }
        } else {
          const videoInfo = {
            title: metadata.name,
            owner: metadata.owner.display_name,
            duration: metadata.video_properties.duration,
            width: metadata.video_properties.width,
            height: metadata.video_properties.height,
            description: metadata.description,
            url: request.url,
          };
          console.log("✅ Video info extracted successfully:", metadata.name);
          console.log("🕐 API Duration (seconds):", metadata.video_properties.duration);
          console.log("🕐 API Duration (formatted):", Math.floor(metadata.video_properties.duration / 60) + ":" + (metadata.video_properties.duration % 60).toString().padStart(2, '0'));
          console.log(
            "📦 Final videoInfo object being returned:",
            JSON.stringify(videoInfo, null, 2)
          );
          if (sendResponse) {
            sendResponse({
              success: true,
              videoInfo: videoInfo,
            });
          }
        }
      })
      .catch((error) => {
        console.error("❌ Error in extractVideoInfo:", error);
        if (sendResponse) {
          sendResponse({ success: false, error: error.message });
        }
      });
  }
}
