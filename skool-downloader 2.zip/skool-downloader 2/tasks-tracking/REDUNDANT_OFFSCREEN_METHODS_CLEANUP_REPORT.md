# Redundant Offscreen Methods Cleanup Report

**Generated:** 2025-08-18  
**Scope:** skool-downloader offscreen method usage analysis  
**Purpose:** Identify unused/redundant code for removal after DASH processing development  

## Executive Summary

**Critical Finding:** ~473 lines of completely unused DASH processing code can be safely removed from `offscreen-faststream-legacy.js`.

**Key Statistics:**
- **Available offscreen methods:** 3 callable + ~15 internal functions
- **Actually used methods:** 2 primary message types + lifecycle methods  
- **Unused code:** 473+ lines (25% of offscreen file)
- **Redundancy level:** HIGH - Multiple competing implementations for same functionality

## Available Offscreen Methods

### Callable Methods (from offscreen message listener lines 1980-1995)
1. **`MERGE_SEGMENTS_FASTSTREAM`** ✅ USED - HLS segment merging
2. **`MERGE_SEPARATE_AV_FASTSTREAM`** ✅ USED - Separate A/V merging  
3. **`PING`** ❌ UNUSED - Test connectivity method

### Internal Functions Status
- `debugLog()` - ✅ Used (helper)
- `loadModules()` - ✅ Used (initialization)
- `loadAllSegments()` - ✅ Used (HLS segments)
- `processSegmentsWithFastStream()` - ✅ Used (HLS processing)
- `loadSeparateAVSegments()` - ✅ Used (A/V segments)  
- `processDashSegments()` - ✅ Used (DASH processing)
- **`muxDashStreamsWithMediaBunny()`** - ❌ UNUSED (lines 508-732)
- **`combineVideoAudioWithMP4Box()`** - ❌ UNUSED (lines 734-981)
- Various parsing helpers - ✅ Used

## Usage Analysis by File

### handlers/loom-handler.js
**Active offscreen calls:**
- Line 852: `createOffscreenDocument()` 
- Line 898: `MERGE_SEPARATE_AV_FASTSTREAM` message ✅
- Line 1052: `createOffscreenDocument()`
- Line 1340: `MERGE_SEGMENTS_FASTSTREAM` message ✅
- Lines 302, 931: `closeOffscreenDocument()`

### handlers/skool-handler.js  
**Active offscreen calls:**
- Lines 163, 333, 723: `createOffscreenDocument()`
- Line 166: `MERGE_SEGMENTS_FASTSTREAM` message ✅
- Line 766: `MERGE_SEGMENTS_FASTSTREAM` message ✅  
- Lines 370, 796: `closeOffscreenDocument()`

### handlers/vimeo-handler.js
**Active offscreen calls:**
- Lines 1470, 1877: `createOffscreenDocument()`
- Line 1757: `MERGE_SEGMENTS_FASTSTREAM` message ✅
- Line 2199: `MERGE_SEPARATE_AV_FASTSTREAM` message ✅
- Line 948: `closeOffscreenDocument()`

### handlers/wistia-handler.js
**Active offscreen calls:**
- Line 251: `closeOffscreenDocument()` only

### handlers/youtube-handler.js
**No offscreen usage** - YouTube doesn't download videos

### content-enhanced.js
**No direct offscreen calls** - Only IndexedDB operations for segment storage

### background-enhanced.js
**Lifecycle management only:**
- Line 35: `createOffscreenDocument()`
- Line 97: `closeOffscreenDocument()`
- Line 1003: Test function usage

## Critical Cleanup Targets

### 🔥 HIGH PRIORITY - Remove Immediately (473 lines)

#### 1. MediaBunny DASH Muxing (225 lines)
**File:** `offscreen-faststream-legacy.js`  
**Lines:** 508-732  
**Function:** `muxDashStreamsWithMediaBunny()`  
**Status:** Completely unused - MediaBunny approach was abandoned  
**Dependencies:** MediaBunny imports, related helper functions

#### 2. MP4Box Video/Audio Combination (248 lines)  
**File:** `offscreen-faststream-legacy.js`  
**Lines:** 734-981  
**Function:** `combineVideoAudioWithMP4Box()`  
**Status:** Completely unused - MP4Box approach was abandoned  
**Dependencies:** MP4Box imports, related helper functions

### 🟡 MEDIUM PRIORITY - Review and Consolidate

#### 3. Duplicate Segment Processing
**Issue:** `MERGE_SEGMENTS_FASTSTREAM` used for both HLS and DASH  
**Files:** skool-handler.js (lines 166, 766)  
**Recommendation:** Create separate message types for clarity

#### 4. Test Method Cleanup
**Function:** `PING` message handler  
**Usage:** Only in test functions, not production  
**Recommendation:** Remove from production build

### 🟢 LOW PRIORITY - Future Optimization

#### 5. Parsing Function Consolidation
**Files:** Multiple M3U8/XML parsing utilities  
**Recommendation:** Consolidate duplicate parsing logic

## Removal Safety Analysis

### ✅ SAFE TO REMOVE
1. **`muxDashStreamsWithMediaBunny()`** - No references found in any file
2. **`combineVideoAudioWithMP4Box()`** - No references found in any file  
3. **MediaBunny imports** - Only used in unused function
4. **MP4Box imports** - Only used in unused function
5. **Related helper functions** for above methods

### ⚠️ VERIFY BEFORE REMOVAL  
1. **`PING` handler** - Confirm test usage only
2. **Duplicate parsing functions** - Map all usage first

### ❌ DO NOT REMOVE
1. **`MERGE_SEGMENTS_FASTSTREAM`** - Actively used in 4 places
2. **`MERGE_SEPARATE_AV_FASTSTREAM`** - Actively used in 2 places
3. **FastStream core functions** - Primary processing methods
4. **Lifecycle management** - Document creation/closure

## Recommended Cleanup Sequence

### Phase 1: Dead Code Removal
1. Remove `muxDashStreamsWithMediaBunny()` function (lines 508-732)
2. Remove `combineVideoAudioWithMP4Box()` function (lines 734-981)  
3. Remove related imports: MediaBunny, MP4Box
4. Remove helper functions that only serve removed methods

### Phase 2: Test Method Cleanup  
1. Remove `PING` handler from production message listener
2. Keep in test/debug builds if needed

### Phase 3: Consolidation (Future)
1. Standardize message types for different processing scenarios
2. Consolidate duplicate parsing utilities
3. Refactor shared handler utilities

## Expected Benefits

### Immediate Impact
- **File size reduction:** ~25% smaller offscreen-faststream-legacy.js
- **Maintenance overhead:** Significantly reduced
- **Code clarity:** Remove competing implementations
- **Bundle size:** Smaller extension package

### Long-term Benefits  
- **Easier debugging:** Single code path for each operation
- **Performance:** Fewer unused imports loaded
- **Future development:** Cleaner architecture for new features

## Risk Assessment

**Risk Level:** LOW  
**Reason:** Identified code is completely unused with no references

**Verification Steps:**
1. ✅ Grep analysis completed - no references to unused functions
2. ✅ Handler analysis completed - only FastStream methods used
3. ✅ Content script analysis - no direct offscreen calls
4. ✅ Background script analysis - only lifecycle methods used

**Rollback Plan:** Git commit before cleanup allows easy reversion if issues arise

---
**Next Steps:** Review this report, then proceed with Phase 1 cleanup to remove the 473 lines of dead code.