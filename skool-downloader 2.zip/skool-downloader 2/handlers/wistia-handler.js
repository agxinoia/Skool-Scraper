// =================================================================================
// WISTIA HANDLER
// =================================================================================

export class WistiaHandler {
  constructor(utils) {
    this.utils = utils;
  }

  /**
   * Ensures URL uses HTTPS protocol for security
   */
  enforceHttps(url) {
    if (!url) return url;
    return url.replace(/^http:\/\//i, 'https://');
  }

  async extractInfo(url) {
    console.log("🔍 extractWistiaInfo called with URL:", url);

    const match = url.match(
      /(?:wistia:|https?:\/\/(?:\w+\.)?wistia\.(?:net|com)\/(?:embed\/)?(?:iframe|medias|playlists|channel)\/)([a-z0-9]{10})/
    );
    const wistiaId = match ? match[1] : null;

    if (!wistiaId) {
      console.error("❌ Could not extract Wistia video ID from URL:", url);
      return null;
    }

    console.log("✅ Extracted Wistia video ID:", wistiaId);

    try {
      const contentType = url.includes("/playlists/")
        ? "playlist"
        : url.includes("/channel/")
        ? "channel"
        : "video";
      const apiPath =
        contentType === "playlist"
          ? "playlists"
          : contentType === "channel"
          ? "channel"
          : "medias";

      const embedUrl = `https://fast.wistia.net/embed/${apiPath}/${wistiaId}.json`;
      console.log("🌐 Fetching embed config from:", embedUrl);

      const response = await fetch(embedUrl, {
        headers: {
          Accept: "application/json",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const embedConfig = await response.json();
      console.log("✅ Got embed config for:", wistiaId);

      if (embedConfig.error) {
        throw new Error(`Wistia API error: ${embedConfig.error}`);
      }

      if (contentType === "video" && embedConfig.media) {
        const media = embedConfig.media;

        const isPasswordProtected =
          media.embed_options?.plugin?.passwordProtectedVideo?.on === "true" ||
          media.embedOptions?.plugin?.passwordProtectedVideo?.on === "true";

        if (isPasswordProtected) {
          throw new Error(
            "This Wistia video is password-protected and cannot be downloaded"
          );
        }

        let thumbnail = null;
        const files = [];

        if (media.assets) {
          for (const asset of media.assets) {
            if (asset.type === "still" || asset.type === "still_image") {
              if (asset.url) {
                let thumbUrl = asset.url.endsWith("bin")
                  ? asset.url.replace(/\.?bin$/, ".jpg")
                  : asset.url;
                thumbnail = this.enforceHttps(thumbUrl);
                break;
              }
            }
          }
        }

        if (media.assets) {
          for (const asset of media.assets) {
            if (
              asset.url &&
              asset.status === 2 &&
              !["preview", "storyboard", "still", "still_image"].includes(
                asset.type
              ) &&
              asset.ext !== "bin"
            ) {
              files.push({
                quality: asset.height ? `${asset.height}p` : asset.type,
                ext: asset.ext || "mp4",
                url: asset.url,
                width: asset.width || null,
                height: asset.height || null,
                filesize: asset.size || null,
                isOriginal: asset.type === "original",
              });
            }
          }
        }

        files.sort((a, b) => {
          if (a.isOriginal && !b.isOriginal) return -1;
          if (!a.isOriginal && b.isOriginal) return 1;
          return (b.height || 0) - (a.height || 0);
        });

        return {
          platform: "Wistia",
          url: url,
          id: wistiaId,
          title: media.name || `Wistia Video ${wistiaId}`,
          description: media.seoDescription || null,
          duration: media.duration || null,
          thumbnail: thumbnail,
          files: files,
          contentType: contentType,
        };
      } else {
        return {
          platform: "Wistia",
          url: url,
          id: wistiaId,
          title: `Wistia ${contentType} ${wistiaId}`,
          contentType: contentType,
          files: [],
        };
      }
    } catch (error) {
      console.error("❌ Wistia extraction failed:", error);
      return null;
    }
  }

  async downloadVideo(url, videoInfo = null, selectedQualityIndex = null) {
    console.log(`🎬 Starting WISTIA download for: ${url}`);

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      downloadCancelled: false,
      activeDownloads: globalState.activeDownloads + 1,
    });

    try {
      if (!videoInfo) {
        console.log("🔍 Extracting video info for download...");
        this.utils.sendProgressToPopup(
          5,
          "Extracting Wistia video information..."
        );

        videoInfo = await this.extractInfo(url);
        if (!videoInfo) {
          throw new Error(
            "Could not extract video information for this Wistia URL."
          );
        }
      }

      console.log("✅ Using video info for download:", videoInfo);
      console.log("📋 Selected quality index:", selectedQualityIndex);

      if (
        videoInfo.contentType === "playlist" ||
        videoInfo.contentType === "channel"
      ) {
        throw new Error(
          `Cannot directly download ${videoInfo.contentType}. Please select a specific video from the ${videoInfo.contentType}.`
        );
      }

      if (!videoInfo.files || videoInfo.files.length === 0) {
        throw new Error("No downloadable formats found for this video");
      }

      let selectedFile = null;

      if (
        selectedQualityIndex !== null &&
        selectedQualityIndex !== "" &&
        videoInfo.files[selectedQualityIndex]
      ) {
        selectedFile = videoInfo.files[selectedQualityIndex];
        console.log(
          `🎯 Using user-selected quality: ${selectedFile.quality} (${selectedFile.ext})`
        );
      } else {
        selectedFile = videoInfo.files.reduce((best, file) => {
          if (file.isOriginal && !best.isOriginal) return file;
          if (!file.isOriginal && best.isOriginal) return best;
          return (file.height || 0) > (best.height || 0) ? file : best;
        });
        console.log(
          `📊 Using best quality as fallback: ${selectedFile.quality} (${selectedFile.ext})`
        );
      }

      if (!selectedFile || !selectedFile.url) {
        throw new Error("Selected video format is not available for download");
      }

      const sanitizedTitle = videoInfo.title
        .replace(/[<>:"/\\|?*]/g, "_")
        .replace(/\s+/g, "_")
        .substring(0, 100);

      const fileName = `${sanitizedTitle}_${videoInfo.id}.${selectedFile.ext}`;
      console.log(`📁 Generated filename: ${fileName}`);

      this.utils.sendProgressToPopup(10, "Starting Wistia video download...");

      console.log(`🔽 Downloading Wistia file: ${selectedFile.url}`);
      await this.utils.downloadFile(selectedFile.url, fileName);

      console.log("✅ Wistia download completed successfully!");
    } catch (error) {
      console.error("❌ Wistia download failed:", error);
      this.utils.sendDownloadError(`Wistia Download Failed: ${error.message}`);
      throw error;
    } finally {
      const globalState = this.utils.getGlobalState();
      if (globalState.activeDownloads > 0) {
        this.utils.setGlobalState({
          activeDownloads: globalState.activeDownloads - 1,
        });
      }
      if (globalState.downloadCancelled) {
        this.utils.setGlobalState({ downloadCancelled: false });
        console.log("🔄 Reset downloadCancelled flag after completion");
      }
      // Don't close offscreen here - let the Chrome download completion handle it
      console.log(`📊 Wistia handler finished, activeDownloads: ${globalState.activeDownloads}, keeping offscreen open for Chrome download`);
    }
  }

  async findEmbed(request, sender, sendResponse) {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      if (!tab) {
        console.error("No active tab found");
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No active tab found",
          });
        }
        return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          console.log("🔍 Searching for Wistia embeds in page...");

          const findWistiaVideoId = () => {
            const currentUrl = window.location.href;

            const wistiaUrlMatch = currentUrl.match(
              /(?:^wistia:|https?:\/\/(?:\w+\.)?wistia\.(?:net|com)\/(?:embed\/)?(?:iframe|medias|playlists|channel)\/)([a-z0-9]{10})/
            );
            if (wistiaUrlMatch) {
              return wistiaUrlMatch[1];
            }

            const urlParams = new URLSearchParams(window.location.search);
            const mediaIdFromUrl =
              urlParams.get("wmediaid") ||
              urlParams.get("wvideo") ||
              urlParams.get("wvideoid");
            if (mediaIdFromUrl && /^[a-z0-9]{10}$/.test(mediaIdFromUrl)) {
              return mediaIdFromUrl;
            }

            const asyncEmbeds = document.querySelectorAll(
              '[class*="wistia_async_"]'
            );
            for (const embed of asyncEmbeds) {
              const match = embed.className.match(
                /wistia_async_([a-z0-9]{10})/
              );
              if (match) return match[1];
            }

            const wistiaElements = document.querySelectorAll(
              "[data-wistia-id], [data-wistia-video-id]"
            );
            for (const element of wistiaElements) {
              const id =
                element.getAttribute("data-wistia-id") ||
                element.getAttribute("data-wistia-video-id");
              if (id && /^[a-z0-9]{10}$/.test(id)) return id;
            }

            const scripts = document.querySelectorAll("script");
            for (const script of scripts) {
              const content = script.textContent || script.innerHTML;
              const embedMatch = content.match(
                /Wistia\.embed\(["']([a-z0-9]{10})["']/
              );
              if (embedMatch) return embedMatch[1];

              const idMatch = content.match(
                /(?:wmediaid|wvideo(?:id)?)['\"=\s]*([a-z0-9]{10})/
              );
              if (idMatch) return idMatch[1];
            }

            const iframes = document.querySelectorAll('iframe[src*="wistia"]');
            for (const iframe of iframes) {
              const match = iframe.src.match(
                /(?:embed\/(?:iframe|medias)\/|wmediaid=)([a-z0-9]{10})/
              );
              if (match) return match[1];
            }

            return null;
          };

          const videoId = findWistiaVideoId();
          if (videoId) {
            console.log("✅ Found Wistia video ID:", videoId);

            const getContentType = () => {
              if (window.location.href.includes("/playlists/"))
                return "playlist";
              if (window.location.href.includes("/channel/")) return "channel";
              return "video";
            };

            let title = `Wistia Video ${videoId}`;
            const titleSelectors = [
              'meta[property="og:title"]',
              'meta[name="twitter:title"]',
              "h1",
              "title",
            ];

            for (const selector of titleSelectors) {
              const element = document.querySelector(selector);
              if (element) {
                const extractedTitle = element.content || element.textContent;
                if (extractedTitle && extractedTitle.trim()) {
                  title = extractedTitle.trim();
                  break;
                }
              }
            }

            let thumbnail = null;
            const thumbnailSelectors = [
              'meta[property="og:image"]',
              'meta[name="twitter:image"]',
              "video[poster]",
            ];

            for (const selector of thumbnailSelectors) {
              const element = document.querySelector(selector);
              if (element) {
                thumbnail = element.content || element.poster || element.src;
                if (thumbnail) break;
              }
            }

            return {
              type: "embed",
              id: videoId,
              title: title,
              url: window.location.href,
              thumbnail: thumbnail,
              platform: "Wistia",
              contentType: getContentType(),
              source: "wistia_detection",
              pageUrl: window.location.href,
              pageTitle: document.title,
            };
          }

          console.log("❌ No Wistia embeds found");
          return null;
        },
      });

      if (results && results[0] && results[0].result) {
        const embedInfo = results[0].result;
        console.log("✅ Found Wistia embed:", embedInfo);

        try {
          const contentType = embedInfo.contentType || "video";
          const apiPath =
            contentType === "playlist"
              ? "playlists"
              : contentType === "channel"
              ? "channel"
              : "medias";

          const embedUrl = `https://fast.wistia.net/embed/${apiPath}/${embedInfo.id}.json`;
          const response = await fetch(embedUrl);

          let videoInfo = {
            id: embedInfo.id,
            title: embedInfo.title || `Wistia Video ${embedInfo.id}`,
            thumbnail: embedInfo.thumbnail,
            url: embedInfo.url,
            platform: "wistia",
            isWistiaVideo: true,
            contentType: contentType,
            files: [],
          };

          if (response.ok) {
            const data = await response.json();
            if (data.media && !data.error) {
              const media = data.media;
              videoInfo = {
                ...videoInfo,
                title: media.name || videoInfo.title,
                description: media.seoDescription,
                duration: media.duration,
              };

              if (media.assets) {
                for (const asset of media.assets) {
                  if (asset.type === "still" || asset.type === "still_image") {
                    if (asset.url) {
                      let thumbUrl = asset.url.endsWith("bin")
                        ? asset.url.replace(/\.?bin$/, ".jpg")
                        : asset.url;
                      videoInfo.thumbnail = this.enforceHttps(thumbUrl);
                      break;
                    }
                  }
                }
              }

              if (media.assets) {
                for (const asset of media.assets) {
                  if (
                    asset.url &&
                    asset.status === 2 &&
                    !["preview", "storyboard", "still", "still_image"].includes(
                      asset.type
                    ) &&
                    asset.ext !== "bin"
                  ) {
                    videoInfo.files.push({
                      quality: asset.height ? `${asset.height}p` : asset.type,
                      ext: asset.ext || "mp4",
                      url: asset.url,
                      width: asset.width,
                      height: asset.height,
                    });
                  }
                }
              }
            }
          }

          if (sendResponse) {
            sendResponse({
              success: true,
              embedInfo: embedInfo,
              videoInfo: videoInfo,
            });
          }
        } catch (error) {
          console.error("❌ Error extracting Wistia video info:", error);
          if (sendResponse) {
            sendResponse({
              success: false,
              error: "Could not extract Wistia video information.",
            });
          }
        }
      } else {
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No Wistia embed found on this page.",
          });
        }
      }
    } catch (error) {
      console.error("❌ Error in findWistiaEmbed:", error);
      if (sendResponse) {
        sendResponse({
          success: false,
          error: "Error finding Wistia embed.",
        });
      }
    }
  }

  extractVideoInfo(request, sender, sendResponse) {

    const match = request.url.match(
      /(?:wistia:|https?:\/\/(?:\w+\.)?wistia\.(?:net|com)\/(?:embed\/)?(?:iframe|medias|playlists|channel)\/)([a-z0-9]{10})/
    );
    const wistiaId = match ? match[1] : null;

    if (!wistiaId) {
      if (sendResponse) {
        sendResponse({
          success: false,
          error: "Could not extract Wistia video ID from URL.",
        });
      }
      return;
    }

    const contentType = request.url.includes("/playlists/")
      ? "playlist"
      : request.url.includes("/channel/")
      ? "channel"
      : "video";
    const apiPath =
      contentType === "playlist"
        ? "playlists"
        : contentType === "channel"
        ? "channel"
        : "medias";

    fetch(`https://fast.wistia.net/embed/${apiPath}/${wistiaId}.json`)
      .then((response) => response.json())
      .then((embedConfig) => {
        if (embedConfig.error) {
          throw new Error(`Wistia API error: ${embedConfig.error}`);
        }

        let videoInfo;
        if (contentType === "video" && embedConfig.media) {
          const media = embedConfig.media;
          let thumbnail = null;

          if (media.assets) {
            for (const asset of media.assets) {
              if (asset.type === "still" || asset.type === "still_image") {
                if (asset.url) {
                  let thumbUrl = asset.url.endsWith("bin")
                    ? asset.url.replace(/\.?bin$/, ".jpg")
                    : asset.url;
                  thumbnail = this.enforceHttps(thumbUrl);
                  break;
                }
              }
            }
          }

          const formats = [];
          if (media.assets) {
            for (const asset of media.assets) {
              if (
                asset.url &&
                asset.status === 2 &&
                !["preview", "storyboard", "still", "still_image"].includes(
                  asset.type
                ) &&
                asset.ext !== "bin"
              ) {
                formats.push({
                  format_id: asset.type,
                  url: asset.url,
                  ext: asset.ext || "mp4",
                  width: asset.width,
                  height: asset.height,
                  quality: asset.type === "original" ? 1 : 0,
                });
              }
            }
          }

          formats.sort(
            (a, b) =>
              (b.quality || 0) - (a.quality || 0) ||
              (b.height || 0) - (a.height || 0)
          );

          videoInfo = {
            id: wistiaId,
            title: media.name || `Wistia Video ${wistiaId}`,
            description: media.seoDescription,
            duration: media.duration,
            thumbnail: thumbnail,
            url: request.url,
            platform: "wistia",
            isWistiaVideo: true,
            formats: formats,
            files: formats.map((f) => ({
              quality: f.height ? `${f.height}p` : f.format_id,
              ext: f.ext,
              url: f.url,
              width: f.width,
              height: f.height,
            })),
          };
        } else {
          videoInfo = {
            id: wistiaId,
            title: `Wistia ${contentType} ${wistiaId}`,
            url: request.url,
            platform: "wistia",
            isWistiaVideo: true,
            contentType: contentType,
            formats: [],
            files: [],
          };
        }

        if (sendResponse) {
          sendResponse({
            success: true,
            videoInfo: videoInfo,
          });
        }
      })
      .catch((error) => {
        console.error("❌ Wistia API error:", error);
        const videoInfo = {
          id: wistiaId,
          title: `Wistia Video ${wistiaId}`,
          url: request.url,
          platform: "wistia",
          isWistiaVideo: true,
          formats: [],
          files: [],
        };

        if (sendResponse) {
          sendResponse({
            success: true,
            videoInfo: videoInfo,
          });
        }
      });
  }
}
