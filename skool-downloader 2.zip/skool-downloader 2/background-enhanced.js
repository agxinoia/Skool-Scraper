// =================================================================================
// MAIN BACKGROUND SCRIPT - REFACTORED
// =================================================================================

import { set, get, remove } from "./indexed-db.js";
import { LoomHandler } from "./handlers/loom-handler.js";
import { SkoolHandler } from "./handlers/skool-handler.js";
import { VimeoHandler } from "./handlers/vimeo-handler.js";
import { WistiaHandler } from "./handlers/wistia-handler.js";
import { YouTubeHandler } from "./handlers/youtube-handler.js";

console.log("🚀 Universal Video Downloader Background Script Starting...");

// =================================================================================
// GLOBAL STATE & CONFIGURATION
// =================================================================================

let offscreenCreated = false;
let activeDownloads = 0;
let downloadCancelled = false;
const activeDownloadIds = new Set();
let currentDownloadProgress = {
  percentage: 0,
  status: "",
  speed: "",
};

// =================================================================================
// CORE UTILITIES
// =================================================================================

/**
 * Creates the offscreen document for FFmpeg processing if it doesn't already exist.
 */
async function createOffscreenDocument() {
  console.log("Creating offscreen document...");

  await new Promise(async (resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.runtime.onMessage.removeListener(listener);
      reject(
        new Error("Offscreen document creation timed out after 30 seconds.")
      );
    }, 30000);

    const listener = (message) => {
      if (message.type === "FASTSTREAM_OFFSCREEN_READY") {
        clearTimeout(timeout);
        chrome.runtime.onMessage.removeListener(listener);
        offscreenCreated = true;
        console.log("✅ Offscreen document is ready.");
        resolve();
      } else if (message.type === "OFFSCREEN_ERROR") {
        clearTimeout(timeout);
        chrome.runtime.onMessage.removeListener(listener);
        console.error("❌ Offscreen document failed to load:", message.error);
        reject(new Error(`Offscreen document error: ${message.error.message}`));
      }
    };

    chrome.runtime.onMessage.addListener(listener);

    try {
      await chrome.offscreen.createDocument({
        url: "offscreen-faststream.html",
        reasons: ["WORKERS"],
        justification:
          "FastStream HLS2MP4 converter needs to run in a separate worker process.",
      });
      console.log("✅ New offscreen document created, waiting for ready signal...");
    } catch (error) {
      if (error.message && error.message.includes('Only a single offscreen')) {
        console.log("✅ Offscreen document already exists - reusing existing instance");
        offscreenCreated = true;
        clearTimeout(timeout);
        chrome.runtime.onMessage.removeListener(listener);
        resolve();
        return;
      }
      clearTimeout(timeout);
      chrome.runtime.onMessage.removeListener(listener);
      console.error("❌ Failed to create offscreen document:", error);
      reject(error);
    }
  });
}

/**
 * Closes the offscreen document if it exists.
 */
async function closeOffscreenDocument() {
  if (!offscreenCreated) return;

  try {
    await chrome.offscreen.closeDocument();
    offscreenCreated = false;
    console.log("✅ Offscreen document closed");
  } catch (error) {
    console.warn("⚠️ Error closing offscreen document:", error);
  }
}

/**
 * Sends a progress update message to the popup.
 */
function sendProgressToPopup(percentage, status, speed = "") {
  currentDownloadProgress = { percentage, status, speed };
  try {
    chrome.runtime
      .sendMessage({
        type: "DOWNLOAD_PROGRESS",
        percentage,
        status,
        speed,
      })
      .catch(() => {
        // Ignore errors if popup is closed
      });
  } catch (e) {
    // Ignore errors if extension context is invalid
  }
}

/**
 * Sends a download completion message to the popup.
 */
function sendDownloadComplete(status = "Download completed!") {
  currentDownloadProgress = { percentage: 100, status, speed: "" };
  try {
    chrome.runtime
      .sendMessage({
        type: "DOWNLOAD_COMPLETE",
        status,
      })
      .catch(() => {
        // Ignore errors if popup is closed
      });
  } catch (e) {
    // Ignore errors if extension context is invalid
  }
}

/**
 * Sends a download error message to the popup.
 */
function sendDownloadError(error) {
  currentDownloadProgress = {
    percentage: 0,
    status: `Error: ${error}`,
    speed: "",
  };
  try {
    chrome.runtime
      .sendMessage({
        type: "DOWNLOAD_ERROR",
        error,
      })
      .catch(() => {
        // Ignore errors if popup is closed
      });
  } catch (e) {
    // Ignore errors if extension context is invalid
  }
}

/**
 * Sends a download cancellation message to the popup.
 */
function sendDownloadCancelled(message = "Download cancelled by user") {
  currentDownloadProgress = {
    percentage: 0,
    status: "Download cancelled",
    speed: "",
  };
  try {
    chrome.runtime
      .sendMessage({
        type: "DOWNLOAD_CANCELLED",
        message,
      })
      .catch(() => {
        // Ignore errors if popup is closed
      });
  } catch (e) {
    // Ignore errors if extension context is invalid
  }
}

/**
 * Generates a browser-compatible UUID v4.
 */
const uuidv4 = () => {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    var r = (Math.random() * 16) | 0,
      v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

/**
 * Downloads a file directly using the chrome.downloads API, with a fetch/blob fallback.
 */
async function downloadFile(url, fileName) {
  console.log(`🔽 Starting direct download from: ${url}`);
  activeDownloads++;

  sendProgressToPopup(10, "Starting download...");

  try {
    // First, try to download directly from the URL using Chrome's download API
    try {
      sendProgressToPopup(25, "Initiating file download...");

      const downloadId = await new Promise((resolve, reject) => {
        chrome.downloads.download(
          {
            url: url,
            filename: fileName,
            saveAs: true,
          },
          (downloadId) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (downloadId) {
              resolve(downloadId);
            } else {
              reject(new Error("Download failed to start."));
            }
          }
        );
      });

      activeDownloadIds.add(downloadId);
      console.log(
        `✅ Direct download initiated for: ${fileName} (ID: ${downloadId})`
      );

      // Track download progress
      const progressInterval = setInterval(() => {
        if (downloadCancelled) {
          console.log("🚫 Download cancelled, stopping progress tracking");
          clearInterval(progressInterval);
          activeDownloadIds.delete(downloadId);
          activeDownloads = Math.max(0, activeDownloads - 1);
          console.log(
            `📊 Download cancelled, active downloads: ${activeDownloads}`
          );

          chrome.downloads.cancel(downloadId, () => {
            if (chrome.runtime.lastError) {
              console.log(
                `⚠️ Could not cancel download ${downloadId}: ${chrome.runtime.lastError.message}`
              );
            } else {
              console.log(`🚫 Chrome download ${downloadId} cancelled`);
            }
          });
          return;
        }

        chrome.downloads.search({ id: downloadId }, (downloads) => {
          if (downloads.length > 0) {
            const download = downloads[0];
            const percentage =
              download.totalBytes > 0
                ? (download.bytesReceived / download.totalBytes) * 100
                : 0;

            let status = "Downloading...";
            if (download.totalBytes > 0) {
              const mbReceived = (download.bytesReceived / 1024 / 1024).toFixed(
                1
              );
              const mbTotal = (download.totalBytes / 1024 / 1024).toFixed(1);
              status = `Downloading... ${mbReceived}/${mbTotal} MB`;
            }

            sendProgressToPopup(percentage, status);

            if (download.state === "complete") {
              clearInterval(progressInterval);
              activeDownloadIds.delete(downloadId);
              activeDownloads = Math.max(0, activeDownloads - 1);
              console.log(
                `📊 Download completed, active downloads: ${activeDownloads}`
              );
              sendDownloadComplete(`Download completed: ${fileName}`);
            } else if (download.state === "interrupted") {
              clearInterval(progressInterval);
              activeDownloadIds.delete(downloadId);
              activeDownloads = Math.max(0, activeDownloads - 1);
              console.log(
                `📊 Download interrupted, active downloads: ${activeDownloads}`
              );
              sendDownloadError(
                `Download interrupted: ${download.error || "Unknown error"}`
              );
            }
          }
        });
      }, 500);

      return;
    } catch (directDownloadError) {
      console.warn(
        "⚠️ Direct download failed, trying blob approach:",
        directDownloadError
      );
    }

    // Fallback: blob approach
    sendProgressToPopup(0, "Fetching video file...");
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(
        `Download failed: ${response.status} ${response.statusText}`
      );
    }

    sendProgressToPopup(25, "Reading video data...");
    const blob = await response.blob();
    const blobSize = blob.size;

    sendProgressToPopup(
      50,
      `Processing ${(blobSize / 1024 / 1024).toFixed(1)} MB file...`
    );

    sendProgressToPopup(75, "Converting file for download...");
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => {
        console.error("❌ FileReader error:", error);
        reject(new Error("Failed to read blob: " + error));
      };
      reader.readAsDataURL(blob);
    });

    sendProgressToPopup(90, "Initiating download...");
    chrome.downloads.download({
      url: dataUrl,
      filename: fileName,
      saveAs: true,
    });

    console.log(`✅ Download initiated for: ${fileName}`);
    sendDownloadComplete(`Download started: ${fileName}`);
  } catch (error) {
    console.error("❌ Download failed:", error);
    sendDownloadError(`Download failed: ${error.message}`);
    throw error;
  } finally {
    activeDownloads = Math.max(0, activeDownloads - 1);
    console.log(
      `📊 Download failed/completed, active downloads: ${activeDownloads}`
    );
  }
}

/**
 * Sanitizes a string to be used as a valid filename.
 */
function sanitizeFileName(title) {
  if (!title) return "Untitled_Video";
  return title
    .replace(/[^a-z0-9\s\-_]/gi, "")
    .replace(/\s+/g, "_")
    .toLowerCase();
}

/**
 * Handles thumbnail proxy requests to bypass CORS restrictions.
 */
async function handleThumbnailProxy(request, sender, sendResponse) {
  try {
    console.log("🖼️ Fetching thumbnail via proxy:", request.url);

    const response = await fetch(request.url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const blob = await response.blob();
    const reader = new FileReader();

    reader.onload = () => {
      console.log("✅ Thumbnail successfully fetched via proxy");
      sendResponse({
        success: true,
        dataUrl: reader.result,
      });
    };

    reader.onerror = () => {
      console.error("❌ Failed to convert thumbnail blob to data URL");
      sendResponse({
        success: false,
        error: "Failed to convert image to data URL",
      });
    };

    reader.readAsDataURL(blob);
  } catch (error) {
    console.error("❌ Thumbnail proxy failed:", error);
    sendResponse({
      success: false,
      error: error.message,
    });
  }
}

// =================================================================================
// HANDLERS INITIALIZATION
// =================================================================================

// Initialize handlers with shared utilities
const sharedUtils = {
  createOffscreenDocument,
  closeOffscreenDocument,
  sendProgressToPopup,
  sendDownloadComplete,
  sendDownloadError,
  sendDownloadCancelled,
  downloadFile,
  sanitizeFileName,
  uuidv4,
  set,
  get,
  remove,
  getGlobalState: () => ({
    offscreenCreated,
    activeDownloads,
    downloadCancelled,
    activeDownloadIds,
    currentDownloadProgress,
  }),
  setGlobalState: (updates) => {
    if ("offscreenCreated" in updates)
      offscreenCreated = updates.offscreenCreated;
    if ("activeDownloads" in updates) activeDownloads = updates.activeDownloads;
    if ("downloadCancelled" in updates)
      downloadCancelled = updates.downloadCancelled;
    if ("currentDownloadProgress" in updates)
      currentDownloadProgress = updates.currentDownloadProgress;
  },
  addActiveDownloadId: (id) => activeDownloadIds.add(id),
  deleteActiveDownloadId: (id) => activeDownloadIds.delete(id),
  clearActiveDownloadIds: () => activeDownloadIds.clear(),
};

const loomHandler = new LoomHandler(sharedUtils);
const skoolHandler = new SkoolHandler(sharedUtils);
const vimeoHandler = new VimeoHandler(sharedUtils);
const wistiaHandler = new WistiaHandler(sharedUtils);
const youtubeHandler = new YouTubeHandler(sharedUtils);

// =================================================================================
// MESSAGE ROUTER
// =================================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Fire-and-forget messages
  const fireAndForgetTypes = [
    "MERGE_AUDIO_VIDEO",
    "MERGE_SEGMENTS",
    "MERGE_SEGMENTS_RESPONSE",
    "MERGE_SEPARATE_AV",
    "MERGE_SEPARATE_AV_RESPONSE",
    "MERGE_RESPONSE",
    "MERGE_COMPLETE",
    "OFFSCREEN_DOCUMENT_READY",
    "OFFSCREEN_ERROR",
    "DEBUG_MESSAGE",
    "DOWNLOAD_PROCESSED_FILE",
    "DOWNLOAD_COMPLETE_NOTIFICATION",
    "PONG",
  ];

  const fireAndForgetActions = [
    "saveDOM",
    "loomEmbedDetected",
    "videoDetected",
    "wistiaVideoDetected",
  ];

  if (
    fireAndForgetTypes.includes(request.type) ||
    fireAndForgetActions.includes(request.action)
  ) {
    handleRequest(request, sender, null);
    return false;
  }

  if (request.action) {
    // Other async actions that don't require activation
    handleRequest(request, sender, sendResponse);
    return true;
  } else {
    // Messages without action, handle as fire-and-forget
    console.log(
      "🔄 Handling message without action:",
      request.type || "unknown"
    );
    handleRequest(request, sender, null);
    return false;
  }
});

async function handleRequest(request, sender, sendResponse) {
  switch (request.action) {
    case "detectVideoOnCurrentTab":
      handleDetectVideo(request, sender, sendResponse);
      break;

    case "extractVideoInfo":
      handleExtractVideoInfo(request, sender, sendResponse);
      break;

    case "downloadVideo":
      handleDownloadVideo(request, sender, sendResponse);
      break;

    case "getVideoInfo":
      vimeoHandler.getVideoInfo(request, sender, sendResponse);
      break;

    case "findLoomEmbed":
      loomHandler.findEmbed(request, sender, sendResponse);
      break;

    case "findVimeoEmbed":
      vimeoHandler.findEmbed(request, sender, sendResponse);
      break;

    case "findYouTubeEmbed":
      youtubeHandler.findEmbed(request, sender, sendResponse);
      break;

    case "findWistiaEmbed":
      wistiaHandler.findEmbed(request, sender, sendResponse);
      break;

    case "findSkoolNativeVideo":
      skoolHandler.findVideo(request, sender, sendResponse);
      break;

    case "getAllSkoolNativeVideos":
      skoolHandler.getAllVideos(request, sender, sendResponse);
      break;

    case "cancelDownload":
      handleCancelDownload(request, sender, sendResponse);
      break;

    case "checkDownloadStatus":
      handleCheckDownloadStatus(request, sender, sendResponse);
      break;

    

    case "testOffscreen":
      handleTestOffscreen(request, sender, sendResponse);
      break;

    // Skool-specific handlers
    case "storeSkoolSegment":
      skoolHandler.storeSegment(request, sender, sendResponse);
      break;

    case "skoolDownloadProgress":
      skoolHandler.handleProgress(request, sender, sendResponse);
      break;

    case "skoolDownloadReadyForProcessing":
      skoolHandler.handleReadyForProcessing(request, sender, sendResponse);
      break;

    case "skoolDownloadFailed":
      skoolHandler.handleDownloadFailed(request, sender, sendResponse);
      break;

    case "initStreamingDownload":
      skoolHandler.initStreamingDownload(request, sender, sendResponse);
      break;

    case "streamSegmentBatch":
      skoolHandler.streamSegmentBatch(request, sender, sendResponse);
      break;

    case "finalizeStreamingDownload":
      skoolHandler.finalizeStreamingDownload(request, sender, sendResponse);
      break;

    case "abortStreamingDownload":
      skoolHandler.abortStreamingDownload(request, sender, sendResponse);
      break;

    case "registerSkoolDownload":
      console.log(`📝 Registering Skool download: ${request.downloadId}`);
      activeDownloadIds.add(request.downloadId);
      activeDownloads++;
      sendResponse({ success: true });
      break;

    case "unregisterSkoolDownload":
      console.log(`📝 Unregistering Skool download: ${request.downloadId} (success: ${request.success})`);
      activeDownloadIds.delete(request.downloadId);
      activeDownloads = Math.max(0, activeDownloads - 1);
      
      // Reset cancellation flag when no downloads are active
      if (activeDownloads === 0) {
        downloadCancelled = false;
        console.log("🔄 Reset downloadCancelled flag - no active downloads");
        // Note: Content script reset is handled when starting new downloads
      }
      
      sendResponse({ success: true });
      break;

    case "loadThumbnailProxy":
      handleThumbnailProxy(request, sender, sendResponse);
      break;

    case "saveDOM":
      handleSaveDOM(request, sender, sendResponse);
      break;

    default:
      handleFireAndForgetMessages(request, sender, sendResponse);
  }
}

// =================================================================================
// CORE HANDLERS
// =================================================================================

async function handleDetectVideo(request, sender, sendResponse) {
  console.log("🎬 Processing detectVideoOnCurrentTab request");
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    if (!tab || !tab.url) {
      if (sendResponse) {
        sendResponse({ success: false, error: "No active tab found." });
      }
      return;
    }

    let videoInfo = null;

    // Check for direct, official pages first
    if (tab.url.includes("loom.com/share/")) {
      videoInfo = await loomHandler.extractInfo(tab.url);
    } else if (tab.url.includes("vimeo.com/")) {
      videoInfo = await vimeoHandler.extractInfo(tab.url);
    } else if (
      tab.url.includes("wistia.com") ||
      tab.url.includes("wistia.net")
    ) {
      videoInfo = await wistiaHandler.extractInfo(tab.url);
    } else {
      // Ask content script to check for embeds
      console.log("Asking content script to check for embeds...");
      const response = await chrome.tabs
        .sendMessage(tab.id, { action: "getVideoInfo" })
        .catch((err) => {
          console.warn(
            "Could not communicate with content script on this page.",
            err
          );
          return null;
        });

      if (response && response.success) {
        videoInfo = response.videoInfo;
      }
    }

    if (videoInfo) {
      if (sendResponse) {
        sendResponse({ success: true, videoInfo: videoInfo });
      }
    } else {
      if (sendResponse) {
        sendResponse({
          success: false,
          error: "No compatible video found on this page.",
        });
      }
    }
  } catch (error) {
    console.error("Error during video detection:", error);
    if (sendResponse) {
      sendResponse({ success: false, error: error.message });
    }
  }
}

async function handleExtractVideoInfo(request, sender, sendResponse) {
  console.log("🎬 Processing extractVideoInfo request");

  // Route to appropriate handler based on URL
  if (request.url.includes("youtube.com") || request.url.includes("youtu.be")) {
    youtubeHandler.extractVideoInfo(request, sender, sendResponse);
  } else if (
    request.url.includes("wistia.com") ||
    request.url.includes("wistia.net")
  ) {
    wistiaHandler.extractVideoInfo(request, sender, sendResponse);
  } else if (request.url.includes("loom.com")) {
    loomHandler.extractVideoInfo(request, sender, sendResponse);
  } else {
    // Default to Vimeo for other URLs
    vimeoHandler.extractVideoInfo(request, sender, sendResponse);
  }
}

async function handleDownloadVideo(request, sender, sendResponse) {
  console.log("⬇️ Processing downloadVideo request");
  // console.log("🔍 Request structure:", {
  //   hasVideoInfo: !!request.videoInfo,
  //   hasEmbedInfo: !!request.embedInfo,
  //   videoInfoPlatform: request.videoInfo?.platform,
  //   embedInfoPlatform: request.embedInfo?.platform,
  //   url: request.url,
  // });

  if (downloadCancelled) downloadCancelled = false;

  // Route to appropriate handler based on platform or URL
  let downloadPromise;

  // 🚨 FIX: Check for platform in videoInfo AND embedInfo - prioritize videoInfo
  const videoInfo = request.videoInfo;
  const embedInfo = request.embedInfo;

  // 🚨 CRITICAL FIX: Force platform detection based on URL FIRST - URL is the source of truth
  let platform = null;
  let platformInfo = videoInfo || embedInfo;

  if (request.url) {
    if (request.url.includes("loom.com")) {
      platform = "Loom";
      console.log("🎬 🚨 URL-based platform detection: LOOM from URL (URL is source of truth)");
    } else if (request.url.includes("vimeo.com")) {
      platform = "Vimeo";
      console.log("🎬 🚨 URL-based platform detection: VIMEO from URL (URL is source of truth)");
    } else if (
      request.url.includes("youtube.com") ||
      request.url.includes("youtu.be")
    ) {
      platform = "YouTube";
      console.log("🎬 🚨 URL-based platform detection: YOUTUBE from URL (URL is source of truth)");
    } else if (request.url.includes("wistia.com")) {
      platform = "Wistia";
      console.log("🎬 🚨 URL-based platform detection: WISTIA from URL (URL is source of truth)");
    }
  }
  
  // Only fall back to videoInfo/embedInfo if URL didn't give us a platform
  if (!platform) {
    platform = videoInfo?.platform || embedInfo?.platform;
    console.log("🎬 Fallback to videoInfo/embedInfo platform:", platform);
  }

  console.log("🎯 Platform detection:", {
    platformInfo: !!platformInfo,
    platform: platform,
    videoInfoPlatform: videoInfo?.platform,
    embedInfoPlatform: embedInfo?.platform,
    source: videoInfo?.platform
      ? "videoInfo"
      : embedInfo?.platform
      ? "embedInfo"
      : "url",
    url: request.url,
  });

  if (platform) {
    switch (platform.toLowerCase()) {
      case "loom":
        console.log("🎬 Routing to Loom handler");
        downloadPromise = loomHandler.downloadVideo(
          request.url,
          request.password
        );
        break;
      case "youtube":
        console.log("🎯 Routing to YouTube handler");
        downloadPromise = youtubeHandler.downloadVideo(
          request.url,
          platformInfo
        );
        break;
      case "wistia":
        console.log("🎯 Routing to Wistia handler");
        downloadPromise = wistiaHandler.downloadVideo(
          request.url,
          platformInfo,
          request.selectedQualityIndex
        );
        break;
      case "skool":
        // 🚨 IMPORTANT: Only route to Skool handler for ACTUAL Skool native videos
        console.log("🎓 Routing to Skool handler (native Skool video)");
        downloadPromise = skoolHandler.downloadVideo(platformInfo);
        break;
      case "vimeo":
      default:
        console.log("🎯 Routing to Vimeo handler (default)");
        downloadPromise = vimeoHandler.downloadVideo(
          request.url,
          platformInfo,
          request.selectedQualityIndex
        );
        break;
    }
  } else {
    // Fallback to URL-based detection ONLY if no platform is detected
    console.log("⚠️ No platform detected, using URL-based fallback routing");
    if (request.url && request.url.includes("loom.com")) {
      console.log("🎬 URL-based routing to Loom handler");
      downloadPromise = loomHandler.downloadVideo(
        request.url,
        request.password
      );
    } else if (
      request.url &&
      (request.url.includes("youtube.com") || request.url.includes("youtu.be"))
    ) {
      console.log("🎯 URL-based routing to YouTube handler");
      downloadPromise = youtubeHandler.downloadVideo(request.url, platformInfo);
    } else if (
      request.url &&
      (request.url.includes("wistia.com") || request.url.includes("wistia.net"))
    ) {
      console.log("🎯 URL-based routing to Wistia handler");
      downloadPromise = wistiaHandler.downloadVideo(
        request.url,
        platformInfo,
        request.selectedQualityIndex
      );
    } else if (
      request.url &&
      (request.url.includes("skool.com") ||
        request.url.includes("video.skool.com"))
    ) {
      console.log("🎓 URL-based routing to Skool handler");
      downloadPromise = skoolHandler.downloadVideo(platformInfo);
    } else {
      console.log("🎯 URL-based routing to Vimeo handler (default)");
      downloadPromise = vimeoHandler.downloadVideo(
        request.url,
        platformInfo,
        request.selectedQualityIndex
      );
    }
  }

  downloadPromise
    .then(() => {
      console.log("✅ Download completed successfully");
      if (sendResponse) {
        sendResponse({
          success: true,
          message: "Download process initiated.",
        });
      }
    })
    .catch((error) => {
      console.error("❌ Error in downloadVideo:", error);
      sendDownloadError(error.message);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    });
}

async function handleCancelDownload(request, sender, sendResponse) {
  console.log("❌ Processing cancelDownload request");
  console.log(
    `📊 Current state: activeDownloads=${activeDownloads}, activeDownloadIds=${Array.from(
      activeDownloadIds
    )}`
  );

  try {
    if (activeDownloads > 0 || activeDownloadIds.size > 0) {
      downloadCancelled = true;
      console.log("✅ Download cancellation set for active downloads");

      const hasHLSDownloads = Array.from(activeDownloadIds).some((id) =>
        String(id).startsWith("hls_")
      );
      const hasSkoolDownloads = Array.from(activeDownloadIds).some((id) =>
        String(id).startsWith("skool_")
      );

      for (const downloadId of activeDownloadIds) {
        if (String(downloadId).startsWith("hls_")) {
          console.log(`🚫 Cancelling HLS download: ${downloadId}`);
          downloadCancelled = true;
        } else if (String(downloadId).startsWith("skool_")) {
          console.log(`🚫 Cancelling Skool download: ${downloadId}`);
          downloadCancelled = true;
          // Notify content script to cancel Skool downloads
          try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab) {
              chrome.tabs.sendMessage(tab.id, {
                action: "cancelSkoolDownload",
                downloadId: downloadId
              });
            }
          } catch (e) {
            console.warn("Failed to notify content script of Skool cancellation:", e);
          }
        } else {
          chrome.downloads.cancel(downloadId, () => {
            if (chrome.runtime.lastError) {
              console.log(
                `⚠️ Could not cancel download ${downloadId}: ${chrome.runtime.lastError.message}`
              );
            } else {
              console.log(`🚫 Cancelled Chrome download: ${downloadId}`);
            }
          });
        }
      }

      if (!hasHLSDownloads && !hasSkoolDownloads) {
        activeDownloads = 0;
        activeDownloadIds.clear();
      }

      sendDownloadCancelled("Download cancelled by user");

      if (sendResponse) {
        sendResponse({
          success: true,
          message: "Download cancellation requested",
        });
      }
    } else {
      console.log("⚠️ No active downloads to cancel");
      if (sendResponse) {
        sendResponse({
          success: false,
          message: "No active downloads to cancel",
        });
      }
    }
  } catch (error) {
    console.error("❌ Error in cancelDownload:", error);
    if (sendResponse) {
      sendResponse({
        success: false,
        error: `Cancel failed: ${error.message}`,
      });
    }
  }
}

function handleCheckDownloadStatus(request, sender, sendResponse) {

  const isDownloadActive = activeDownloads > 0 || activeDownloadIds.size > 0;


  if (sendResponse) {
    sendResponse({
      success: true,
      inProgress: isDownloadActive && !downloadCancelled,
      activeCount: activeDownloads,
      activeIds: Array.from(activeDownloadIds),
      progress: currentDownloadProgress,
      cancelled: downloadCancelled,
    });
  }
}

async function handleTestOffscreen(request, sender, sendResponse) {
  console.log("🧪 Processing testOffscreen request");
  try {
    await createOffscreenDocument();

    const testId = Math.random().toString(36).substring(7);

    const testResult = await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error("Offscreen document test timed out"));
      }, 5000);

      const listener = (message) => {
        if (message.type === "PONG" && message.testId === testId) {
          clearTimeout(timeout);
          chrome.runtime.onMessage.removeListener(listener);
          resolve(true);
        }
      };

      chrome.runtime.onMessage.addListener(listener);
      chrome.runtime.sendMessage({ type: "PING", testId: testId });
    });

    if (sendResponse) {
      sendResponse({ success: true, message: "Offscreen test passed!" });
    }
  } catch (error) {
    if (sendResponse) {
      sendResponse({ success: false, error: error.message });
    }
  }
}

function handleSaveDOM(request, sender, sendResponse) {
  try {
    const { domContent } = request;
    const blob = new Blob([domContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: url,
      filename: "dom.txt",
      saveAs: false,
    });
  } catch (e) {
    console.error("Error saving DOM", e);
  }
}

function handleFireAndForgetMessages(request, sender, sendResponse) {
  switch (request.type) {
    case "MERGE_COMPLETE":
      console.log(
        `✅ Merge complete for request: ${request.requestId}, cleaning up...`
      );
      sendDownloadComplete("Processing complete!");
      break;
    case "OFFSCREEN_DOCUMENT_READY":
      console.log("✅ Offscreen document is ready.");
      break;
    case "OFFSCREEN_ERROR":
      console.log("❌ Offscreen document error received.");
      break;
    case "DEBUG_MESSAGE":
      console.log(`🔍 OFFSCREEN DEBUG: ${request.message}`);
      break;
    case "DOWNLOAD_PROCESSED_FILE":
      console.log(
        `📥 Processing download request: ${request.fileName} (${(
          request.size /
          1024 /
          1024
        ).toFixed(2)} MB)`
      );
      try {
        chrome.downloads.download(
          {
            url: request.blobUrl,
            filename: request.fileName,
            saveAs: true,
          },
          (downloadId) => {
            if (chrome.runtime.lastError) {
              console.error("❌ Download error:", chrome.runtime.lastError);
              sendDownloadError("Failed to save the final file.");
            } else {
              console.log(`✅ Download started with ID: ${downloadId}`);
              sendDownloadComplete("Download completed!");
              setTimeout(() => {
                try {
                  URL.revokeObjectURL(request.blobUrl);
                  console.log(
                    `🧹 Revoked blob URL for download: ${downloadId}`
                  );
                } catch (error) {
                  console.log(`⚠️ Could not revoke blob URL: ${downloadId}`);
                }
              }, 10000);
            }
            activeDownloads = Math.max(0, activeDownloads - 1);
            // Don't close offscreen here - wait for actual download completion
          }
        );
      } catch (error) {
        console.error("❌ Error initiating download:", error);
      }
      break;
    case "videoDetected":
      console.log("🎥 Video detected:", request.videoInfo);
      chrome.storage.local.set({
        detectedVideo: {
          ...request.videoInfo,
          timestamp: Date.now(),
        },
      });
      break;
    case "PONG":
      console.log(`✅ Received PONG with testId: ${request.testId}`);
      break;
    case "DOWNLOAD_COMPLETE":
      console.log("✅ Download completion notification received:", request.fileName || "unknown");
      // Check if this is actually a processed file that needs downloading
      if (request.blobUrl && request.fileName) {
        console.log(
          `📥 Processing download request: ${request.fileName} (${(
            (request.size || 0) /
            1024 /
            1024
          ).toFixed(2)} MB)`
        );
        try {
          chrome.downloads.download(
            {
              url: request.blobUrl,
              filename: request.fileName,
              saveAs: true,
            },
            (downloadId) => {
              if (chrome.runtime.lastError) {
                console.error("❌ Download error:", chrome.runtime.lastError);
                sendDownloadError("Failed to save the final file.");
              } else {
                console.log(`✅ Download started with ID: ${downloadId}`);
                // Don't decrement activeDownloads here - wait for download completion
                console.log(`📊 Active downloads: ${activeDownloads} (Chrome download in progress)`);
                setTimeout(() => {
                  try {
                    URL.revokeObjectURL(request.blobUrl);
                    console.log(
                      `🧹 Revoked blob URL for download: ${downloadId}`
                    );
                  } catch (error) {
                    console.log(`⚠️ Could not revoke blob URL: ${downloadId}`);
                  }
                }, 10000);
              }
            }
          );
        } catch (error) {
          console.error("❌ Error initiating download:", error);
        }
      } else {
        // Regular completion notification
        activeDownloads--;
              sendDownloadComplete(`Download completed: ${request.fileName || "unknown"}`);
      }
      break;
    case "DOWNLOAD_COMPLETE_NOTIFICATION":
      console.log("✅ Download completion notification received:", request.fileName);
      activeDownloads--;
          sendDownloadComplete(`Download completed: ${request.fileName}`);
      break;
    case "MERGE_SEPARATE_AV_RESPONSE":
      console.log("✅ DASH stream merge completed:", request.requestId);
      activeDownloads = Math.max(0, activeDownloads - 1);
          sendDownloadComplete("Download completed!");
      break;
    case "MERGE_SEGMENTS_RESPONSE":
      console.log("✅ HLS segments merge completed:", request.requestId);
      activeDownloads = Math.max(0, activeDownloads - 1);
          sendDownloadComplete("Download completed!");
      break;
    default:
      if (request.action) {
        console.warn("❓ Unknown action received:", request.action);
        if (sendResponse) {
          sendResponse({
            success: false,
            error: `Unknown action: ${request.action}`,
          });
        }
      } else {
        console.warn("⚠️ Unhandled message:", request);
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "Unhandled message type",
          });
        }
      }
  }
}

// =================================================================================
// DOWNLOAD LISTENERS
// =================================================================================

chrome.downloads.onChanged.addListener((downloadDelta) => {
  if (activeDownloadIds.has(downloadDelta.id) && downloadDelta.state) {
    if (
      downloadDelta.state.current === "complete" ||
      downloadDelta.state.current === "interrupted"
    ) {
      activeDownloadIds.delete(downloadDelta.id);
      if (activeDownloads > 0) activeDownloads--;
      console.log(`📊 Download finished. Active downloads: ${activeDownloads}`);

      if (activeDownloads === 0) {
        // Close offscreen after a delay to ensure download completes
        setTimeout(() => {
          closeOffscreenDocument();
        }, 2000);
      }

      if (
        downloadDelta.state.current === "complete" &&
        !currentDownloadProgress.status.includes("Processing")
      ) {
        sendDownloadComplete();
      }
    }
  }

  if (downloadDelta.state && downloadDelta.state.current === "complete") {
    console.log(`📥 Download completed: ${downloadDelta.id}`);
    // Decrement activeDownloads when Chrome download actually completes
    if (activeDownloads > 0) {
      activeDownloads--;
      console.log(`📊 Chrome download completed, active downloads: ${activeDownloads}`);
      sendDownloadComplete("Download completed!");
      
      // Close offscreen if no more downloads
      if (activeDownloads === 0) {
        setTimeout(() => {
          closeOffscreenDocument();
        }, 1000);
      }
    }
  }

  if (downloadDelta.state && downloadDelta.state.current === "interrupted") {
    console.log(`❌ Download interrupted: ${downloadDelta.id}`);
    // Decrement activeDownloads when download is interrupted
    if (activeDownloads > 0) {
      activeDownloads--;
      console.log(`📊 Chrome download interrupted, active downloads: ${activeDownloads}`);
      
      // Close offscreen if no more downloads
      if (activeDownloads === 0) {
        setTimeout(() => {
          closeOffscreenDocument();
        }, 1000);
      }
    }
    
    chrome.downloads.search({ id: downloadDelta.id }, (downloads) => {
      if (downloads.length > 0) {
        const download = downloads[0];
        console.log(`❌ Download interruption details:`, {
          id: download.id,
          filename: download.filename,
          url: download.url,
          error: download.error,
          state: download.state,
          bytesReceived: download.bytesReceived,
          totalBytes: download.totalBytes,
        });
      }
    });
  }

  if (activeDownloads > 0) {
    console.log(
      `⏳ Keeping service worker alive - ${activeDownloads} active downloads`
    );
  }
});

// Clean up offscreen document when extension shuts down
chrome.runtime.onSuspend.addListener(() => {
  console.log("🧹 Extension suspending, cleaning up offscreen document...");
  closeOffscreenDocument().catch(console.error);
});

console.log("✅ Universal background script loaded and listening for events.");
