// =================================================================================================
//
//        UNIFIED POPUP SCRIPT - LOOM & VIMEO EMBEDDED VIDEO DOWNLOADER
//
// =================================================================================================

document.addEventListener("DOMContentLoaded", () => {
  console.log("🚀 Unified popup script loaded and DOM ready");

  // DOM Elements
  const statusDiv = document.getElementById("status");
  const videoInfoDiv = document.getElementById("videoInfo");
  const downloadBtn = document.getElementById("downloadBtn");
  const passwordSection = document.getElementById("passwordSection");
  const passwordInput = document.getElementById("passwordInput");
  const helpBtn = document.getElementById("helpBtn");
  const helpTextDisplay = document.getElementById("helpTextDisplay");
  const mainContent = document.getElementById("mainContent");
  const embedDetected = document.getElementById("embedDetected");
  const qualitySection = document.getElementById("qualitySection");
  const qualitySelect = document.getElementById("qualitySelect");
  const youtubeUrlSection = document.getElementById("youtubeUrlSection");
  const youtubeUrlInput = document.getElementById("youtubeUrl");
  const copyUrlBtn = document.getElementById("copyUrlBtn");
  const ytDlpMacBtn = document.getElementById("ytDlpMacBtn");
  const ytDlpWindowsBtn = document.getElementById("ytDlpWindowsBtn");
  const progressContainer = document.getElementById("progress");
  const progressFill = document.getElementById("progressFill");
  const progressText = document.getElementById("progressText");
  const progressSpeed = document.getElementById("progressSpeed");
  const cancelBtn = document.getElementById("cancelBtn");

  console.log("✅ All DOM elements loaded");

  // State Variables
  let currentVideoInfo = null;
  let downloadInProgress = false;
  let detectedPlatform = null; // 'Loom', 'Vimeo', 'YouTube', 'Wistia', or 'Skool'

  // =================================================================================
  // UTILITY FUNCTIONS
  // =================================================================================

  async function loadThumbnailFromContentScript(url) {
    try {
      console.log("🖼️ Loading thumbnail via content script:", url);

      // Get the active tab to send message to content script
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (!tab) {
        console.error("❌ No active tab found for thumbnail loading");
        throw new Error("No active tab found");
      }

      console.log("🖼️ Sending fetchThumbnail message to tab:", tab.id);
      
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "fetchThumbnail",
        url: url,
      });

      console.log("🖼️ Received response from content script:", response);

      if (response && response.success) {
        console.log("✅ Thumbnail loaded successfully via content script");
        return response.dataUrl;
      } else {
        console.error(
          "❌ Content script thumbnail fetch failed:",
          response ? response.error : "No response received"
        );
        return null;
      }
    } catch (error) {
      console.error("❌ Error loading thumbnail via content script:", error);
      console.error("❌ Error details:", error.message);
      
      // Fallback: Try using background script proxy
      console.log("🖼️ Trying background script proxy as fallback...");
      try {
        const fallbackResponse = await chrome.runtime.sendMessage({
          action: "loadThumbnailProxy",
          url: url,
        });
        
        if (fallbackResponse && fallbackResponse.success) {
          console.log("✅ Thumbnail loaded via background proxy fallback");
          return fallbackResponse.dataUrl;
        }
      } catch (fallbackError) {
        console.error("❌ Background proxy fallback also failed:", fallbackError);
      }
      
      return null;
    }
  }

  function showStatus(message, type = "info") {
    // Clear any previous content
    statusDiv.innerHTML = "";
    statusDiv.className = `status ${type}`;

    // Check if this is the generic "Navigate to..." message
    if (
      message.includes("Navigate to") &&
      message.includes("video page to begin")
    ) {
      // Create text span
      const textSpan = document.createElement("span");
      textSpan.textContent = message;
      statusDiv.appendChild(textSpan);

      // Create refresh button
      const refreshBtn = document.createElement("button");
      refreshBtn.textContent = "🔄 Refresh";
      refreshBtn.className = "refresh-btn";
      refreshBtn.style.marginLeft = "10px";
      refreshBtn.style.padding = "4px 8px";
      refreshBtn.style.fontSize = "12px";
      refreshBtn.style.border = "1px solid #ccc";
      refreshBtn.style.borderRadius = "4px";
      refreshBtn.style.background = "#f5f5f5";
      refreshBtn.style.cursor = "pointer";
      refreshBtn.title = "Try to detect video again";

      // Add click handler to refresh detection
      refreshBtn.addEventListener("click", () => {
        console.log("🔄 Refresh button clicked - retrying video detection");
        showStatus("Checking current page for videos...", "loading");
        checkCurrentTabForVideo();
      });

      statusDiv.appendChild(refreshBtn);
    } else {
      // For other messages, just set text content
      statusDiv.textContent = message;
    }

    console.log(`Status [${type}]: ${message}`);
  }

  function showProgress(percentage, status, speed = "") {
    console.log(`📊 Progress: ${percentage}% - ${status}`);

    downloadInProgress = true;

    // Store download state
    chrome.storage.local.set({
      downloadInProgress: true,
      downloadPercentage: percentage,
      downloadStatus: status,
      downloadSpeed: speed,
    });

    // Show progress container
    progressContainer.classList.remove("hidden");

    // Enable cancel button when showing progress
    cancelBtn.disabled = false;

    // Update progress bar
    progressFill.style.width = `${Math.max(0, Math.min(100, percentage))}%`;

    // Update progress text
    progressText.textContent = `${Math.round(percentage)}%`;

    // Update speed info
    progressSpeed.textContent = speed;

    // Update status
    showStatus(status, percentage >= 100 ? "success" : "loading");
  }

  function hideProgress() {
    console.log("🔲 Hiding progress");
    downloadInProgress = false;

    // Clear download state from storage
    chrome.storage.local.remove([
      "downloadInProgress",
      "downloadPercentage",
      "downloadStatus",
      "downloadSpeed",
    ]);

    // Disable cancel button when hiding progress
    cancelBtn.disabled = true;

    progressContainer.classList.add("hidden");
    progressFill.style.width = "0%";
    progressText.textContent = "0%";
    progressSpeed.textContent = "";
  }

  function populateQualityDropdown(videoInfo) {
    console.log("🔍 populateQualityDropdown called with videoInfo:", videoInfo);

    // Clear existing options
    qualitySelect.innerHTML = "";

    // Get available qualities from files array (mainly for Vimeo)
    const availableQualities = [];

    if (videoInfo.files && Array.isArray(videoInfo.files)) {
      videoInfo.files.forEach((file, index) => {
        // Include files that have either:
        // 1. A rendition property that's not "adaptive"
        // 2. Width/height properties (progressive files)
        // 3. A link/url property (downloadable files)
        const hasRendition = file.rendition && file.rendition !== "adaptive";
        const hasResolution = file.width && file.height;
        const hasDownloadLink = file.link || file.url;

        if (hasRendition || hasResolution || hasDownloadLink) {
          // Determine quality label
          let qualityLabel = "Unknown";
          if (file.rendition) {
            qualityLabel = file.rendition;
          } else if (file.quality) {
            qualityLabel = file.quality;
          } else if (file.width && file.height) {
            qualityLabel = `${file.width}x${file.height}`;
          }

          // Determine size info
          let sizeInfo = "Unknown size";
          if (file.size_short) {
            sizeInfo = file.size_short;
          } else if (file.size) {
            // Convert bytes to MB if needed
            const sizeInMB = Math.round(file.size / (1024 * 1024));
            sizeInfo = `${sizeInMB} MB`;
          }

          availableQualities.push({
            index: index,
            rendition: qualityLabel,
            quality: file.quality || qualityLabel,
            width: file.width || 0,
            height: file.height || 0,
            size_short: sizeInfo,
            fps: file.fps,
            link: file.link || file.url,
          });
        }
      });
    }

    // Sort by resolution (width) in descending order
    availableQualities.sort((a, b) => (b.width || 0) - (a.width || 0));

    console.log("✅ Available qualities after processing:", availableQualities);

    if (availableQualities.length <= 1) {
      // Hide the quality section when no options or only one option is available
      qualitySection.classList.add("hidden");
      console.log("🔍 Hiding quality selection - not enough options");
      return;
    }

    // Add options to dropdown
    availableQualities.forEach((quality) => {
      const option = document.createElement("option");
      option.value = quality.index;
      option.textContent = `${quality.rendition} (${quality.width}x${quality.height}) - ${quality.size_short}`;
      qualitySelect.appendChild(option);
    });

    // Select the highest quality by default
    if (availableQualities.length > 0) {
      qualitySelect.value = availableQualities[0].index;
    }

    qualitySection.classList.remove("hidden");
  }

  function showYouTubeUrlSection(url) {
    console.log("🎯 Showing YouTube URL section with URL:", url);

    if (!url) {
      console.warn("⚠️ No URL provided to YouTube URL section");
      return;
    }

    // Populate the URL input
    youtubeUrlInput.value = url;

    // Show the section
    youtubeUrlSection.classList.remove("hidden");

    console.log("✅ YouTube URL section displayed");
  }

  function hideYouTubeUrlSection() {
    console.log("🎯 Hiding YouTube URL section");
    youtubeUrlSection.classList.add("hidden");
    youtubeUrlInput.value = "";
  }

  function displayVideoInfo(videoInfo) {
    console.log("🎬 displayVideoInfo called with:", videoInfo);
    console.log("🎬 Platform detected:", videoInfo.platform);

    currentVideoInfo = videoInfo;
    detectedPlatform = videoInfo.platform;

    // Update thumbnail
    const thumbnailImg = document.getElementById("videoThumbnail");
    const thumbnailPlaceholder = document.getElementById(
      "thumbnailPlaceholder"
    );

    console.log("🎬 Thumbnail handling - URL:", videoInfo.thumbnail);
    console.log("🎬 Thumbnail handling - Platform:", videoInfo.platform);

    if (videoInfo.thumbnail) {
      console.log(
        "🎬 Loading thumbnail via content script:",
        videoInfo.thumbnail
      );

      // Show placeholder while loading
      thumbnailImg.style.display = "none";
      thumbnailImg.classList.add("hidden");
      thumbnailPlaceholder.style.display = "flex";

      // Load thumbnail via content script to bypass CORS
      loadThumbnailFromContentScript(videoInfo.thumbnail)
        .then((dataUrl) => {
          if (dataUrl) {
            console.log("✅ Thumbnail loaded successfully via content script");
            thumbnailImg.src = dataUrl;
            thumbnailImg.style.display = "block";
            thumbnailImg.classList.remove("hidden");
            thumbnailPlaceholder.style.display = "none";
          } else {
            console.error("❌ Failed to load thumbnail via content script");
            thumbnailImg.style.display = "none";
            thumbnailImg.classList.add("hidden");
            thumbnailPlaceholder.style.display = "flex";
          }
        })
        .catch((error) => {
          console.error("❌ Error loading thumbnail:", error);
          thumbnailImg.style.display = "none";
          thumbnailImg.classList.add("hidden");
          thumbnailPlaceholder.style.display = "flex";
        });
    } else {
      console.log("⚠️ No thumbnail URL provided");
      thumbnailImg.classList.add("hidden");
      thumbnailPlaceholder.style.display = "flex";
    }

    // Update duration badge on thumbnail
    const durationBadge = document.getElementById("durationBadge");
    if (videoInfo.duration) {
      const minutes = Math.floor(videoInfo.duration / 60);
      const seconds = Math.floor(videoInfo.duration % 60);
      durationBadge.textContent = `${minutes}:${seconds
        .toString()
        .padStart(2, "0")}`;
    } else {
      durationBadge.textContent = "";
    }

    // Update video details
    const videoTitle = document.getElementById("videoTitle");
    const videoOwner = document.getElementById("videoOwner");
    const videoResolution = document.getElementById("videoResolution");
    const videoDescription = document.getElementById("videoDescription");

    videoTitle.textContent = videoInfo.title || "Untitled Video";

    // Display owner in metadata
    if (videoInfo.owner) {
      videoOwner.textContent = videoInfo.owner;
    } else {
      videoOwner.textContent = "";
    }

    // Display resolution in metadata
    if (videoInfo.width && videoInfo.height) {
      videoResolution.textContent = `${videoInfo.width}x${videoInfo.height}`;
    } else {
      videoResolution.textContent = "";
    }

    // Display description with automatic truncation (handled by CSS)
    if (videoInfo.description) {
      videoDescription.textContent = videoInfo.description;
      videoDescription.title = videoInfo.description; // Full text on hover
    } else {
      videoDescription.textContent = "";
    }

    console.log("🎬 Making videoInfoDiv visible...");
    videoInfoDiv.classList.remove("hidden");
    videoInfoDiv.style.display = "block";

    // Populate quality dropdown (mainly for Vimeo)
    populateQualityDropdown(videoInfo);

    downloadBtn.disabled = false;
    cancelBtn.disabled = true;
    showStatus(
      `${detectedPlatform} video info extracted. Ready to download.`,
      "success"
    );
  }

  // =================================================================================
  // PLATFORM DETECTION FUNCTIONS
  // =================================================================================

  async function checkForLoomVideo() {
    console.log("🔍 Checking for Loom videos...");

    try {
      // First check for direct Loom URLs
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });

      const currentTab = tabs[0];
      if (
        currentTab?.url &&
        /loom\.com\/(share|embed)\//.test(currentTab.url)
      ) {
        console.log("✅ Direct Loom URL detected:", currentTab.url);
        showStatus("Loom video detected. Extracting info...", "loading");

        try {
          // Try to get thumbnail from page elements first
          const embedResponse = await chrome.runtime.sendMessage({
            action: "findLoomEmbed",
          });

          // Extract video info from API
          const response = await chrome.runtime.sendMessage({
            action: "extractVideoInfo",
            url: currentTab.url,
            password: null,
          });

          if (response?.success && response.videoInfo) {
            console.log("✅ Loom video info extracted:", response.videoInfo);

            // Enrich with thumbnail from DOM if available
            const enrichedVideoInfo = {
              ...response.videoInfo,
              platform: "Loom",
              thumbnail:
                embedResponse?.embedInfo?.thumbnail ||
                response.videoInfo.thumbnail,
            };

            displayVideoInfo(enrichedVideoInfo);
            return true;
          } else {
            console.warn(
              "⚠️ Failed to extract Loom video info:",
              response?.error
            );
            if (response?.error?.includes("password-protected")) {
              passwordSection.classList.remove("hidden");
              passwordInput.focus();
              showStatus(
                "This Loom video is password-protected. Please provide the password.",
                "error"
              );
              return true; // Still found a video, just needs password
            }
          }
        } catch (error) {
          console.error("❌ Error extracting Loom video info:", error);
        }
      }

      // Check for Loom embeds on third-party sites
      const embedResponse = await chrome.runtime.sendMessage({
        action: "findLoomEmbed",
      });

      if (embedResponse?.success && embedResponse.embedInfo) {
        console.log("✅ Loom embed found:", embedResponse.embedInfo);

        // Show embed detected section
        embedDetected.classList.remove("hidden");
        const embedText = document.querySelector(".embed-text");
        if (embedText) {
          embedText.textContent = "Loom embed detected on this page!";
        }

        // Try to get video info for the embed
        try {
          const shareUrl = `https://www.loom.com/share/${embedResponse.embedInfo.videoId}`;
          const videoInfoResponse = await chrome.runtime.sendMessage({
            action: "extractVideoInfo",
            url: shareUrl,
            password: null,
          });

          if (videoInfoResponse?.success) {
            const enrichedVideoInfo = {
              ...videoInfoResponse.videoInfo,
              platform: "Loom",
              thumbnail:
                embedResponse.embedInfo.thumbnail ||
                videoInfoResponse.videoInfo.thumbnail,
            };
            displayVideoInfo(enrichedVideoInfo);
            hideYouTubeUrlSection(); // Hide YouTube section for Loom videos
          } else {
            // Still show as detected even if we can't get full info
            showStatus("Loom embed detected! Ready to download.", "success");
            downloadBtn.disabled = false;
            hideYouTubeUrlSection(); // Hide YouTube section for Loom videos
          }
        } catch (error) {
          console.warn("⚠️ Could not get detailed info for Loom embed:", error);
          showStatus("Loom embed detected! Ready to download.", "success");
          downloadBtn.disabled = false;
          hideYouTubeUrlSection(); // Hide YouTube section for Loom videos
        }

        return true;
      }

      return false;
    } catch (error) {
      console.error("❌ Error checking for Loom videos:", error);
      return false;
    }
  }

  async function checkForVimeoVideo() {
    console.log("🔍 Checking for Vimeo videos...");

    try {
      // First check for direct Vimeo URLs
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });

      const currentTab = tabs[0];
      if (
        currentTab?.url &&
        /vimeo\.com\/(?:channels\/[^/]+\/|groups\/[^/]+\/|album\/\d+\/|video\/|ondemand\/|user[^/]+\/review\/|event\/)*(?:\d+\/)*\d+/.test(
          currentTab.url
        )
      ) {
        console.log("✅ Direct Vimeo URL detected:", currentTab.url);
        showStatus("Vimeo video detected. Extracting info...", "loading");

        try {
          const response = await chrome.runtime.sendMessage({
            action: "getVideoInfo",
            url: currentTab.url,
            password: null,
          });

          if (response?.success && response.videoInfo) {
            console.log("✅ Vimeo video info extracted:", response.videoInfo);

            const enrichedVideoInfo = {
              ...response.videoInfo,
              platform: "Vimeo",
            };

            displayVideoInfo(enrichedVideoInfo);
            hideYouTubeUrlSection(); // Hide YouTube section for Vimeo videos
            return true;
          } else {
            console.warn(
              "⚠️ Failed to extract Vimeo video info:",
              response?.error
            );
            if (response?.error?.includes("password-protected")) {
              passwordSection.classList.remove("hidden");
              passwordInput.focus();
              showStatus(
                "This Vimeo video is password-protected. Please provide the password.",
                "error"
              );
              return true;
            }
          }
        } catch (error) {
          console.error("❌ Error extracting Vimeo video info:", error);
        }
      }

      // Check for Vimeo embeds on third-party sites
      const embedResponse = await chrome.runtime.sendMessage({
        action: "findVimeoEmbed",
      });

      if (embedResponse?.success && embedResponse.embedInfo) {
        console.log("✅ Vimeo embed found:", embedResponse.embedInfo);

        // Show embed detected section
        embedDetected.classList.remove("hidden");
        const embedText = document.querySelector(".embed-text");
        if (embedText) {
          embedText.textContent = "Vimeo embed detected on this page!";
        }

        if (embedResponse.videoInfo) {
          const enrichedVideoInfo = {
            ...embedResponse.videoInfo,
            platform: "Vimeo",
          };
          displayVideoInfo(enrichedVideoInfo);
          hideYouTubeUrlSection(); // Hide YouTube section for Vimeo videos
        } else {
          showStatus("Vimeo embed detected! Ready to download.", "success");
          downloadBtn.disabled = false;
          hideYouTubeUrlSection(); // Hide YouTube section for Vimeo videos
        }

        return true;
      }

      return false;
    } catch (error) {
      console.error("❌ Error checking for Vimeo videos:", error);
      return false;
    }
  }

  async function checkForYouTubeVideo() {
    console.log("🎯 Checking for YouTube videos...");

    try {
      // First check for direct YouTube URLs
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });

      const currentTab = tabs[0];
      if (
        currentTab?.url &&
        (currentTab.url.includes("youtube.com/watch") ||
          currentTab.url.includes("youtu.be/") ||
          currentTab.url.includes("youtube.com/embed") ||
          currentTab.url.includes("youtube.com/shorts"))
      ) {
        console.log("✅ Direct YouTube URL detected:", currentTab.url);
        showStatus("YouTube video detected. Extracting info...", "loading");

        try {
          const response = await chrome.runtime.sendMessage({
            action: "extractVideoInfo",
            url: currentTab.url,
          });

          if (response?.success && response.videoInfo) {
            console.log("✅ YouTube video info extracted:", response.videoInfo);

            const enrichedVideoInfo = {
              ...response.videoInfo,
              platform: "YouTube",
              isYouTubeVideo: true,
            };

            displayVideoInfo(enrichedVideoInfo);

            // Show YouTube URL section
            showYouTubeUrlSection(enrichedVideoInfo.url || currentTab.url);

            // Show special message for YouTube
            showStatus(
              "YouTube video info displayed. Use the original YouTube URL to access the video.",
              "info"
            );

            // Disable download button since we don't download YouTube videos
            downloadBtn.disabled = true;
            const downloadBtnText = downloadBtn.querySelector(".btn-text");
            if (downloadBtnText) {
              downloadBtnText.textContent = "View on YouTube";
            }

            return true;
          } else {
            console.warn(
              "⚠️ Failed to extract YouTube video info:",
              response?.error
            );
          }
        } catch (error) {
          console.error("❌ Error extracting YouTube video info:", error);
        }
      }

      // Check for YouTube embeds on third-party sites
      const embedResponse = await chrome.runtime.sendMessage({
        action: "findYouTubeEmbed",
      });

      if (embedResponse?.success && embedResponse.embedInfo) {
        console.log("✅ YouTube embed found:", embedResponse.embedInfo);

        // Show embed detected section
        embedDetected.classList.remove("hidden");
        const embedText = document.querySelector(".embed-text");
        if (embedText) {
          embedText.textContent = "YouTube embed detected on this page!";
        }

        if (embedResponse.videoInfo) {
          const enrichedVideoInfo = {
            ...embedResponse.videoInfo,
            platform: "YouTube",
            isYouTubeVideo: true,
          };
          displayVideoInfo(enrichedVideoInfo);

          // Show YouTube URL section
          showYouTubeUrlSection(enrichedVideoInfo.url);

          // Show special message for YouTube
          showStatus(
            "YouTube video info displayed. Use the original YouTube URL to access the video.",
            "info"
          );

          // Disable download button since we don't download YouTube videos
          downloadBtn.disabled = true;
          const downloadBtnText = downloadBtn.querySelector(".btn-text");
          if (downloadBtnText) {
            downloadBtnText.textContent = "View on YouTube";
          }
        } else {
          // Show YouTube URL section even without full video info
          const youtubeUrl =
            embedResponse.embedInfo?.url ||
            `https://www.youtube.com/watch?v=${embedResponse.embedInfo?.videoId}`;
          showYouTubeUrlSection(youtubeUrl);

          showStatus(
            "YouTube embed detected! Use the original YouTube URL to access the video.",
            "info"
          );
          downloadBtn.disabled = true;
          const downloadBtnText = downloadBtn.querySelector(".btn-text");
          if (downloadBtnText) {
            downloadBtnText.textContent = "View on YouTube";
          }
        }

        return true;
      }

      return false;
    } catch (error) {
      console.error("❌ Error checking for YouTube videos:", error);
      return false;
    }
  }

  async function checkForWistiaVideo() {
    console.log("🎯 Checking for Wistia videos...");

    try {
      // First check for direct Wistia URLs
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });

      const currentTab = tabs[0];
      if (
        currentTab?.url &&
        (currentTab.url.includes("wistia.com") ||
          currentTab.url.includes("wistia.net"))
      ) {
        console.log("✅ Direct Wistia URL detected:", currentTab.url);
        showStatus("Wistia video detected. Extracting info...", "loading");

        try {
          const response = await chrome.runtime.sendMessage({
            action: "extractVideoInfo",
            url: currentTab.url,
          });

          if (response?.success && response.videoInfo) {
            console.log("✅ Wistia video info extracted:", response.videoInfo);

            const enrichedVideoInfo = {
              ...response.videoInfo,
              platform: "Wistia",
              isWistiaVideo: true,
            };

            displayVideoInfo(enrichedVideoInfo);
            detectedPlatform = "Wistia";
            currentVideoInfo = enrichedVideoInfo;

            showStatus(
              "Wistia video detected and ready for download!",
              "success"
            );

            // Enable download button for Wistia videos
            downloadBtn.disabled = false;
            const downloadBtnText = downloadBtn.querySelector(".btn-text");
            if (downloadBtnText) {
              downloadBtnText.textContent = "Download Video";
            }

            return true;
          } else {
            console.warn(
              "⚠️ Failed to extract Wistia video info:",
              response?.error
            );
          }
        } catch (error) {
          console.error("❌ Error extracting Wistia video info:", error);
        }
      }

      // Check for Wistia embeds on third-party sites
      const embedResponse = await chrome.runtime.sendMessage({
        action: "findWistiaEmbed",
      });

      if (embedResponse?.success && embedResponse.embedInfo) {
        console.log("✅ Wistia embed found:", embedResponse.embedInfo);

        // Show embed detected section
        embedDetected.classList.remove("hidden");
        const embedText = document.querySelector(".embed-text");
        if (embedText) {
          embedText.textContent = "Wistia embed detected on this page!";
        }

        if (embedResponse.videoInfo) {
          const enrichedVideoInfo = {
            ...embedResponse.videoInfo,
            platform: "Wistia",
            isWistiaVideo: true,
          };

          displayVideoInfo(enrichedVideoInfo);
          detectedPlatform = "Wistia";
          currentVideoInfo = enrichedVideoInfo;

          showStatus(
            "Wistia video detected and ready for download!",
            "success"
          );

          // Enable download button for Wistia videos
          downloadBtn.disabled = false;
          const downloadBtnText = downloadBtn.querySelector(".btn-text");
          if (downloadBtnText) {
            downloadBtnText.textContent = "Download Video";
          }
        } else {
          // Basic embed info without full video details
          const basicVideoInfo = {
            ...embedResponse.embedInfo,
            platform: "Wistia",
            isWistiaVideo: true,
          };

          displayVideoInfo(basicVideoInfo);
          detectedPlatform = "Wistia";
          currentVideoInfo = basicVideoInfo;

          showStatus(
            "Wistia embed detected and ready for download!",
            "success"
          );

          downloadBtn.disabled = false;
          const downloadBtnText = downloadBtn.querySelector(".btn-text");
          if (downloadBtnText) {
            downloadBtnText.textContent = "Download Video";
          }
        }

        return true;
      }

      return false;
    } catch (error) {
      console.error("❌ Error checking for Wistia videos:", error);
      return false;
    }
  }

  async function checkForSkoolVideo() {
    console.log("🎓 Checking for Skool videos...");

    try {
      // First check for direct Skool URLs
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });

      const currentTab = tabs[0];
      if (currentTab?.url && currentTab.url.includes("skool.com")) {
        console.log("✅ Skool page detected:", currentTab.url);
        showStatus("Checking for Skool native videos...", "loading");

        try {
          // Check for Skool native videos
          console.log("🎓 Popup: Sending findSkoolNativeVideo request...");
          const embedResponse = await chrome.runtime.sendMessage({
            action: "findSkoolNativeVideo",
          });

          console.log("🎓 Popup: Received response:", embedResponse);
          console.log("🎓 Popup: Response type:", typeof embedResponse);
          console.log("🎓 Popup: Response success:", embedResponse?.success);
          console.log(
            "🎓 Popup: Response embedInfo:",
            embedResponse?.embedInfo
          );

          if (embedResponse?.success && embedResponse.embedInfo) {
            console.log(
              "✅ Skool native video detected:",
              embedResponse.embedInfo
            );

            const enrichedVideoInfo = {
              ...embedResponse.embedInfo,
              platform: "Skool",
            };

            console.log(
              "🎓 Popup: About to display video info:",
              enrichedVideoInfo
            );
            displayVideoInfo(enrichedVideoInfo);
            return true;
          } else {
            console.log("ℹ️ No Skool native video found on this page");
            console.log(
              "🎓 Popup: Response was not successful or missing embedInfo"
            );
          }
        } catch (error) {
          console.error("❌ Error checking for Skool embed:", error);
        }
      }

      return false;
    } catch (error) {
      console.error("❌ Error checking for Skool videos:", error);
      return false;
    }
  }

  let videoDetectionTimeout = null;
  
  async function checkCurrentTabForVideo() {
    // Don't run video detection if download is in progress
    if (downloadInProgress) {
      console.log("⚠️ Download in progress, skipping video detection");
      return;
    }
    
    // Clear any pending video detection to prevent double calls
    if (videoDetectionTimeout) {
      clearTimeout(videoDetectionTimeout);
      videoDetectionTimeout = null;
      console.log("🔄 Cancelled pending video detection to prevent duplicate");
    }
    // Check for Skool LAST (only for true native videos)

    console.log("🔍 Checking current tab for videos...");

    const foundLoom = await checkForLoomVideo();
    if (foundLoom) return;

    const foundVimeo = await checkForVimeoVideo();
    if (foundVimeo) return;

    const foundYouTube = await checkForYouTubeVideo();
    if (foundYouTube) return;

    const foundWistia = await checkForWistiaVideo();
    if (foundWistia) return;

    const foundSkool = await checkForSkoolVideo();
    if (foundSkool) return;

    // No videos found
    console.log("ℹ️ No supported videos detected on current page");
    embedDetected.classList.add("hidden");
    hideYouTubeUrlSection(); // Hide YouTube section when no videos found
    showStatus(
      "Navigate to a Loom, Vimeo, YouTube, Wistia, or Skool video page to begin. Remember to press play to detect video.",
      "info"
    );
  }

  // =================================================================================
  // DOWNLOAD FUNCTIONS
  // =================================================================================

  async function handleDownload() {
    console.log("⬇️ handleDownload called");

    if (!currentVideoInfo) {
      console.error("❌ No video info available for download");
      showStatus(
        "No video information available. Please navigate to a supported video page first.",
        "error"
      );
      return;
    }

    // Handle YouTube videos specially - redirect to YouTube instead of downloading
    if (
      currentVideoInfo.platform === "YouTube" ||
      currentVideoInfo.isYouTubeVideo
    ) {
      console.log("🎯 Redirecting to YouTube video");
      const youtubeUrl =
        currentVideoInfo.url ||
        `https://www.youtube.com/watch?v=${currentVideoInfo.id}`;

      try {
        // Open YouTube video in new tab
        await chrome.tabs.create({ url: youtubeUrl });
        showStatus("Opened YouTube video in new tab", "success");
      } catch (error) {
        console.error("❌ Failed to open YouTube tab:", error);
        // Fallback: copy URL to clipboard
        navigator.clipboard
          .writeText(youtubeUrl)
          .then(() => {
            showStatus("YouTube URL copied to clipboard", "success");
          })
          .catch(() => {
            showStatus(`YouTube URL: ${youtubeUrl}`, "info");
          });
      }
      return;
    }

    // Wistia videos can be downloaded normally (no special handling needed)

    const password = passwordInput ? passwordInput.value : null;
    const url = currentVideoInfo?.url || currentVideoInfo?.pageUrl;
    const selectedQualityIndex = qualitySelect.value;

    console.log("📤 Starting download with:", {
      platform: detectedPlatform,
      url,
      password: password ? "***" : null,
      selectedQualityIndex,
    });

    showStatus("Initiating download...", "loading");
    downloadBtn.disabled = true;
    cancelBtn.disabled = false;

    try {
      console.log("📤 Sending downloadVideo message to background");

      // Use platform-specific download actions
      let action = "downloadVideo";
      if (
        detectedPlatform === "Loom" &&
        currentVideoInfo.source === "iframe_embed"
      ) {
        action = "downloadLoomEmbed";
      } else if (
        detectedPlatform === "Vimeo" &&
        currentVideoInfo.source === "iframe_embed"
      ) {
        action = "downloadVimeoEmbed";
      }

      const response = await chrome.runtime.sendMessage({
        action: action,
        url: url,
        password: password,
        videoInfo: currentVideoInfo,
        embedInfo: currentVideoInfo, // For embed downloads
        selectedQualityIndex: selectedQualityIndex,
      });

      console.log("📥 Received download response from background:", response);

      if (response && response.success) {
        console.log("✅ Download started successfully");
        showStatus(
          response.message || "Download started successfully!",
          "success"
        );
      } else {
        console.error("❌ Download failed:", response?.error);
        showStatus(
          response?.error || "An unknown error occurred during download.",
          "error"
        );
        // Re-enable download button on error
        downloadBtn.disabled = false;
        cancelBtn.disabled = true;
      }
    } catch (error) {
      console.error("❌ Error in handleDownload:", error);
      showStatus(`Download Error: ${error.message}`, "error");
      // Re-enable download button on error
      downloadBtn.disabled = false;
      cancelBtn.disabled = true;
    }
  }

  async function handleCancelDownload() {
    console.log("❌ User requested download cancellation");

    try {
      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: "cancelDownload" }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(response);
          }
        });
      });

      if (response && response.success) {
        console.log("✅ Cancel request sent to background");
        showStatus("Cancelling download...", "warning");
      } else {
        console.error(
          "❌ Failed to cancel download:",
          response?.message || "No response"
        );
        showStatus(
          response?.message || "No active download to cancel",
          "warning"
        );
        cancelBtn.disabled = true;
      }
    } catch (error) {
      console.error("❌ Error cancelling download:", error);
      showStatus("Error communicating with background script", "error");
      cancelBtn.disabled = true;
    }
  }

  async function handleDownloadPage() {
    showStatus("Downloading page content...", "loading");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) {
        showStatus("No active tab found.", "error");
        return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const mainContent = document.querySelector('.styled__MainContent-sc-1penv8o-2.ikNKwI');
          return mainContent ? mainContent.innerHTML : null;
        },
      });

      if (results && results[0] && results[0].result) {
        const htmlContent = results[0].result;
        const markdownContent = htmlToMarkdown(htmlContent);
        const blob = new Blob([markdownContent], { type: "text/markdown" });
        const url = URL.createObjectURL(blob);
        const filename = sanitizeFileName(tab.title) + ".md";
        chrome.downloads.download({
          url: url,
          filename: filename,
          saveAs: true,
        });
        showStatus("Page content download started.", "success");
      } else {
        showStatus("Could not find the specified content on the page.", "error");
      }
    } catch (error) {
      console.error("Error downloading page content:", error);
      showStatus("Error downloading page content.", "error");
    }
  }

  function sanitizeFileName(title) {
    if (!title) return "Untitled_Video";
    return title
      .replace(/[^a-z0-9\s\-_]/gi, "")
      .replace(/\s+/g, "_")
      .toLowerCase();
  }

  function htmlToMarkdown(html) {
    let markdown = html;
    markdown = markdown.replace(/<p>(.*?)<\/p>/gi, "$1\n\n");
    markdown = markdown.replace(/<h1>(.*?)<\/h1>/gi, "# $1\n\n");
    markdown = markdown.replace(/<h2>(.*?)<\/h2>/gi, "## $1\n\n");
    markdown = markdown.replace(/<h3>(.*?)<\/h3>/gi, "### $1\n\n");
    markdown = markdown.replace(/<h4>(.*?)<\/h4>/gi, "#### $1\n\n");
    markdown = markdown.replace(/<h5>(.*?)<\/h5>/gi, "##### $1\n\n");
    markdown = markdown.replace(/<h6>(.*?)<\/h6>/gi, "###### $1\n\n");
    markdown = markdown.replace(/<a href=\"(.*?)\">(.*?)<\/a>/gi, "[$2]($1)");
    markdown = markdown.replace(/<strong>(.*?)<\/strong>/gi, "**$1**");
    markdown = markdown.replace(/<em>(.*?)<\/em>/gi, "*$1*");
    markdown = markdown.replace(/<li>(.*?)<\/li>/gi, "- $1\n");
    markdown = markdown.replace(/<br>/gi, "\n");
    markdown = markdown.replace(/&nbsp;/gi, " ");
    markdown = markdown.replace(/<[^>]+>/g, "");
    return markdown;
  }

  function checkDownloadState() {
    chrome.storage.local.get(
      [
        "downloadInProgress",
        "downloadPercentage",
        "downloadStatus",
        "downloadSpeed",
      ],
      (data) => {
        console.log("🔍 Checking stored download state:", data);
        if (data.downloadInProgress) {
          console.log("📥 Restoring download progress display");
          // Verify download is actually still in progress
          try {
            chrome.runtime.sendMessage(
              { action: "checkDownloadStatus" },
              (response) => {
                if (chrome.runtime.lastError) {
                  console.log(
                    "🧹 Cannot check download status, clearing state:",
                    chrome.runtime.lastError
                  );
                  hideProgress();
                  checkCurrentTabForVideo();
                  return;
                }

                if (response && response.inProgress) {
                  const currentProgress = response.currentProgress;
                  if (
                    currentProgress &&
                    (currentProgress.percentage > 0 || currentProgress.status)
                  ) {
                    showProgress(
                      currentProgress.percentage,
                      currentProgress.status,
                      currentProgress.speed || ""
                    );
                  } else {
                    showProgress(
                      data.downloadPercentage || 0,
                      data.downloadStatus || "Downloading...",
                      data.downloadSpeed || ""
                    );
                  }
                } else {
                  // Don't clear progress if we're in the completion timer
                  if (!window.downloadCompleted) {
                    hideProgress();
                    checkCurrentTabForVideo();
                  }
                }
              }
            );
          } catch (error) {
            console.log(
              "🧹 Cannot check download status, clearing state:",
              error
            );
            hideProgress();
            checkCurrentTabForVideo();
          }
        } else {
          // No download in progress, run video detection
          checkCurrentTabForVideo();
        }
      }
    );
  }

  function showMainContent() {
    mainContent.classList.remove("hidden");
    checkDownloadState();
  }

  // =================================================================================
  // INITIALIZATION FUNCTIONS
  // =================================================================================

  async function initializeButtonStates() {
    try {
      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: "checkDownloadStatus" },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(response);
            }
          }
        );
      });

      if (response && response.success && response.inProgress) {
        // Download is active, enable cancel button and show current progress
        cancelBtn.disabled = false;
        downloadBtn.disabled = true;

        const currentProgress = response.currentProgress;
        if (
          currentProgress &&
          (currentProgress.percentage > 0 || currentProgress.status)
        ) {
          showProgress(
            currentProgress.percentage,
            currentProgress.status,
            currentProgress.speed || ""
          );
        } else {
          showStatus("Download in progress...", "loading");
        }
      } else {
        // No download active, disable cancel button
        cancelBtn.disabled = true;
      }
    } catch (error) {
      console.log("Could not check download status:", error);
      cancelBtn.disabled = true;
    }
  }

  // =================================================================================
  // EVENT LISTENERS
  // =================================================================================

  downloadBtn.addEventListener("click", handleDownload);
  const downloadPageBtn = document.getElementById("downloadPageBtn");
  downloadPageBtn.addEventListener("click", handleDownloadPage);

  cancelBtn.addEventListener("click", (event) => {
    console.log("🖱️ Cancel button clicked!");
    if (!cancelBtn.disabled) {
      handleCancelDownload();
    } else {
      console.log("⚠️ Cancel button is disabled, ignoring click");
    }
  });

  let helpTimeout;
  helpBtn.addEventListener("click", () => {
    if (helpTimeout) {
      clearTimeout(helpTimeout);
    }
    helpTextDisplay.classList.remove("hidden");
    helpTimeout = setTimeout(() => {
      helpTextDisplay.classList.add("hidden");
    }, 5000);
  });

  // Copy URL button functionality
  copyUrlBtn.addEventListener("click", async () => {
    console.log("📋 Copy URL button clicked");

    const url = youtubeUrlInput.value;
    if (!url) {
      console.warn("❌ No URL to copy");
      return;
    }

    try {
      await navigator.clipboard.writeText(url);
      console.log("✅ URL copied to clipboard:", url);

      // Visual feedback
      const originalIcon = copyUrlBtn.querySelector(".copy-icon");
      const originalText = originalIcon.textContent;

      copyUrlBtn.classList.add("copied");
      originalIcon.textContent = "✓";
      copyUrlBtn.title = "URL copied!";

      setTimeout(() => {
        copyUrlBtn.classList.remove("copied");
        originalIcon.textContent = originalText;
        copyUrlBtn.title = "Copy URL to clipboard";
      }, 2000);

      showStatus("YouTube URL copied to clipboard!", "success");
    } catch (error) {
      console.error("❌ Failed to copy URL:", error);

      // Fallback: select the text
      youtubeUrlInput.select();
      youtubeUrlInput.setSelectionRange(0, 99999);

      try {
        document.execCommand("copy");
        showStatus("YouTube URL copied to clipboard!", "success");

        // Visual feedback
        const originalIcon = copyUrlBtn.querySelector(".copy-icon");
        const originalText = originalIcon.textContent;

        copyUrlBtn.classList.add("copied");
        originalIcon.textContent = "✓";
        copyUrlBtn.title = "URL copied!";

        setTimeout(() => {
          copyUrlBtn.classList.remove("copied");
          originalIcon.textContent = originalText;
          copyUrlBtn.title = "Copy URL to clipboard";
        }, 2000);
      } catch (fallbackError) {
        console.error("❌ Fallback copy also failed:", fallbackError);
        showStatus("Please manually copy the URL", "error");
      }
    }
  });

  // yt-dlp command button event handlers
  ytDlpMacBtn.addEventListener("click", async () => {
    console.log("📋 yt-dlp Mac button clicked");

    const url = youtubeUrlInput.value;
    if (!url) {
      console.warn("❌ No URL to copy");
      return;
    }

    const macCommand = `yt-dlp -P ~/Desktop '${url}'`;

    try {
      await navigator.clipboard.writeText(macCommand);
      console.log("✅ Mac yt-dlp command copied:", macCommand);

      // Visual feedback
      const originalText = ytDlpMacBtn.textContent;
      ytDlpMacBtn.classList.add("copied");
      ytDlpMacBtn.textContent = "Copied!";

      setTimeout(() => {
        ytDlpMacBtn.classList.remove("copied");
        ytDlpMacBtn.textContent = originalText;
      }, 2000);

      showStatus("Mac yt-dlp command copied to clipboard!", "success");
    } catch (error) {
      console.error("❌ Failed to copy Mac command:", error);
      showStatus("Failed to copy Mac command", "error");
    }
  });

  ytDlpWindowsBtn.addEventListener("click", async () => {
    console.log("📋 yt-dlp Windows button clicked");

    const url = youtubeUrlInput.value;
    if (!url) {
      console.warn("❌ No URL to copy");
      return;
    }

    const windowsCommand = `yt-dlp -P %USERPROFILE%\Desktop "${url}"`;

    try {
      await navigator.clipboard.writeText(windowsCommand);
      console.log("✅ Windows yt-dlp command copied:", windowsCommand);

      // Visual feedback
      const originalText = ytDlpWindowsBtn.textContent;
      ytDlpWindowsBtn.classList.add("copied");
      ytDlpWindowsBtn.textContent = "Copied!";

      setTimeout(() => {
        ytDlpWindowsBtn.classList.remove("copied");
        ytDlpWindowsBtn.textContent = originalText;
      }, 2000);

      showStatus("Windows yt-dlp command copied to clipboard!", "success");
    } catch (error) {
      console.error("❌ Failed to copy Windows command:", error);
      showStatus("Failed to copy Windows command", "error");
    }
  });

  // Listen for progress updates from background script
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("📩 Popup received message:", message);

    switch (message.type) {
      case "DOWNLOAD_PROGRESS":
        showProgress(message.percentage, message.status, message.speed || "");
        break;

      case "DOWNLOAD_COMPLETE":
        downloadInProgress = false;
        window.downloadCompleted = true; // Flag to prevent polling interference
        showProgress(100, message.status || "Download completed!");
        downloadBtn.disabled = false;
        cancelBtn.disabled = true;
        setTimeout(() => {
          window.downloadCompleted = false; // Reset flag
          hideProgress();
          videoDetectionTimeout = setTimeout(() => {
            checkCurrentTabForVideo();
            videoDetectionTimeout = null;
          }, 500);
        }, 3000);
        break;

      case "DOWNLOAD_ERROR":
        hideProgress();
        showStatus(message.error || "Download failed", "error");
        downloadBtn.disabled = false;
        cancelBtn.disabled = true;
        videoDetectionTimeout = setTimeout(() => {
          checkCurrentTabForVideo();
          videoDetectionTimeout = null;
        }, 3000);
        break;

      case "DOWNLOAD_CANCELLED":
        console.log("✅ Download cancelled, resetting UI");
        downloadInProgress = false;
        hideProgress();
        showStatus("Download cancelled", "warning");
        downloadBtn.disabled = false;
        cancelBtn.disabled = true;
        videoDetectionTimeout = setTimeout(() => {
          checkCurrentTabForVideo();
          videoDetectionTimeout = null;
        }, 2000);
        break;
    }
  });

  // =================================================================================
  // INITIALIZATION
  // =================================================================================

  // Initialize button states
  initializeButtonStates();

  // Show main content on load
  showMainContent();
});
