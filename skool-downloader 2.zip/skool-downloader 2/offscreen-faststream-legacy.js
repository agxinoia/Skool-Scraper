// FastStream-based offscreen script for HLS processing (Enhanced with fMP4 support)
import {
  set as idbSet,
  get as idbGet,
  remove as idbRemove,
} from "./indexed-db.js";

console.log("🚀 FastStream Offscreen script starting...");

// Global variables to hold loaded modules
let SimpleHLS2MP4Converter = null;

function getBatchSize(totalSegments) {
  return Math.min(10, totalSegments);
}

// Helper function to detect if segment data is FMP4 format
function isSegmentFMP4(segmentData) {
  try {
    let data;
    if (segmentData instanceof ArrayBuffer) {
      data = new Uint8Array(segmentData);
    } else if (segmentData instanceof Uint8Array) {
      data = segmentData;
    } else {
      return false;
    }

    if (data.length < 16) return false;

    // Check for MP4 box signatures that indicate FMP4
    const hasMP4Boxes = containsMP4Box(data, "ftyp") || 
                       containsMP4Box(data, "moof") || 
                       containsMP4Box(data, "moov");
    
    return hasMP4Boxes;
  } catch (error) {
    return false;
  }
}

// Helper function to check for MP4 box presence
function containsMP4Box(data, boxType) {
  const boxBytes = new TextEncoder().encode(boxType);
  for (let i = 0; i <= data.length - boxBytes.length; i++) {
    let match = true;
    for (let j = 0; j < boxBytes.length; j++) {
      if (data[i + j] !== boxBytes[j]) {
        match = false;
        break;
      }
    }
    if (match) return true;
  }
  return false;
}


// Helper function to send debug logs to background script
function debugLog(message, level = "info") {
  console.log(message);
  try {
    chrome.runtime
      .sendMessage({
        type: "DEBUG_MESSAGE",
        message: `📱 FASTSTREAM OFFSCREEN: ${message}`,
        level: level,
      })
      .catch(() => {});
  } catch (error) {}
}

// Load modules dynamically
async function loadModules() {
  try {
    debugLog("🔄 Loading modules...");

    debugLog("✅ IndexedDB module imported");

    // Import the actual FastStream HLS2MP4 converter
    const { HLS2MP4 } = await import("./modules/hls2mp4/hls2mp4.mjs");

    // Create enhanced wrapper class that handles both TS and fMP4 formats
    SimpleHLS2MP4Converter = class FastStreamHLS2MP4Wrapper {
      constructor(options = {}) {
        this.cancelled = false;
        this.progressCallback = options.onProgress;
        this.hls2mp4 = null;
      }

      cancel() {
        this.cancelled = true;
        if (this.hls2mp4) {
          this.hls2mp4.cancel();
        }
      }

      async convertSegments(segments, options = {}) {
        debugLog(
          `🔧 FastStream converter processing ${segments.length} segments`
        );
        debugLog(
          `🔧 Stream format detected: ${options.streamFormat || "unknown"}`
        );

        try {
          // Check if this is fMP4 HLS (has initialization segments)
          if (this.isFMP4Stream(segments, options)) {
            debugLog(`🔧 Detected fMP4 HLS stream with init segments`);
            return await this.convertFMP4Segments(segments, options);
          }

          // Check if this is DASH content
          if (options.isDASH || options.segmentType === "DASH") {
            debugLog(`🔧 Detected DASH segments, processing...`);
            return await this.convertDashSegments(segments, options);
          }

          // Traditional TS segments processing
          debugLog(`🔧 Processing traditional TS segments`);
          return await this.convertTSSegments(segments, options);
        } catch (error) {
          debugLog(`🔧 FastStream conversion failed: ${error.message}`);
          throw error;
        }
      }

      // Check if this is an fMP4 stream
      isFMP4Stream(segments, options) {
        // Check URL parameters for fMP4 indicators
        if (
          options.streamFormat === "fmp4" ||
          options.sourceUrl?.includes("sf=fmp4") ||
          options.sourceUrl?.includes("format=fmp4")
        ) {
          debugLog(`🔧 fMP4 detected via URL parameters`);
          return true;
        }

        // Check manifest for fMP4 indicators
        if (options.manifestContent) {
          const hasMap = options.manifestContent.includes("#EXT-X-MAP:");
          const version6Plus = /#EXT-X-VERSION:([6-9]|\d{2,})/.test(
            options.manifestContent
          );
          if (hasMap || version6Plus) {
            debugLog(
              `🔧 fMP4 indicators: EXT-X-MAP=${hasMap}, Version6+=${version6Plus}`
            );
            return true;
          }
        }

        // Check segment data for fMP4 box structures
        if (segments.length > 0) {
          const firstSegment = segments[0];
          const segmentData = firstSegment.data || firstSegment;

          if (
            this.containsMP4Box(segmentData, "ftyp") ||
            this.containsMP4Box(segmentData, "moof")
          ) {
            debugLog(`🔧 Found MP4 box structure in segments`);
            return true;
          }
        }

        return false;
      }

      // Convert fMP4 HLS segments
      async convertFMP4Segments(segments, options = {}) {
        debugLog(`🔧 Processing ${segments.length} fMP4 HLS segments`);

        try {
          // Separate initialization segments from media segments
          const { initSegments, mediaSegments } =
            this.separateFMP4Segments(segments);

          debugLog(
            `🔧 Found ${initSegments.length} init segments and ${mediaSegments.length} media segments`
          );

          if (initSegments.length === 0) {
            debugLog(
              `🔧 No init segments found, trying fallback concatenation`
            );
            return await this.fallbackConcatenateFMP4(segments, options);
          }

          // Build complete fMP4 stream
          const completeStream = await this.buildFMP4Stream(
            initSegments,
            mediaSegments,
            options
          );

          // Convert using MediaBunny for fMP4 processing
          const result = await this.processWithMediaBunny(
            completeStream,
            options
          );

          return result;
        } catch (error) {
          debugLog(`🔧 fMP4 processing failed: ${error.message}`);

          // Fallback: try treating as concatenated segments
          debugLog(`🔧 Trying fallback: concatenate all fMP4 segments`);
          return await this.fallbackConcatenateFMP4(segments, options);
        }
      }

      // Separate init segments from media segments in fMP4 stream
      separateFMP4Segments(segments) {
        const initSegments = [];
        const mediaSegments = [];

        for (let i = 0; i < segments.length; i++) {
          const segment = segments[i];
          const segmentData = segment.data || segment;
          const dataArray = this.toUint8Array(segmentData);

          // Check if marked as init segment from M3U8 parsing or if content indicates init segment
          const isMarkedInit = segment.isInit === true;
          const isContentInit = this.isInitializationSegment(dataArray);
          const isInitSegment = isMarkedInit || isContentInit;

          debugLog(
            `🔧 Segment ${i}: ${dataArray.length} bytes, init=${isInitSegment} (marked=${isMarkedInit}, content=${isContentInit})`
          );

          if (isInitSegment) {
            initSegments.push(dataArray);
          } else {
            mediaSegments.push(dataArray);
          }
        }

        return { initSegments, mediaSegments };
      }

      // Check if segment is an initialization segment
      isInitializationSegment(data) {
        if (data.length < 16) return false;

        // fMP4 init segments contain 'ftyp' and 'moov' boxes
        const hasFtyp = this.containsMP4Box(data, "ftyp");
        const hasMoov = this.containsMP4Box(data, "moov");

        // Init segments typically have both ftyp and moov
        // Media segments have 'moof' and 'mdat' boxes
        const hasMoof = this.containsMP4Box(data, "moof");

        // If it has ftyp or moov but not moof, it's likely an init segment
        if ((hasFtyp || hasMoov) && !hasMoof) {
          return true;
        }

        // Very small segments are often init segments
        if (data.length < 10000 && (hasFtyp || hasMoov)) {
          return true;
        }

        return false;
      }

      // Build complete fMP4 stream by combining init + media segments
      async buildFMP4Stream(initSegments, mediaSegments, options) {
        debugLog(`🔧 Building complete fMP4 stream`);

        // Use the first (or largest) initialization segment
        const initSegment = initSegments.reduce((largest, current) =>
          current.length > largest.length ? current : largest
        );

        debugLog(`🔧 Using init segment: ${initSegment.length} bytes`);

        // Calculate total size
        const totalSize =
          initSegment.length +
          mediaSegments.reduce((sum, seg) => sum + seg.length, 0);

        // Build complete stream: init + all media segments
        const completeStream = new Uint8Array(totalSize);
        let offset = 0;

        // Add initialization segment first
        completeStream.set(initSegment, offset);
        offset += initSegment.length;

        // Add all media segments
        for (const mediaSegment of mediaSegments) {
          completeStream.set(mediaSegment, offset);
          offset += mediaSegment.length;
        }

        debugLog(
          `🔧 Complete fMP4 stream built: ${completeStream.length} bytes`
        );

        return completeStream;
      }

      // Process fMP4 stream using MediaBunny
      async processWithMediaBunny(streamData, options) {
        debugLog(
          `🔧 Processing fMP4 with MediaBunny: ${streamData.length} bytes`
        );

        try {
          const {
            Input,
            Output,
            Conversion,
            ALL_FORMATS,
            BufferSource,
            BufferTarget,
            Mp4OutputFormat,
          } = await import("./modules/mediabunny/dist/modules/src/index.js");

          // Create input from the complete fMP4 stream
          const input = new Input({
            source: new BufferSource(streamData.buffer),
            formats: ALL_FORMATS,
          });

          // Create MP4 output
          const output = new Output({
            format: new Mp4OutputFormat({
              fastStart: "in-memory",
            }),
            target: new BufferTarget(),
          });

          debugLog(`🔧 Starting MediaBunny conversion...`);

          // Convert using MediaBunny
          const conversion = await Conversion.init({
            input: input,
            output: output,
          });

          await conversion.execute();

          const outputBuffer = output.target.buffer;
          if (!outputBuffer || outputBuffer.byteLength === 0) {
            throw new Error(
              "MediaBunny conversion failed - output buffer is empty"
            );
          }

          const outputBlob = new Blob([outputBuffer], { type: "video/mp4" });

          debugLog(
            `🔧 MediaBunny conversion successful: ${(
              outputBlob.size /
              1024 /
              1024
            ).toFixed(2)} MB`
          );

          return outputBlob;
        } catch (error) {
          debugLog(`🔧 MediaBunny processing failed: ${error.message}`);
          throw error;
        }
      }

      // Fallback: simple concatenation of fMP4 segments
      async fallbackConcatenateFMP4(segments, options) {
        debugLog(`🔧 Fallback: concatenating ${segments.length} fMP4 segments`);

        try {
          // Calculate total size
          const totalSize = segments.reduce((sum, segment) => {
            const segmentData = segment.data || segment;
            const dataArray = this.toUint8Array(segmentData);
            return sum + dataArray.length;
          }, 0);

          // Concatenate all segments
          const concatenated = new Uint8Array(totalSize);
          let offset = 0;

          for (const segment of segments) {
            const segmentData = segment.data || segment;
            const dataArray = this.toUint8Array(segmentData);
            concatenated.set(dataArray, offset);
            offset += dataArray.length;
          }

          // Create blob
          const resultBlob = new Blob([concatenated], { type: "video/mp4" });

          debugLog(
            `🔧 Fallback concatenation complete: ${(
              resultBlob.size /
              1024 /
              1024
            ).toFixed(2)} MB`
          );

          return resultBlob;
        } catch (error) {
          debugLog(`🔧 Fallback concatenation failed: ${error.message}`);
          throw error;
        }
      }

      // Convert traditional TS segments (existing logic)
      async convertTSSegments(segments, options = {}) {
        debugLog(
          `🔧 Processing traditional TS segments with FastStream HLS2MP4`
        );

        // Create the FastStream converter for HLS content
        this.hls2mp4 = new HLS2MP4();

        // Set up progress tracking
        if (this.progressCallback) {
          this.hls2mp4.on("progress", this.progressCallback);
        }

        // Create level and audioLevel objects for FastStream
        const finalDuration =
          options.totalDuration || options.duration || segments.length * 2;

        const level = {
          audioCodec: options.audioCodec || "mp4a.40.2",
          videoCodec: options.videoCodec || "avc1.42E01E",
          details: {
            totalduration: finalDuration,
          },
        };

        // Create fragment objects compatible with FastStream
        const zippedFragments = [];

        for (let i = 0; i < segments.length; i++) {
          if (this.cancelled) {
            throw new Error("Conversion cancelled");
          }

          const segmentData = segments[i];
          let arrayBuffer;

          if (segmentData instanceof ArrayBuffer) {
            arrayBuffer = segmentData;
          } else if (segmentData instanceof Uint8Array) {
            arrayBuffer = segmentData.buffer;
          } else if (segmentData instanceof Blob) {
            arrayBuffer = await segmentData.arrayBuffer();
          } else {
            const blob = new Blob([segmentData]);
            arrayBuffer = await blob.arrayBuffer();
          }

          const fragment = {
            track: 0,
            fragment: {
              sn: i,
              cc: 0,
            },
            async getEntry() {
              return {
                async getDataFromBlob() {
                  return arrayBuffer;
                },
              };
            },
          };

          zippedFragments.push(fragment);
        }

        debugLog(
          `🔧 Starting FastStream TS conversion with ${zippedFragments.length} fragments`
        );

        // Use FastStream's convert method
        const resultBlob = await this.hls2mp4.convert(
          level,
          null, // levelInitData
          null, // audioLevel (no separate audio)
          null, // audioInitData
          zippedFragments
        );

        debugLog(
          `🔧 FastStream TS conversion complete: ${(
            resultBlob.size /
            1024 /
            1024
          ).toFixed(2)} MB`
        );

        return resultBlob;
      }

      // Helper: convert data to Uint8Array
      toUint8Array(data) {
        if (data instanceof Uint8Array) {
          return data;
        } else if (data instanceof ArrayBuffer) {
          return new Uint8Array(data);
        } else {
          return new Uint8Array(data);
        }
      }

      // Helper: check if data contains specific MP4 box
      containsMP4Box(data, boxType) {
        const dataArray = this.toUint8Array(data);
        const searchBytes = new TextEncoder().encode(boxType);

        for (let i = 0; i < dataArray.length - 4; i++) {
          let match = true;
          for (let j = 0; j < 4; j++) {
            if (dataArray[i + j] !== searchBytes[j]) {
              match = false;
              break;
            }
          }
          if (match) return true;
        }

        return false;
      }

      async convertDashSegments(segments, options = {}) {
        debugLog(
          `🔧 DASH: Processing ${segments.length} DASH segments with proper muxing`
        );

        try {
          const result = await processDashSegments(
            segments,
            options.mpdData || {}
          );

          // Check if we got separate video and audio blobs
          if (result.videoBlob && result.audioBlob) {
            debugLog(
              `🔧 DASH: Successfully created separate files - Video: ${(
                result.videoBlob.size /
                1024 /
                1024
              ).toFixed(2)} MB, Audio: ${(
                result.audioBlob.size /
                1024 /
                1024
              ).toFixed(2)} MB`
            );
            return result; // Return object with videoBlob and audioBlob
          } else if (result.videoBlob) {
            debugLog(
              `🔧 DASH: Successfully created video file: ${(
                result.videoBlob.size /
                1024 /
                1024
              ).toFixed(2)} MB (no audio)`
            );
            return result; // Return object with videoBlob only
          } else {
            // Fallback for backwards compatibility
            debugLog(
              `🔧 DASH: Successfully created ${(
                result.size /
                1024 /
                1024
              ).toFixed(2)} MB file`
            );
            return result;
          }
        } catch (error) {
          debugLog(`🔧 DASH: Processing failed: ${error.message}`);
          throw error;
        }
      }

      destroy() {
        if (this.hls2mp4) {
          this.hls2mp4.destroy();
          this.hls2mp4 = null;
        }
      }
    };

    debugLog("✅ All modules loaded successfully");
    return true;
  } catch (error) {
    debugLog(`❌ Failed to load modules: ${error.message}`);
    console.error("Failed to load modules:", error);
    return false;
  }
}

// Load all segments at once
async function loadAllSegments(segmentsKey, totalSegments) {
  debugLog(`🔍 Loading all ${totalSegments} segments...`);

  const segments = [];
  const BATCH_SIZE = getBatchSize(totalSegments);

  for (let i = 0; i < totalSegments; i += BATCH_SIZE) {
    const batchEnd = Math.min(i + BATCH_SIZE, totalSegments);
    const batchPromises = [];

    for (let j = i; j < batchEnd; j++) {
      const segmentKey = `${segmentsKey}_${j}`;
      batchPromises.push(
        idbGet(segmentKey).then(async (segmentData) => {
          if (segmentData) {
            await idbRemove(segmentKey);
            return {
              index: j,
              data: segmentData,
            };
          }
          return null;
        })
      );
    }

    const batchResults = await Promise.all(batchPromises);

    for (const result of batchResults) {
      if (result && result.data) {
        segments.push(result);
      }
    }

    const loadedCount = batchResults.filter((r) => r && r.data).length;
    debugLog(
      `🔍 Batch ${
        Math.floor(i / BATCH_SIZE) + 1
      }: Loaded ${loadedCount} segments`
    );
  }

  segments.sort((a, b) => a.index - b.index);
  debugLog(`🔍 ✅ Successfully loaded ${segments.length} segments total`);

  return segments;
}

// Enhanced segment processing function that detects stream format
async function processSegmentsWithFastStream(
  segments,
  fileName,
  totalDuration = null,
  options = {}
) {
  debugLog(
    `🔍 Processing ${segments.length} segments with Enhanced FastStream`
  );

  const baseFileName = fileName.replace(/\.(webm|mkv|avi|ts|mp4)$/i, "");
  const outputFileName = `${baseFileName}.mp4`;

  try {
    // Create enhanced converter with progress tracking
    const converter = new SimpleHLS2MP4Converter({
      onProgress: (progress) => {
        debugLog(`🔍 Conversion progress: ${(progress * 100).toFixed(1)}%`);
      },
    });

    // Extract just the data from segments
    const segmentBuffers = segments.map((segment) => segment.data);

    // 🔍 DETAILED FORMAT DETECTION LOGGING
    if (segmentBuffers.length > 0) {
      const firstSegment = segmentBuffers[0];
      debugLog(`🔍 📊 SKOOL SEGMENT FORMAT ANALYSIS:`);
      debugLog(`🔍 📊 - Total segments: ${segmentBuffers.length}`);
      debugLog(`🔍 📊 - First segment type: ${firstSegment?.constructor?.name || typeof firstSegment}`);
      debugLog(`🔍 📊 - First segment size: ${firstSegment?.byteLength || firstSegment?.length || 'unknown'} bytes`);
      
      // Examine first 32 bytes for format detection
      let headerBytes = null;
      if (firstSegment instanceof ArrayBuffer) {
        headerBytes = new Uint8Array(firstSegment.slice(0, 32));
      } else if (firstSegment instanceof Uint8Array) {
        headerBytes = firstSegment.slice(0, 32);
      } else if (firstSegment?.buffer) {
        headerBytes = new Uint8Array(firstSegment.buffer.slice(0, 32));
      }
      
      if (headerBytes) {
        const hexString = Array.from(headerBytes).map(b => b.toString(16).padStart(2, '0')).join(' ');
        const asciiString = Array.from(headerBytes).map(b => (b >= 32 && b <= 126) ? String.fromCharCode(b) : '.').join('');
        debugLog(`🔍 📊 - First 32 bytes (hex): ${hexString}`);
        debugLog(`🔍 📊 - First 32 bytes (ascii): ${asciiString}`);
        
        // Common format detection
        const header = headerBytes.slice(0, 16);
        if (header[0] === 0x47) {
          debugLog(`🔍 📊 - Format detected: MPEG-TS (Transport Stream) - starts with sync byte 0x47`);
        } else if (header[4] === 0x66 && header[5] === 0x74 && header[6] === 0x79 && header[7] === 0x70) {
          debugLog(`🔍 📊 - Format detected: MP4/fMP4 - contains 'ftyp' box`);
        } else if (header[4] === 0x6D && header[5] === 0x6F && header[6] === 0x6F && header[7] === 0x66) {
          debugLog(`🔍 📊 - Format detected: fMP4 - contains 'moof' box`);
        } else if (header[0] === 0x00 && header[1] === 0x00 && header[2] === 0x00) {
          debugLog(`🔍 📊 - Format detected: Possible MP4 box structure`);
        } else {
          debugLog(`🔍 📊 - Format detected: UNKNOWN - header doesn't match common patterns`);
        }
      }
    }

    debugLog(
      `🔍 Starting Enhanced FastStream conversion of ${segmentBuffers.length} segments`
    );
    debugLog(
      `🔍 Options:`,
      JSON.stringify(
        {
          isDASH: options.isDASH,
          streamFormat: options.streamFormat,
          sourceUrl: options.sourceUrl?.substring(0, 100) + "...",
        },
        null,
        2
      )
    );

    const startTime = performance.now();

    // Use the enhanced converter with format detection
    const outputBlob = await converter.convertSegments(segmentBuffers, {
      videoCodec: "avc1.42E01E",
      audioCodec: "mp4a.40.2",
      totalDuration: totalDuration,
      duration: totalDuration || segmentBuffers.length * 2,
      isDASH: options.isDASH,
      segmentType: options.segmentType,
      streamFormat: options.streamFormat,
      sourceUrl: options.sourceUrl,
      manifestContent: options.manifestContent,
      videoMimeType: options.videoMimeType,
      audioMimeType: options.audioMimeType,
      videoInitSegment: options.videoInitSegment,
      audioInitSegment: options.audioInitSegment,
    });

    const endTime = performance.now();

    debugLog(
      `🔍 ✅ Enhanced FastStream conversion completed in ${(
        endTime - startTime
      ).toFixed(2)}ms`
    );
    debugLog(
      `🔍 Output file size: ${(outputBlob.size / 1024 / 1024).toFixed(2)} MB`
    );

    // Handle different result types
    if (outputBlob.videoBlob || outputBlob.audioBlob) {
      // DASH result with separate files
      const baseFileName = fileName.replace(/\.(webm|mkv|avi|ts|mp4)$/i, "");
      let totalSize = 0;

      // Download video file
      if (outputBlob.videoBlob && outputBlob.videoBlob instanceof Blob) {
        const videoFileName = `${baseFileName}_video.mp4`;
        const videoBlobUrl = URL.createObjectURL(outputBlob.videoBlob);
        const videoLink = document.createElement("a");
        videoLink.href = videoBlobUrl;
        videoLink.download = videoFileName;
        document.body.appendChild(videoLink);
        videoLink.click();
        document.body.removeChild(videoLink);
        setTimeout(() => URL.revokeObjectURL(videoBlobUrl), 1000);
        totalSize += outputBlob.videoBlob.size;
        debugLog(`🔍 Downloaded video file: ${videoFileName}`);

        // Send completion notification
        try {
          chrome.runtime
            .sendMessage({
              type: "DOWNLOAD_COMPLETE_NOTIFICATION",
              fileName: videoFileName,
            })
            .catch(() => {});
        } catch (error) {}
      }

      // Download audio file
      if (outputBlob.audioBlob && outputBlob.audioBlob instanceof Blob) {
        const audioExtension = outputBlob.audioBlob.type.includes("webm")
          ? "webm"
          : "mp4";
        const audioFileName = `${baseFileName}_audio.${audioExtension}`;
        const audioBlobUrl = URL.createObjectURL(outputBlob.audioBlob);
        const audioLink = document.createElement("a");
        audioLink.href = audioBlobUrl;
        audioLink.download = audioFileName;
        document.body.appendChild(audioLink);
        audioLink.click();
        document.body.removeChild(audioLink);
        setTimeout(() => URL.revokeObjectURL(audioBlobUrl), 1000);
        totalSize += outputBlob.audioBlob.size;
        debugLog(`🔍 Downloaded audio file: ${audioFileName}`);

        // Send completion notification
        try {
          chrome.runtime
            .sendMessage({
              type: "DOWNLOAD_COMPLETE_NOTIFICATION",
              fileName: audioFileName,
            })
            .catch(() => {});
        } catch (error) {}
      }

      return {
        fileName: `${baseFileName}_video.mp4 + ${baseFileName}_audio.mp4`,
        size: totalSize,
        success: true,
      };
    } else {
      // Single file result
      const blobUrl = URL.createObjectURL(outputBlob);
      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = outputFileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      debugLog(`🔍 ✅ Download initiated for ${outputFileName}`);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

      // Send completion notification
      try {
        chrome.runtime
          .sendMessage({
            type: "DOWNLOAD_COMPLETE_NOTIFICATION",
            fileName: outputFileName,
          })
          .catch(() => {});
      } catch (error) {}

      // Clean up
      converter.destroy();

      return {
        fileName: outputFileName,
        size: outputBlob.size,
        success: true,
      };
    }
  } catch (error) {
    debugLog(`🔍 ❌ Enhanced FastStream processing failed: ${error.message}`);
    throw error;
  }
}

// Load separate A/V segments
async function loadSeparateAVSegments(
  segmentsKey,
  totalSegments,
  videoCount,
  audioCount
) {
  debugLog(
    `🔍 Loading ${videoCount} video and ${audioCount} audio segments...`
  );

  const videoSegments = [];
  const audioSegments = [];
  const BATCH_SIZE = getBatchSize(totalSegments);

  // Load video segments (indices 0 to videoCount-1)
  for (let i = 0; i < videoCount; i += BATCH_SIZE) {
    const batchEnd = Math.min(i + BATCH_SIZE, videoCount);
    const batchPromises = [];

    for (let j = i; j < batchEnd; j++) {
      const segmentKey = `${segmentsKey}_${j}`;
      batchPromises.push(
        idbGet(segmentKey).then(async (segmentData) => {
          if (segmentData) {
            await idbRemove(segmentKey);
            return {
              index: j,
              data: segmentData.data || segmentData, // Extract ArrayBuffer from wrapper
              isInitSegment: segmentData.isInitSegment || false,
              segmentType: segmentData.segmentType || 'video',
              segmentIndex: segmentData.segmentIndex || j,
              mimeType: segmentData.mimeType || 'video/mp4'
            };
          }
          return null;
        })
      );
    }

    const batchResults = await Promise.all(batchPromises);
    for (const result of batchResults) {
      if (result && result.data) {
        videoSegments.push(result);
      }
    }
  }

  // Load audio segments (indices videoCount to totalSegments-1)
  for (let i = videoCount; i < totalSegments; i += BATCH_SIZE) {
    const batchEnd = Math.min(i + BATCH_SIZE, totalSegments);
    const batchPromises = [];

    for (let j = i; j < batchEnd; j++) {
      const segmentKey = `${segmentsKey}_${j}`;
      batchPromises.push(
        idbGet(segmentKey).then(async (segmentData) => {
          if (segmentData) {
            await idbRemove(segmentKey);
            return {
              index: j - videoCount,
              data: segmentData.data || segmentData, // Extract ArrayBuffer from wrapper
              isInitSegment: segmentData.isInitSegment || false,
              segmentType: segmentData.segmentType || 'audio',
              segmentIndex: segmentData.segmentIndex || (j - videoCount),
              mimeType: segmentData.mimeType || 'audio/mp4'
            };
          }
          return null;
        })
      );
    }

    const batchResults = await Promise.all(batchPromises);
    for (const result of batchResults) {
      if (result && result.data) {
        audioSegments.push(result);
      }
    }
  }

  videoSegments.sort((a, b) => a.index - b.index);
  audioSegments.sort((a, b) => a.index - b.index);

  debugLog(
    `🔍 ✅ Loaded ${videoSegments.length} video and ${audioSegments.length} audio segments`
  );

  return { videoSegments, audioSegments };
}

async function muxDashStreamsWithMediaBunny(videoBlob, audioBlob) {
  debugLog(`🔧 MUXING: Using EncodedVideoPacketSource with proper metadata...`);

  try {
    const {
      Input,
      Output,
      ALL_FORMATS,
      BufferSource,
      BufferTarget,
      Mp4OutputFormat,
      EncodedVideoPacketSource,
      EncodedAudioPacketSource,
      EncodedPacketSink,
    } = await import("./modules/mediabunny/dist/modules/src/index.js");

    // Convert blobs to ArrayBuffers
    const videoBuffer = await videoBlob.arrayBuffer();
    const audioBuffer = await audioBlob.arrayBuffer();

    // Create inputs
    const videoInput = new Input({
      source: new BufferSource(videoBuffer),
      formats: ALL_FORMATS,
    });

    const audioInput = new Input({
      source: new BufferSource(audioBuffer),
      formats: ALL_FORMATS,
    });

    // Get tracks
    const videoTrack = await videoInput.getPrimaryVideoTrack();
    const audioTrack = await audioInput.getPrimaryAudioTrack();

    if (!videoTrack) throw new Error("No video track found");

    // Get track properties and decoder configurations
    const videoWidth = videoTrack.codedWidth || videoTrack.displayWidth || 1920;
    const videoHeight =
      videoTrack.codedHeight || videoTrack.displayHeight || 1080;
    const audioChannels = audioTrack ? audioTrack.numberOfChannels || 2 : 2;
    const audioSampleRate = audioTrack ? audioTrack.sampleRate || 48000 : 48000;

    // Get decoder configurations
    const videoDecoderConfig = await videoTrack.getDecoderConfig();
    const audioDecoderConfig = audioTrack
      ? await audioTrack.getDecoderConfig()
      : null;

    debugLog(
      `🔧 MUXING: Video: ${videoWidth}x${videoHeight}, Audio: ${audioChannels}ch @ ${audioSampleRate}Hz`
    );
    debugLog(
      `🔧 MUXING: Video decoder config: ${JSON.stringify(videoDecoderConfig)}`
    );
    debugLog(
      `🔧 MUXING: Audio decoder config: ${JSON.stringify(audioDecoderConfig)}`
    );

    // Create output
    const output = new Output({
      format: new Mp4OutputFormat({
        fastStart: "in-memory",
      }),
      target: new BufferTarget(),
    });

    // Create sources with correct MediaBunny API - only codec name required
    const videoSource = new EncodedVideoPacketSource(videoTrack.codec);

    let audioSource = null;
    if (audioTrack) {
      audioSource = new EncodedAudioPacketSource(audioTrack.codec);
    }

    // Add tracks to output
    output.addVideoTrack(videoSource);
    if (audioSource) {
      output.addAudioTrack(audioSource);
    }

    // Start output
    await output.start();

    // Process video packets using correct MediaBunny API
    const videoSink = new EncodedPacketSink(videoTrack);
    let videoCount = 0;
    let isFirstVideoPacket = true;

    debugLog(`🔧 MUXING: Processing video packets...`);

    for await (const packet of videoSink.packets()) {
      videoCount++;

      try {
        if (isFirstVideoPacket) {
          // First packet requires decoder configuration metadata
          await videoSource.add(packet, {
            decoderConfig: videoDecoderConfig,
          });
          isFirstVideoPacket = false;
          debugLog(`🔧 MUXING: Added first video packet with decoder config`);
        } else {
          // Subsequent packets just need the packet data
          await videoSource.add(packet);
        }
      } catch (methodError) {
        debugLog(
          `🔧 MUXING: Error with video packet ${videoCount}: ${methodError.message}`
        );
        if (videoCount === 1) {
          throw methodError; // Fail on first packet error
        }
      }

      if (videoCount % 100 === 0) {
        debugLog(`🔧 MUXING: Processed ${videoCount} video packets...`);
      }
    }

    debugLog(`🔧 MUXING: Processed ${videoCount} video packets total`);

    // Process audio packets using correct MediaBunny API
    if (audioTrack && audioSource) {
      debugLog(`🔧 MUXING: Processing audio packets...`);

      const audioSink = new EncodedPacketSink(audioTrack);
      let audioCount = 0;
      let isFirstAudioPacket = true;

      for await (const packet of audioSink.packets()) {
        audioCount++;

        try {
          if (isFirstAudioPacket) {
            // First packet requires decoder configuration metadata
            await audioSource.add(packet, {
              decoderConfig: audioDecoderConfig,
            });
            isFirstAudioPacket = false;
            debugLog(`🔧 MUXING: Added first audio packet with decoder config`);
          } else {
            // Subsequent packets just need the packet data
            await audioSource.add(packet);
          }
        } catch (methodError) {
          debugLog(
            `🔧 MUXING: Error with audio packet ${audioCount}: ${methodError.message}`
          );
          if (audioCount === 1) {
            throw methodError;
          }
        }

        if (audioCount % 100 === 0) {
          debugLog(`🔧 MUXING: Processed ${audioCount} audio packets...`);
        }
      }

      debugLog(`🔧 MUXING: Processed ${audioCount} audio packets total`);
    }

    // Finalize output
    await output.finalize();

    const muxedBuffer = output.target.buffer;
    if (!muxedBuffer || muxedBuffer.byteLength === 0) {
      throw new Error("Output buffer is empty");
    }

    const muxedBlob = new Blob([muxedBuffer], { type: "video/mp4" });
    debugLog(
      `🔧 MUXING: Success! Created ${(muxedBlob.size / 1024 / 1024).toFixed(
        2
      )} MB MP4`
    );

    return muxedBlob;
  } catch (error) {
    debugLog(`🔧 MUXING: Failed: ${error.message}`);
    throw error;
  }
}

async function processDashSegments(segments, mpdData) {
  debugLog(
    `🔧 MEDIABUNNY: Processing ${segments.length} DASH segments using Conversion API`
  );

  // Declare variables at function scope so they're accessible throughout
  let videoBlob = null;
  let audioBlob = null;

  try {
    // Parse MPD for timing information
    const { totalDuration, timescale, segmentTimeline } = parseMpdData(mpdData);

    debugLog(
      `🔧 MEDIABUNNY: Total duration: ${totalDuration}s, Timescale: ${timescale}`
    );

    // Import MediaBunny classes including Conversion API
    const {
      Input,
      Output,
      Conversion,
      ALL_FORMATS,
      BufferSource,
      WebMOutputFormat,
      BufferTarget,
      Mp4OutputFormat,
    } = await import("./modules/mediabunny/dist/modules/src/index.js");

    debugLog(`🔧 MEDIABUNNY: Analyzing segment structure...`);

    // We need to properly identify video vs audio segments
    // DASH downloads video segments first, then audio segments
    // They're passed to us in order: [video_init, video_segments..., audio_init, audio_segments...]

    let videoInit = null;
    let audioInit = null;
    const videoMediaSegments = [];
    const audioMediaSegments = [];

    // Find initialization segments and separate video/audio
    // DASH segments usually come in order: video_segments..., audio_segments...
    // Init segments are typically smaller and may be marked explicitly

    segments.forEach((segment, index) => {
      const segmentData = segment.data || segment;

      // Convert to Uint8Array for analysis
      let dataArray;
      if (segmentData instanceof Uint8Array) {
        dataArray = segmentData;
      } else if (segmentData instanceof ArrayBuffer) {
        dataArray = new Uint8Array(segmentData);
      } else {
        dataArray = new Uint8Array(segmentData);
      }

      // Check for MP4 box structure
      const boxType = getMP4BoxType(dataArray);
      const containsFtyp = boxType === "ftyp" || containsBox(dataArray, "ftyp");
      const containsMoov = containsBox(dataArray, "moov");
      const isInitSegment =
        containsFtyp ||
        containsMoov ||
        segment.isInitSegment ||
        segment.url?.includes("init") ||
        (segment.range && segment.range.includes("0-")) ||
        dataArray.length < 10000; // Init segments are typically small

      // Check segment type metadata
      const isVideoSegment =
        segment.segmentType === "video" || segment.mimeType?.includes("video");
      const isAudioSegment =
        segment.segmentType === "audio" || segment.mimeType?.includes("audio");

      // Use size-based heuristics for DASH segments:
      // - Audio segments are typically smaller (< 100KB)
      // - Video segments are typically larger (> 200KB)
      // - Very small segments (< 10KB) are likely init segments
      const likelyAudioBySize =
        dataArray.length < 100000 && dataArray.length > 1000;
      const likelyVideoBySize = dataArray.length > 200000;

      debugLog(
        `🔧 MEDIABUNNY: Segment ${index}: ${
          dataArray.length
        } bytes, box: ${boxType}, init: ${isInitSegment}, type: ${
          segment.segmentType || "unknown"
        }, audioSize: ${likelyAudioBySize}, videoSize: ${likelyVideoBySize}`
      );

      if (isInitSegment) {
        if (isVideoSegment) {
          videoInit = dataArray;
          debugLog(
            `🔧 MEDIABUNNY: Found VIDEO init segment at index ${index}: ${dataArray.length} bytes (by metadata)`
          );
        } else if (isAudioSegment) {
          // Use the FIRST audio init segment found, not subsequent ones
          if (!audioInit) {
            audioInit = dataArray;
            debugLog(
              `🔧 MEDIABUNNY: Found FIRST AUDIO init segment at index ${index}: ${dataArray.length} bytes (by metadata)`
            );
          } else {
            debugLog(
              `🔧 MEDIABUNNY: Skipping additional audio init segment at index ${index}: ${dataArray.length} bytes (already have audio init)`
            );
          }
        } else if (likelyVideoBySize && !videoInit) {
          // Fallback: first init segment is video
          videoInit = dataArray;
          debugLog(
            `🔧 MEDIABUNNY: Found VIDEO init segment (size fallback) at index ${index}: ${dataArray.length} bytes`
          );
        } else if (likelyAudioBySize && !audioInit) {
          // Second init segment is audio
          audioInit = dataArray;
          debugLog(
            `🔧 MEDIABUNNY: Found AUDIO init segment (size fallback) at index ${index}: ${dataArray.length} bytes`
          );
        }
      } else {
        // Media segment - PRIORITIZE METADATA over size-based heuristics
        if (isVideoSegment) {
          videoMediaSegments.push(dataArray);
          debugLog(
            `🔧 MEDIABUNNY: Added video media segment ${index}: ${dataArray.length} bytes (by metadata)`
          );
        } else if (isAudioSegment) {
          audioMediaSegments.push(dataArray);
          debugLog(
            `🔧 MEDIABUNNY: Added audio media segment ${index}: ${dataArray.length} bytes (by metadata)`
          );
        } else if (likelyVideoBySize || dataArray.length > 100000) {
          videoMediaSegments.push(dataArray);
          debugLog(
            `🔧 MEDIABUNNY: Added video media segment ${index}: ${dataArray.length} bytes (by size fallback)`
          );
        } else if (likelyAudioBySize || dataArray.length < 100000) {
          audioMediaSegments.push(dataArray);
          debugLog(
            `🔧 MEDIABUNNY: Added audio media segment ${index}: ${dataArray.length} bytes (by size fallback)`
          );
        }
      }
    });

    debugLog(
      `🔧 MEDIABUNNY: Found ${videoMediaSegments.length} video segments and ${audioMediaSegments.length} audio segments`
    );

    // Fallback: if no init segments detected, treat first small segments as init
    if (!videoInit) {
      debugLog(
        `🔧 MEDIABUNNY: No video init found by structure analysis, trying fallback...`
      );

      // Look for first small segment as potential init
      for (let i = 0; i < Math.min(5, segments.length); i++) {
        const segment = segments[i];
        const segmentData = segment.data || segment;
        const dataArray =
          segmentData instanceof Uint8Array
            ? segmentData
            : new Uint8Array(segmentData);

        if (dataArray.length < 100000) {
          // < 100KB likely init segment
          videoInit = dataArray;
          debugLog(
            `🔧 MEDIABUNNY: Using segment ${i} as video init (${dataArray.length} bytes)`
          );

          // Remove this from media segments if it was added
          const index = videoMediaSegments.findIndex(
            (seg) => seg.length === dataArray.length
          );
          if (index >= 0) {
            videoMediaSegments.splice(index, 1);
            debugLog(`🔧 MEDIABUNNY: Removed from video media segments`);
          }
          break;
        }
      }
    }

    // Ensure we have proper audio init segment as well
    if (!audioInit && audioMediaSegments.length > 0) {
      debugLog(
        `🔧 MEDIABUNNY: No audio init found, looking for FIRST audio init segment...`
      );

      // Try to find the FIRST audio init segment by looking for small segments with audio-like characteristics
      for (let i = 0; i < segments.length; i++) {
        const segment = segments[i];
        const segmentData = segment.data || segment;
        const dataArray =
          segmentData instanceof Uint8Array
            ? segmentData
            : new Uint8Array(segmentData);

        // Look for small segments that might be audio init
        if (dataArray.length < 50000 && dataArray.length > 100) {
          const boxType = getMP4BoxType(dataArray);
          const containsFtyp =
            boxType === "ftyp" || containsBox(dataArray, "ftyp");
          const containsMoov = containsBox(dataArray, "moov");

          if (containsFtyp || containsMoov) {
            audioInit = dataArray;
            debugLog(
              `🔧 MEDIABUNNY: Found FIRST AUDIO init segment at index ${i}: ${dataArray.length} bytes`
            );

            // Remove from audio media segments if it was added
            const mediaIndex = audioMediaSegments.findIndex(
              (seg) => seg.length === dataArray.length
            );
            if (mediaIndex >= 0) {
              audioMediaSegments.splice(mediaIndex, 1);
              debugLog(`🔧 MEDIABUNNY: Removed audio init from media segments`);
            }
            break; // Use the FIRST one found
          }
        }
      }
    }

    if (!videoInit) {
      throw new Error(
        "No video initialization segment found - unable to process DASH stream"
      );
    }

    if (!audioInit && audioMediaSegments.length > 0) {
      throw new Error(
        "No audio initialization segment found - cannot create playable audio MP4"
      );
    }

    if (videoMediaSegments.length === 0) {
      throw new Error("No video media segments found");
    }

    // Create two complete MP4 streams - one for video, one for audio
    debugLog(`🔧 MEDIABUNNY: Creating complete video MP4...`);

    // Build complete video MP4
    const videoDataSize = videoMediaSegments.reduce(
      (total, seg) => total + seg.length,
      0
    );
    const videoMP4Size = videoInit.length + videoDataSize;
    const videoMP4Data = new Uint8Array(videoMP4Size);

    videoMP4Data.set(videoInit, 0);
    let offset = videoInit.length;

    for (const segment of videoMediaSegments) {
      videoMP4Data.set(segment, offset);
      offset += segment.length;
    }

    debugLog(`🔧 MEDIABUNNY: Complete video MP4: ${videoMP4Data.length} bytes`);

    // Build complete audio MP4 if we have audio
    let audioMP4Data = null;
    if (audioInit && audioMediaSegments.length > 0) {
      debugLog(`🔧 MEDIABUNNY: Creating complete audio MP4...`);

      const audioDataSize = audioMediaSegments.reduce(
        (total, seg) => total + seg.length,
        0
      );
      const audioMP4Size = audioInit.length + audioDataSize;
      audioMP4Data = new Uint8Array(audioMP4Size);

      audioMP4Data.set(audioInit, 0);
      offset = audioInit.length;

      for (const segment of audioMediaSegments) {
        audioMP4Data.set(segment, offset);
        offset += segment.length;
      }

      debugLog(
        `🔧 MEDIABUNNY: Complete audio MP4: ${audioMP4Data.length} bytes`
      );
    }

    // Create separate video and audio files using MediaBunny
    debugLog(`🔧 MEDIABUNNY: Creating separate video and audio outputs...`);

    try {
      // Process video
      const videoInput = new Input({
        source: new BufferSource(videoMP4Data.buffer),
        formats: ALL_FORMATS,
      });

      const videoOutput = new Output({
        format: new Mp4OutputFormat({
          fastStart: "in-memory",
        }),
        target: new BufferTarget(),
      });

      debugLog(`🔧 MEDIABUNNY: Converting video MP4...`);

      const videoConversion = await Conversion.init({
        input: videoInput,
        output: videoOutput,
      });

    await videoConversion.execute();

    const videoOutputBuffer = videoOutput.target.buffer;
    if (!videoOutputBuffer || videoOutputBuffer.byteLength === 0) {
      throw new Error(
        "MediaBunny video conversion failed - output buffer is empty"
      );
    }

    videoBlob = new Blob([videoOutputBuffer], { type: "video/mp4" });

    debugLog(
      `🔧 MEDIABUNNY: Video conversion completed! Created ${(
        videoBlob.size /
        1024 /
        1024
      ).toFixed(2)} MB MP4 (type: ${typeof videoBlob}, instanceof Blob: ${
        videoBlob instanceof Blob
      })`
    );

    // Process audio if available - try Media Bunny first, fallback to raw data
    if (audioMP4Data) {
      debugLog(`🔧 MEDIABUNNY: Processing audio with Media Bunny...`);

      try {
        const audioInput = new Input({
          source: new BufferSource(audioMP4Data.buffer),
          formats: ALL_FORMATS,
        });

        // Convert audio to MP4 format
        const audioOutput = new Output({
          format: new Mp4OutputFormat({
            fastStart: "in-memory",
          }),
          target: new BufferTarget(),
        });

        debugLog(`🔧 MEDIABUNNY: Converting audio to MP4 format...`);

        const audioConversion = await Conversion.init({
          input: audioInput,
          output: audioOutput,
        });

        await audioConversion.execute();

        const audioOutputBuffer = audioOutput.target.buffer;
        if (!audioOutputBuffer || audioOutputBuffer.byteLength === 0) {
          throw new Error(
            "MediaBunny audio conversion failed - output buffer is empty"
          );
        }

        audioBlob = new Blob([audioOutputBuffer], { type: "audio/mp4" });

        debugLog(
          `🔧 MEDIABUNNY: Audio conversion completed! Created ${(
            audioBlob.size /
            1024 /
            1024
          ).toFixed(2)} MB MP4 (type: ${typeof audioBlob}, instanceof Blob: ${
            audioBlob instanceof Blob
          })`
        );
      } catch (audioError) {
        debugLog(
          `🔧 MEDIABUNNY: Audio MP4 conversion failed: ${audioError.message}`
        );
        debugLog(`🔧 MEDIABUNNY: Trying alternative MP4 format fallback...`);

        try {
          const audioInput = new Input({
            source: new BufferSource(audioMP4Data.buffer),
            formats: ALL_FORMATS,
          });

          const audioOutput = new Output({
            format: new Mp4OutputFormat({
              fastStart: "in-memory",
            }),
            target: new BufferTarget(),
          });

          const audioConversion = await Conversion.init({
            input: audioInput,
            output: audioOutput,
          });

          await audioConversion.execute();

          const audioOutputBuffer = audioOutput.target.buffer;
          if (!audioOutputBuffer || audioOutputBuffer.byteLength === 0) {
            throw new Error(
              "MediaBunny audio MP4 conversion failed - output buffer is empty"
            );
          }

          audioBlob = new Blob([audioOutputBuffer], { type: "audio/mp4" });

          debugLog(
            `🔧 MEDIABUNNY: Audio MP4 fallback completed! Created ${(
              audioBlob.size /
              1024 /
              1024
            ).toFixed(2)} MB MP4 (type: ${typeof audioBlob}, instanceof Blob: ${
              audioBlob instanceof Blob
            })`
          );
        } catch (mp4Error) {
          debugLog(
            `🔧 MEDIABUNNY: Audio MP4 fallback also failed: ${mp4Error.message}`
          );
          throw new Error(
            `Audio processing failed - Media Bunny cannot process the audio format. WebM error: ${audioError.message}, MP4 error: ${mp4Error.message}`
          );
        }
      }
    }

    } catch (mediaBunnyError) {
      debugLog(`🔧 MEDIABUNNY: MediaBunny processing failed: ${mediaBunnyError.message}`);
      debugLog(`🔧 MEDIABUNNY: Falling back to direct file download approach...`);
      
      // Fallback: Download the concatenated files directly without MediaBunny processing
      videoBlob = new Blob([videoMP4Data], { type: "video/mp4" });
      audioBlob = audioMP4Data ? new Blob([audioMP4Data], { type: "audio/mp4" }) : null;
      
      debugLog(`🔧 MEDIABUNNY: Fallback - Video file: ${(videoBlob.size / 1024 / 1024).toFixed(2)} MB`);
      if (audioBlob) {
        debugLog(`🔧 MEDIABUNNY: Fallback - Audio file: ${(audioBlob.size / 1024 / 1024).toFixed(2)} MB`);
      }
      
      // Return the blobs to the calling function for download
      // The calling function will handle the actual download with proper filenames
      return { 
        videoBlob, 
        audioBlob,
        success: true,
        message: "Processed as separate video and audio files (MediaBunny fallback)"
      };
    }

    // Try to mux video and audio into a single file using MediaBunny with media sources
    if (videoBlob && audioBlob) {
      try {
        debugLog(
          `🔧 MEDIABUNNY: Attempting to mux video and audio MP4s using media sources...`
        );
        const muxedBlob = await muxDashStreamsWithMediaBunny(
          videoBlob,
          audioBlob
        );
        if (muxedBlob && muxedBlob.size > 0) {
          debugLog(
            `🔧 MEDIABUNNY: Successfully muxed! Returning single combined MP4 (${(
              muxedBlob.size /
              1024 /
              1024
            ).toFixed(2)} MB)`
          );
          return muxedBlob; // Return single combined blob
        }
      } catch (muxError) {
        debugLog(
          `🔧 MEDIABUNNY: Muxing failed: ${muxError.message}, falling back to separate files`
        );
        // Fall back to returning separate files
      }
    }

    // Return both video and audio blobs as fallback
    return { videoBlob, audioBlob };
  } catch (error) {
    debugLog(`🔧 MEDIABUNNY: Conversion failed: ${error.message}`);
    debugLog(`🔧 MEDIABUNNY: Error stack: ${error.stack}`);
    throw error;
  }
}

// Helper function to identify MP4 box types
function getMP4BoxType(data) {
  if (data.length < 8) return "unknown";

  // MP4 boxes have 4-byte size followed by 4-byte type
  const type = String.fromCharCode(data[4], data[5], data[6], data[7]);

  // Common MP4 box types
  const knownTypes = [
    "ftyp",
    "moov",
    "moof",
    "mdat",
    "free",
    "skip",
    "wide",
    "pdin",
    "meco",
    "styp",
  ];

  if (knownTypes.includes(type)) {
    return type;
  }

  return "unknown";
}

// Helper function to check if data contains a specific box type
function containsBox(data, boxType) {
  const searchBytes = new TextEncoder().encode(boxType);

  for (let i = 0; i < data.length - 4; i++) {
    let match = true;
    for (let j = 0; j < 4; j++) {
      if (data[i + j] !== searchBytes[j]) {
        match = false;
        break;
      }
    }
    if (match) return true;
  }

  return false;
}

// Parse MPD XML data to extract timing information
function parseMpdData(mpdData) {
  try {
    // Handle different MPD data formats
    let mpdXml = "";
    if (typeof mpdData === "string") {
      mpdXml = mpdData;
    } else if (mpdData.mpdContent) {
      mpdXml = mpdData.mpdContent;
    } else if (mpdData.manifestContent) {
      mpdXml = mpdData.manifestContent;
    } else {
      debugLog(`🔧 DASH MPD: Unknown data format, using defaults`);
      mpdXml = "";
    }

    debugLog(`🔧 DASH MPD: Processing XML length: ${mpdXml.length} chars`);

    // Extract total duration from MPD (PT509.037S format)
    let totalDuration = 509.037; // Default
    const durationMatch = mpdXml.match(
      /mediaPresentationDuration="PT([\d.]+)S"/
    );
    if (durationMatch) {
      totalDuration = parseFloat(durationMatch[1]);
      debugLog(`🔧 DASH MPD: Found duration: ${totalDuration}s`);
    }

    // Extract timescale (default 1000000 = microseconds)
    const timescale = 1000000;

    // Parse segment timeline from MPD data
    const segmentTimeline = {
      video: [],
      audio: [],
    };

    // Parse audio AdaptationSet (contentType="audio")
    const audioAdaptationMatch = mpdXml.match(
      /<AdaptationSet[^>]*contentType="audio"[^>]*>.*?<\/AdaptationSet>/s
    );
    if (audioAdaptationMatch) {
      const audioSection = audioAdaptationMatch[0];
      const audioTimelineMatches = [
        ...audioSection.matchAll(/<S t="(\d+)" d="(\d+)"/g),
      ];
      audioTimelineMatches.forEach((match) => {
        const t = parseInt(match[1]);
        const d = parseInt(match[2]);
        segmentTimeline.audio.push({ t, d });
      });
      debugLog(
        `🔧 DASH MPD: Found ${segmentTimeline.audio.length} audio timeline entries`
      );
    }

    // Parse video AdaptationSet (look for one without contentType="audio" that has video data)
    const allAdaptationSets = [
      ...mpdXml.matchAll(/<AdaptationSet[^>]*>.*?<\/AdaptationSet>/gs),
    ];
    for (const adaptationSet of allAdaptationSets) {
      const section = adaptationSet[0];
      // Skip if it's the audio adaptation set
      if (section.includes('contentType="audio"')) continue;

      // Look for video-related content (bandwidth usually higher for video)
      const representations = [
        ...section.matchAll(/<Representation[^>]*bandwidth="(\d+)"[^>]*>/g),
      ];
      const hasHighBandwidth = representations.some(
        (rep) => parseInt(rep[1]) > 500000
      ); // > 500kbps likely video

      if (hasHighBandwidth) {
        const videoTimelineMatches = [
          ...section.matchAll(/<S t="(\d+)" d="(\d+)"/g),
        ];
        videoTimelineMatches.forEach((match) => {
          const t = parseInt(match[1]);
          const d = parseInt(match[2]);
          segmentTimeline.video.push({ t, d });
        });
        debugLog(
          `🔧 DASH MPD: Found ${segmentTimeline.video.length} video timeline entries`
        );
        break; // Use first video adaptation set found
      }
    }

    debugLog(
      `🔧 DASH MPD: Final parsed ${segmentTimeline.video.length} video + ${segmentTimeline.audio.length} audio timeline entries`
    );

    return { totalDuration, timescale, segmentTimeline };
  } catch (error) {
    debugLog(`🔧 DASH MPD: Parse failed, using defaults: ${error.message}`);
    return {
      totalDuration: 509.037,
      timescale: 1000000,
      segmentTimeline: { video: [], audio: [] },
    };
  }
}

// Process A/V segments with FastStream
async function processAVSegmentsWithFastStream(
  videoSegments,
  audioSegments,
  fileName,
  totalDuration = null,
  options = {}
) {
  debugLog(
    `🔍 Processing ${videoSegments.length} video and ${audioSegments.length} audio segments with FastStream`
  );

  const baseFileName = fileName.replace(/\.(webm|mkv|avi|ts|mp4)$/i, "");
  const outputFileName = `${baseFileName}.mp4`;

  try {
    // Check if this is DASH content
    if (options.isDASH) {
      debugLog(`🔍 Detected DASH A/V segments, using proper DASH processing`);
      // Properly analyze segments before processing (like Vimeo handler does)
      const analyzedSegments = [
        ...videoSegments.map((segment) => ({
          data: segment.data,
          segmentType: segment.segmentType || 'video',
          mimeType: segment.mimeType || 'video/mp4',
          isInitSegment: segment.isInitSegment || false,
          segmentIndex: segment.segmentIndex || 0
        })),
        ...audioSegments.map((segment) => ({
          data: segment.data,
          segmentType: segment.segmentType || 'audio',
          mimeType: segment.mimeType || 'audio/mp4',
          isInitSegment: segment.isInitSegment || false,
          segmentIndex: segment.segmentIndex || 0
        }))
      ];
      debugLog(`🔍 Analyzed ${analyzedSegments.length} segments with proper metadata`);
      const result = await processDashSegments(
        analyzedSegments,
        options.mpdData || {}
      );

      // Download the result - handle separate video and audio files for DASH
      const baseFileName = fileName.replace(/\.(webm|mkv|avi|ts|mp4)$/i, "");
      let totalSize = 0;

      // Check if we got separate video and audio blobs
      if (result.videoBlob || result.audioBlob) {
        debugLog(`🔍 DASH A/V: Downloading separate video and audio files`);

        // Download video file
        if (result.videoBlob && result.videoBlob instanceof Blob) {
          const videoFileName = `${baseFileName}_video.mp4`;
          debugLog(
            `🔍 DASH A/V: Creating video download URL for ${result.videoBlob.size} bytes...`
          );
          const videoBlobUrl = URL.createObjectURL(result.videoBlob);
          const videoLink = document.createElement("a");
          videoLink.href = videoBlobUrl;
          videoLink.download = videoFileName;
          document.body.appendChild(videoLink);
          videoLink.click();
          document.body.removeChild(videoLink);
          setTimeout(() => URL.revokeObjectURL(videoBlobUrl), 1000);
          totalSize += result.videoBlob.size;
          debugLog(`🔍 DASH A/V: Downloaded video file: ${videoFileName}`);

          // Send completion notification
          try {
            chrome.runtime
              .sendMessage({
                type: "DOWNLOAD_COMPLETE_NOTIFICATION",
                fileName: videoFileName,
              })
              .catch(() => {});
          } catch (error) {}
        }

        // Download audio file
        if (result.audioBlob && result.audioBlob instanceof Blob) {
          // Determine file extension based on audio blob type
          const audioExtension = result.audioBlob.type.includes("webm")
            ? "webm"
            : "mp4";
          const audioFileName = `${baseFileName}_audio.${audioExtension}`;
          debugLog(
            `🔍 DASH A/V: Creating audio download URL for ${result.audioBlob.size} bytes (${result.audioBlob.type})...`
          );
          const audioBlobUrl = URL.createObjectURL(result.audioBlob);
          const audioLink = document.createElement("a");
          audioLink.href = audioBlobUrl;
          audioLink.download = audioFileName;
          document.body.appendChild(audioLink);
          audioLink.click();
          document.body.removeChild(audioLink);
          setTimeout(() => URL.revokeObjectURL(audioBlobUrl), 1000);
          totalSize += result.audioBlob.size;
          debugLog(`🔍 DASH A/V: Downloaded audio file: ${audioFileName}`);

          // Send completion notification
          try {
            chrome.runtime
              .sendMessage({
                type: "DOWNLOAD_COMPLETE_NOTIFICATION",
                fileName: audioFileName,
              })
              .catch(() => {});
          } catch (error) {}
        }

        return {
          fileName: `${baseFileName}_video.mp4 + ${baseFileName}_audio.mp4`,
          size: totalSize,
          success: true,
        };
      } else {
        // Fallback for single blob result
        const outputFileName = baseFileName + ".webm";
        const blobUrl = URL.createObjectURL(result);
        const a = document.createElement("a");
        a.href = blobUrl;
        a.download = outputFileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

        // Send completion notification
        try {
          chrome.runtime
            .sendMessage({
              type: "DOWNLOAD_COMPLETE_NOTIFICATION",
              fileName: outputFileName,
            })
            .catch(() => {});
        } catch (error) {}

        return {
          fileName: outputFileName,
          size: result.size,
          success: true,
        };
      }
    }

    // Check if this is FMP4 content (based on source URL or stream format)
    const isFMP4Stream = 
      options.streamFormat === "fmp4" ||
      options.sourceUrl?.includes("sf=fmp4") ||
      options.sourceUrl?.includes("format=fmp4") ||
      (videoSegments.length > 0 && isSegmentFMP4(videoSegments[0].data));

    if (isFMP4Stream) {
      debugLog(`🔍 Detected FMP4 A/V segments, using MediaBunny proper conversion`);
      
      // Use MediaBunny's proper conversion API for FMP4 segments
      debugLog(`🔍 Creating MediaBunny Input from FMP4 segments`);
      
      // Process video and audio segments separately to avoid timestamp conflicts
      debugLog(`🔍 Processing video and audio segments separately for MediaBunny`);
      
      // Create separate video and audio streams
      let videoSize = 0;
      videoSegments.forEach(segment => {
        if (segment.data instanceof ArrayBuffer) {
          videoSize += segment.data.byteLength;
        } else if (segment.data instanceof Uint8Array) {
          videoSize += segment.data.byteLength;
        } else {
          videoSize += segment.data.size || 0;
        }
      });
      
      let audioSize = 0;
      audioSegments.forEach(segment => {
        if (segment.data instanceof ArrayBuffer) {
          audioSize += segment.data.byteLength;
        } else if (segment.data instanceof Uint8Array) {
          audioSize += segment.data.byteLength;
        } else {
          audioSize += segment.data.size || 0;
        }
      });
      
      const videoBuffer = new Uint8Array(videoSize);
      let videoOffset = 0;
      
      for (const segment of videoSegments) {
        let data;
        if (segment.data instanceof ArrayBuffer) {
          data = new Uint8Array(segment.data);
        } else if (segment.data instanceof Uint8Array) {
          data = segment.data;
        } else if (segment.data instanceof Blob) {
          data = new Uint8Array(await segment.data.arrayBuffer());
        } else {
          data = new Uint8Array(segment.data);
        }
        
        videoBuffer.set(data, videoOffset);
        videoOffset += data.byteLength;
      }
      
      const audioBuffer = new Uint8Array(audioSize);
      let audioOffset = 0;
      
      for (const segment of audioSegments) {
        let data;
        if (segment.data instanceof ArrayBuffer) {
          data = new Uint8Array(segment.data);
        } else if (segment.data instanceof Uint8Array) {
          data = segment.data;
        } else if (segment.data instanceof Blob) {
          data = new Uint8Array(await segment.data.arrayBuffer());
        } else {
          data = new Uint8Array(segment.data);
        }
        
        audioBuffer.set(data, audioOffset);
        audioOffset += data.byteLength;
      }
      
      debugLog(`🔍 Created separate video buffer: ${(videoBuffer.byteLength / 1024 / 1024).toFixed(2)} MB`);
      debugLog(`🔍 Created separate audio buffer: ${(audioBuffer.byteLength / 1024 / 1024).toFixed(2)} MB`);
      
      // Use MediaBunny for proper FMP4 conversion
      try {
        debugLog(`🔍 Loading MediaBunny for proper FMP4 conversion`);
        
        const {
          Input,
          Output, 
          Conversion,
          ALL_FORMATS,
          BufferSource,
          Mp4OutputFormat,
          BufferTarget,
          EncodedVideoPacketSource,
          EncodedAudioPacketSource,
          EncodedPacketSink
        } = await import("./modules/mediabunny/dist/modules/src/index.js");
        
        debugLog(`🔍 MediaBunny loaded successfully, creating separate video and audio inputs`);
        
        // Create separate inputs for video and audio to avoid timestamp conflicts
        const videoInput = new Input({
          formats: ALL_FORMATS,
          source: new BufferSource(videoBuffer.buffer),
        });
        
        const audioInput = new Input({
          formats: ALL_FORMATS,
          source: new BufferSource(audioBuffer.buffer),
        });
        
        const output = new Output({
          format: new Mp4OutputFormat(),
          target: new BufferTarget(),
        });
        
        debugLog(`🔍 Getting video and audio tracks from separate inputs`);
        
        // Get tracks from separate inputs
        const videoTrack = await videoInput.getPrimaryVideoTrack();
        const audioTrack = await audioInput.getPrimaryAudioTrack();
        
        if (!videoTrack) {
          throw new Error('No video track found in video input');
        }
        if (!audioTrack) {
          throw new Error('No audio track found in audio input');
        }
        
        debugLog(`🔍 Starting MediaBunny muxing with separate tracks`);
        debugLog(`🔍 Video track codec: ${videoTrack.codec}, Audio track codec: ${audioTrack.codec}`);
        
        // Add tracks before starting
        const videoSource = new EncodedVideoPacketSource(videoTrack.codec);
        output.addVideoTrack(videoSource);
        debugLog(`🔍 Added video track to output`);
        
        const audioSource = new EncodedAudioPacketSource(audioTrack.codec);
        output.addAudioTrack(audioSource);
        debugLog(`🔍 Added audio track to output`);
        
        // Start the output after adding tracks
        debugLog(`🔍 Starting output with ${output.tracks?.length || 'unknown'} tracks`);
        await output.start();
        debugLog(`🔍 Output started successfully`);
        
        // Get video packets and add them with metadata
        const videoSink = new EncodedPacketSink(videoTrack);
        const videoDecoderConfig = await videoTrack.getDecoderConfig();
        let isFirstVideoPacket = true;
        
        for await (const packet of videoSink.packets()) {
          if (isFirstVideoPacket) {
            await videoSource.add(packet, {
              decoderConfig: videoDecoderConfig
            });
            isFirstVideoPacket = false;
          } else {
            await videoSource.add(packet);
          }
        }
        await videoSource.close();
        
        // Get audio packets and add them with metadata
        const audioSink = new EncodedPacketSink(audioTrack);
        const audioDecoderConfig = await audioTrack.getDecoderConfig();
        let isFirstAudioPacket = true;
        
        for await (const packet of audioSink.packets()) {
          if (isFirstAudioPacket) {
            await audioSource.add(packet, {
              decoderConfig: audioDecoderConfig
            });
            isFirstAudioPacket = false;
          } else {
            await audioSource.add(packet);
          }
        }
        await audioSource.close();
        
        // Finalize the output
        await output.finalize();
        
        debugLog(`🔍 MediaBunny conversion completed successfully`);
        
        const resultBuffer = output.target.buffer;
        const resultBlob = new Blob([resultBuffer], { type: 'video/mp4' });
        
        // Download the result
        const blobUrl = URL.createObjectURL(resultBlob);
        const a = document.createElement("a");
        a.href = blobUrl;
        a.download = outputFileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

        debugLog(`🔍 ✅ MediaBunny FMP4 Download initiated for ${outputFileName}`);

        // Send completion notification
        try {
          chrome.runtime
            .sendMessage({
              type: "DOWNLOAD_COMPLETE_NOTIFICATION",
              fileName: outputFileName,
            })
            .catch(() => {});
        } catch (error) {}

        return {
          fileName: outputFileName,
          size: resultBlob.size,
          success: true,
        };
        
      } catch (error) {
        debugLog(`🔍 MediaBunny conversion failed: ${error.message}`);
        debugLog(`🔍 Falling back to simple concatenation`);
        
        // Fallback to simple concatenation - combine video and audio buffers
        const combinedSize = videoBuffer.byteLength + audioBuffer.byteLength;
        const combinedBuffer = new Uint8Array(combinedSize);
        combinedBuffer.set(videoBuffer, 0);
        combinedBuffer.set(audioBuffer, videoBuffer.byteLength);
        
        const resultBlob = new Blob([combinedBuffer], { type: 'video/mp4' });
        
        // Download the result
        const blobUrl = URL.createObjectURL(resultBlob);
        const a = document.createElement("a");
        a.href = blobUrl;
        a.download = outputFileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

        debugLog(`🔍 ✅ Fallback FMP4 Download initiated for ${outputFileName}`);

        // Send completion notification
        try {
          chrome.runtime
            .sendMessage({
              type: "DOWNLOAD_COMPLETE_NOTIFICATION",
              fileName: outputFileName,
            })
            .catch(() => {});
        } catch (error) {}

        return {
          fileName: outputFileName,
          size: resultBlob.size,
          success: true,
        };
      }
    }

    // Create converter with progress tracking
    const converter = new SimpleHLS2MP4Converter({
      onProgress: (progress) => {
        debugLog(`🔍 A/V Conversion progress: ${(progress * 100).toFixed(1)}%`);
      },
    });

    // For separate A/V tracks, we need to create separate level objects
    // and use pushFragment and pushFragmentAudio separately
    debugLog(`🔍 Setting up separate A/V conversion`);

    // Create the FastStream converter manually for separate A/V
    const { HLS2MP4 } = await import("./modules/hls2mp4/hls2mp4.mjs");
    const hls2mp4 = new HLS2MP4();

    // Set up progress tracking
    hls2mp4.on("progress", (progress) => {
      debugLog(`🔍 A/V FastStream progress: ${(progress * 100).toFixed(1)}%`);
    });

    // Create level objects for video and audio
    const calculatedDuration =
      totalDuration || Math.max(videoSegments.length, audioSegments.length) * 2;

    const videoLevel = {
      audioCodec: "mp4a.40.2",
      videoCodec: "avc1.42E01E",
      details: {
        totalduration: calculatedDuration,
      },
    };

    const audioLevel = {
      audioCodec: "mp4a.40.2",
      videoCodec: "",
      details: {
        totalduration: calculatedDuration,
      },
    };

    // Setup the converter
    hls2mp4.setup(videoLevel, null, audioLevel, null);

    // Process video segments in batches of 20
    const BATCH_SIZE = 20;
    for (
      let batchStart = 0;
      batchStart < videoSegments.length;
      batchStart += BATCH_SIZE
    ) {
      const batchEnd = Math.min(batchStart + BATCH_SIZE, videoSegments.length);
      const batch = videoSegments.slice(batchStart, batchEnd);

      // Process batch in parallel
      await Promise.all(
        batch.map(async (segment, batchIndex) => {
          const i = batchStart + batchIndex;
          const segmentData = segment.data;
          let arrayBuffer;

          if (segmentData instanceof ArrayBuffer) {
            arrayBuffer = segmentData;
          } else if (segmentData instanceof Uint8Array) {
            arrayBuffer = segmentData.buffer;
          } else if (segmentData instanceof Blob) {
            arrayBuffer = await segmentData.arrayBuffer();
          } else {
            const blob = new Blob([segmentData]);
            arrayBuffer = await blob.arrayBuffer();
          }

          const fragment = {
            fragment: {
              sn: i,
              cc: 0,
            },
            async getEntry() {
              return {
                async getDataFromBlob() {
                  return arrayBuffer;
                },
              };
            },
          };

          await hls2mp4.pushFragment(fragment);
        })
      );
    }

    // Process audio segments in batches of 20
    for (
      let batchStart = 0;
      batchStart < audioSegments.length;
      batchStart += BATCH_SIZE
    ) {
      const batchEnd = Math.min(batchStart + BATCH_SIZE, audioSegments.length);
      const batch = audioSegments.slice(batchStart, batchEnd);

      // Process batch in parallel
      await Promise.all(
        batch.map(async (segment, batchIndex) => {
          const i = batchStart + batchIndex;
          const segmentData = segment.data;
          let arrayBuffer;

          if (segmentData instanceof ArrayBuffer) {
            arrayBuffer = segmentData;
          } else if (segmentData instanceof Uint8Array) {
            arrayBuffer = segmentData.buffer;
          } else if (segmentData instanceof Blob) {
            arrayBuffer = await segmentData.arrayBuffer();
          } else {
            const blob = new Blob([segmentData]);
            arrayBuffer = await blob.arrayBuffer();
          }

          const fragment = {
            fragment: {
              sn: i,
              cc: 0,
            },
            async getEntry() {
              return {
                async getDataFromBlob() {
                  return arrayBuffer;
                },
              };
            },
          };

          await hls2mp4.pushFragmentAudio(fragment);
        })
      );
    }

    // Finalize and get the result
    const outputBlob = await hls2mp4.finalize();

    debugLog(`🔍 ✅ A/V FastStream conversion completed`);

    debugLog(
      `🔍 Output file size: ${(outputBlob.size / 1024 / 1024).toFixed(2)} MB`
    );

    // Trigger download
    const blobUrl = URL.createObjectURL(outputBlob);
    const a = document.createElement("a");
    a.href = blobUrl;
    a.download = outputFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    debugLog(`🔍 ✅ Download initiated for ${outputFileName}`);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);

    // Send completion notification
    try {
      chrome.runtime
        .sendMessage({
          type: "DOWNLOAD_COMPLETE_NOTIFICATION",
          fileName: outputFileName,
        })
        .catch(() => {});
    } catch (error) {}

    // Clean up
    hls2mp4.destroy();

    return {
      fileName: outputFileName,
      size: outputBlob.size,
      success: true,
    };
  } catch (error) {
    debugLog(`🔍 A/V Processing failed: ${error.message}`);
    throw error;
  }
}

// HLS segments merge using FastStream
async function mergeSegmentsWithFastStream(request) {
  debugLog("🔄 Starting FastStream segments merge...");

  const {
    requestId,
    segmentsKey,
    fileName,
    totalSegments,
    totalDuration,
    isDashStream,
    streamFormat,
    sourceUrl,
    manifestContent,
  } = request;

  console.log("🕐 FastStream received totalDuration:", totalDuration);

  try {
    chrome.runtime
      .sendMessage({
        type: "DEBUG_MESSAGE",
        message: `🔄 FASTSTREAM OFFSCREEN: Starting HLS merge for ${totalSegments} segments`,
      })
      .catch(() => {});
  } catch (error) {}

  try {
    const segments = await loadAllSegments(segmentsKey, totalSegments);

    if (segments.length === 0) {
      throw new Error("No segments found");
    }

    const result = await processSegmentsWithFastStream(
      segments,
      fileName,
      totalDuration,
      {
        isDASH: isDashStream,
        streamFormat: streamFormat,
        sourceUrl: sourceUrl,
        manifestContent: manifestContent,
      }
    );

    debugLog(`🔍 ✅ FastStream merge completed successfully`);

    try {
      chrome.runtime
        .sendMessage({
          type: "MERGE_SEGMENTS_RESPONSE",
          success: true,
          requestId: requestId,
          downloadInitiated: true,
          splitIntoMultipleParts: false,
          totalParts: 1,
          successfulParts: 1,
          failedParts: 0,
          results: [result],
        })
        .catch(() => {});
    } catch (error) {}
  } catch (error) {
    debugLog(`🔍 ❌ FastStream merge failed: ${error.message}`);
    console.error("❌ FastStream segments merge failed:", error);

    try {
      chrome.runtime
        .sendMessage({
          type: "MERGE_SEGMENTS_RESPONSE",
          success: false,
          requestId: requestId,
          error: {
            message: error.message,
            stack: error.stack,
            name: error.name,
          },
        })
        .catch(() => {});
    } catch (error) {}
  }
}

// A/V segments merge using FastStream
async function mergeSeparateAVSegmentsWithFastStream(request) {
  debugLog("🔄 Starting FastStream A/V segments merge...");

  const {
    requestId,
    segmentsKey,
    fileName,
    totalSegments,
    videoCount,
    audioCount,
    totalDuration,
    isDashStream,
    mpdContent,
    streamFormat,
    sourceUrl,
    manifestContent,
  } = request;

  try {
    chrome.runtime
      .sendMessage({
        type: "DEBUG_MESSAGE",
        message: `🔄 FASTSTREAM OFFSCREEN: Starting A/V merge (${videoCount} video, ${audioCount} audio)`,
      })
      .catch(() => {});
  } catch (error) {}

  try {
    const { videoSegments, audioSegments } = await loadSeparateAVSegments(
      segmentsKey,
      totalSegments,
      videoCount,
      audioCount
    );

    if (videoSegments.length === 0) {
      throw new Error("No video segments found");
    }

    const result = await processAVSegmentsWithFastStream(
      videoSegments,
      audioSegments,
      fileName,
      totalDuration,
      {
        isDASH: isDashStream,
        mpdData: mpdContent,
        streamFormat: streamFormat,
        sourceUrl: sourceUrl,
        manifestContent: manifestContent,
      }
    );

    debugLog(`🔍 ✅ FastStream A/V merge completed successfully`);

    try {
      chrome.runtime
        .sendMessage({
          type: "MERGE_SEPARATE_AV_RESPONSE",
          success: true,
          requestId: requestId,
          downloadInitiated: true,
          splitIntoMultipleParts: false,
          totalParts: 1,
          successfulParts: 1,
          failedParts: 0,
          results: [result],
        })
        .catch(() => {});
    } catch (error) {}
  } catch (error) {
    console.error("❌ FastStream A/V merge failed:", error);
    try {
      chrome.runtime
        .sendMessage({
          type: "MERGE_SEPARATE_AV_RESPONSE",
          success: false,
          requestId: requestId,
          error: {
            message: error.message,
            stack: error.stack,
            name: error.name,
          },
        })
        .catch(() => {});
    } catch (error) {}
  }
}

// Initialize the module
async function initialize() {
  debugLog("🔄 Initializing FastStream offscreen document...");

  const success = await loadModules();
  if (!success) {
    debugLog("❌ Module loading failed");
    return;
  }

  // Message listener
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("🔔 FastStream Offscreen received message:", request);
    debugLog(`🔍 MESSAGE: Received ${request.type} message`);

    if (request.type === "MERGE_SEGMENTS_FASTSTREAM") {
      mergeSegmentsWithFastStream(request);
    } else if (request.type === "MERGE_SEPARATE_AV_FASTSTREAM") {
      mergeSeparateAVSegmentsWithFastStream(request);
    } else if (request.type === "PING") {
      console.log("Received PING, sending PONG");
      sendResponse({ type: "PONG", testId: request.testId });
      return true;
    }

    return false;
  });

  // Signal readiness
  console.log("✅ FastStream Offscreen document ready");
  try {
    chrome.runtime
      .sendMessage({ type: "FASTSTREAM_OFFSCREEN_READY" })
      .catch(() => {});
  } catch (error) {}
}

// Start initialization when script loads
initialize();
