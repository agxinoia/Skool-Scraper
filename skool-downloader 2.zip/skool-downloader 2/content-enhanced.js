// =================================================================================================
//
//        UNIFIED CONTENT SCRIPT - LOOM & VIMEO EMBEDDED VIDEO DETECTOR
//
// =================================================================================================

// Prevent multiple executions
if (window.embeddedVideoDetectorLoaded) {
} else {
  window.embeddedVideoDetectorLoaded = true;

  // =================================================================================
  // INDEXEDDB HELPER (for Content Script) - Updated to match offscreen storage
  // =================================================================================
  const DB_NAME = "LoomDownloaderDB";
  const STORE_NAME = "fileStore";
  const DB_VERSION = 1;

  function openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };

      request.onsuccess = (event) => {
        resolve(event.target.result);
      };

      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }

  async function setSegment(key, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, "readwrite");
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(value, key);

      // Wait for the entire transaction to complete, not just the request
      transaction.oncomplete = () => {
        resolve(true);
      };

      transaction.onerror = (event) => {
        reject(event.target.error);
      };

      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }

  async function getSegment(key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, "readonly");
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(key);
      request.onsuccess = (event) => resolve(event.target.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }

  async function verifyAllSegments(downloadId, totalSegments) {
    console.error(
      `🔍🔍 VERIFY FUNCTION CALLED: ${totalSegments} segments, downloadId: ${downloadId}`
    );

    for (let i = 0; i < totalSegments; i++) {
      const segmentKey = `skool_segment_${downloadId}_${i}`;

      // Add detailed logging for first few segments
      if (i < 5) {
        console.error(`🔍 Checking segment ${i} with key: ${segmentKey}`);
      }

      const segmentData = await getSegment(segmentKey);

      if (!segmentData) {
        console.error(
          `❌ MISSING SEGMENT ${i}: key=${segmentKey}, data=${segmentData}`
        );
        throw new Error(
          `Segment ${i} not found in storage after download (key: ${segmentKey})`
        );
      }

      // Add detailed logging for first few segments
      if (i < 5) {
        console.error(
          `✅ Segment ${i} found: ${segmentData ? "YES" : "NO"}, size: ${
            segmentData?.size || "unknown"
          }`
        );
      }

      // Log progress for large downloads
      if (i % 50 === 0 && i > 0) {
        console.error(`🔍 Verified ${i}/${totalSegments} segments so far...`);
      }
    }

    console.error(`🔍🔍 ALL ${totalSegments} SEGMENTS VERIFIED SUCCESSFULLY!`);
  }

  // =================================================================================
  // LOOM EMBED DETECTION FUNCTIONS
  // =================================================================================

  /**
   * Finds Loom embeds on third-party websites
   * @returns {object|null} First Loom embed found or null
   */
  function findLoomEmbed() {
    console.log("🔍 Searching for Loom embeds...");

    // Priority 1: Look for Loom iframes (most reliable for embeds)
    const iframe = document.querySelector(
      'iframe[src*="loom.com/embed"], iframe[src*="loom.com/share"]'
    );
    if (iframe && iframe.src) {
      const videoId = iframe.src.match(/(?:embed|share)\/([a-f0-9]{32})/)?.[1];
      if (videoId) {
        console.log("✅ Found Loom iframe embed:", videoId);

        // Find Loom thumbnail by checking all script tags (most reliable method)
        let thumbnail = null;

        console.log(
          "🔍 Searching for Loom thumbnail in scripts for video ID:",
          videoId
        );

        const scripts = document.querySelectorAll("script");
        for (const script of scripts) {
          const content = script.textContent || script.innerHTML;
          if (content) {
            // Look for any Loom thumbnail URLs in script content
            const thumbnailRegex =
              /https?:\/\/[^"'\s]*loom[^"'\s]*thumbnail[^"'\s]*\.(gif|jpg|jpeg|png|webp)/gi;
            const thumbnailMatches = content.match(thumbnailRegex);
            if (thumbnailMatches && thumbnailMatches.length > 0) {
              // Prefer thumbnail with our video ID, otherwise use first found
              const matchWithVideoId = thumbnailMatches.find((url) =>
                url.includes(videoId)
              );
              thumbnail = matchWithVideoId || thumbnailMatches[0];
              console.log("✅ Found Loom thumbnail in script:", thumbnail);
              break;
            }

            // Also check for any Loom CDN URLs that might be images
            const cdnRegex =
              /https?:\/\/cdn\.loom\.com\/[^"'\s]+\.(gif|jpg|jpeg|png|webp)/gi;
            const cdnMatches = content.match(cdnRegex);
            if (cdnMatches && cdnMatches.length > 0) {
              const matchWithVideoId = cdnMatches.find((url) =>
                url.includes(videoId)
              );
              thumbnail = matchWithVideoId || cdnMatches[0];
              console.log("✅ Found Loom CDN image in script:", thumbnail);
              break;
            }

            // Check for video ID in content that might have associated thumbnails
            if (content.includes(videoId) && content.includes("loom.com")) {
              // Extract any image URLs from this script
              const imageRegex =
                /https?:\/\/[^"'\s]*\.(gif|jpg|jpeg|png|webp)/gi;
              const imageMatches = content.match(imageRegex);
              if (imageMatches) {
                const loomImage = imageMatches.find((url) =>
                  url.includes("loom.com")
                );
                if (loomImage) {
                  thumbnail = loomImage;
                  console.log(
                    "✅ Found Loom image URL in script with video ID:",
                    thumbnail
                  );
                  break;
                }
              }
            }
          }
        }

        // Fallback: Look for images in DOM
        if (!thumbnail) {
          const allImages = document.querySelectorAll("img");
          for (const img of allImages) {
            if (
              img.src &&
              img.src.includes("loom.com") &&
              img.src.includes(videoId)
            ) {
              thumbnail = img.src;
              console.log(
                "✅ Found Loom thumbnail in DOM fallback:",
                thumbnail
              );
              break;
            }
          }
        }

        console.log("🔍 Loom iframe detection result:", {
          videoId,
          thumbnail: thumbnail
            ? thumbnail.substring(0, 80) + "..."
            : "not found",
        });

        return {
          id: videoId,
          title:
            iframe.title ||
            iframe.getAttribute("aria-label") ||
            `Loom Video ${videoId}`,
          url: `https://www.loom.com/share/${videoId}`,
          embedSrc: iframe.src,
          element: iframe,
          platform: "Loom",
          source: "iframe_embed",
          pageUrl: window.location.href,
          pageTitle: document.title,
          thumbnail: thumbnail,
        };
      }
    }

    // Priority 2: Look for video elements with Loom data attributes
    const videoElement = document.querySelector("video[data-loom-video-id]");
    if (videoElement) {
      const videoId = videoElement.getAttribute("data-loom-video-id");
      if (videoId && videoId.length === 32) {
        console.log("✅ Found Loom video element:", videoId);
        return {
          id: videoId,
          title:
            videoElement.getAttribute("title") ||
            videoElement.getAttribute("aria-label") ||
            `Loom Video ${videoId}`,
          url: `https://www.loom.com/share/${videoId}`,
          element: videoElement,
          platform: "Loom",
          source: "video_element",
          pageUrl: window.location.href,
          pageTitle: document.title,
          thumbnail: videoElement.poster || null,
        };
      }
    }

    // Priority 3: Look for video elements with Loom-related classes or IDs
    const loomVideoElements = document.querySelectorAll(
      'video[id*="Loom"], video[class*="loom"], video[class*="Loom"]'
    );
    for (const video of loomVideoElements) {
      const src = video.src || video.getAttribute("src");
      if (src && src.includes("loom.com")) {
        const videoId = src.match(/([a-f0-9]{32})/)?.[1];
        if (videoId) {
          console.log("✅ Found Loom video by class/ID:", videoId);
          return {
            id: videoId,
            title:
              video.getAttribute("title") ||
              video.getAttribute("aria-label") ||
              `Loom Video ${videoId}`,
            url: `https://www.loom.com/share/${videoId}`,
            element: video,
            platform: "Loom",
            source: "video_src",
            pageUrl: window.location.href,
            pageTitle: document.title,
            thumbnail: video.poster || null,
          };
        }
      }
    }

    // Priority 4: Look for Loom links
    const loomLink = document.querySelector('a[href*="loom.com/share/"]');
    if (loomLink && loomLink.href) {
      const videoId = loomLink.href.match(
        /loom\.com\/share\/([a-f0-9]{32})/
      )?.[1];
      if (videoId) {
        console.log("✅ Found Loom link:", videoId);
        return {
          id: videoId,
          title:
            loomLink.textContent.trim() ||
            loomLink.getAttribute("aria-label") ||
            `Loom Video ${videoId}`,
          url: loomLink.href,
          element: loomLink,
          platform: "Loom",
          source: "link",
          pageUrl: window.location.href,
          pageTitle: document.title,
        };
      }
    }

    // Priority 5: Look for Loom embeds in script tags
    const scripts = document.querySelectorAll("script");
    for (const script of scripts) {
      const content = script.textContent || script.innerHTML;
      if (content.includes("loom.com")) {
        const match = content.match(
          /loom\.com\/(?:embed|share)\/([a-f0-9]{32})/
        );
        if (match && match[1]) {
          const videoId = match[1];
          console.log("✅ Found Loom in script:", videoId);
          return {
            id: videoId,
            title: `Loom Video ${videoId}`,
            url: `https://www.loom.com/share/${videoId}`,
            platform: "Loom",
            source: "script",
            pageUrl: window.location.href,
            pageTitle: document.title,
          };
        }
      }
    }

    console.log("❌ No Loom embeds found");
    return null;
  }

  /**
   * Finds all Loom embeds on the page
   * @returns {Array} Array of all Loom embeds found
   */
  function findAllLoomEmbeds() {
    const allEmbeds = [];
    const foundIds = new Set();

    // Check all iframe embeds
    document
      .querySelectorAll(
        'iframe[src*="loom.com/embed"], iframe[src*="loom.com/share"]'
      )
      .forEach((iframe) => {
        const videoId = iframe.src.match(
          /(?:embed|share)\/([a-f0-9]{32})/
        )?.[1];
        if (videoId && !foundIds.has(videoId)) {
          allEmbeds.push({
            id: videoId,
            title:
              iframe.title ||
              iframe.getAttribute("aria-label") ||
              `Loom Video ${videoId}`,
            url: `https://www.loom.com/share/${videoId}`,
            embedSrc: iframe.src,
            element: iframe,
            platform: "Loom",
            source: "iframe_embed",
            pageUrl: window.location.href,
            pageTitle: document.title,
          });
          foundIds.add(videoId);
        }
      });

    // Check video elements with data attributes
    document.querySelectorAll("video[data-loom-video-id]").forEach((video) => {
      const videoId = video.getAttribute("data-loom-video-id");
      if (videoId && videoId.length === 32 && !foundIds.has(videoId)) {
        allEmbeds.push({
          id: videoId,
          title:
            video.getAttribute("title") ||
            video.getAttribute("aria-label") ||
            `Loom Video ${videoId}`,
          url: `https://www.loom.com/share/${videoId}`,
          element: video,
          platform: "Loom",
          source: "video_element",
          pageUrl: window.location.href,
          pageTitle: document.title,
          thumbnail: video.poster || null,
        });
        foundIds.add(videoId);
      }
    });

    // Check links
    document.querySelectorAll('a[href*="loom.com/share/"]').forEach((link) => {
      const videoId = link.href.match(/loom\.com\/share\/([a-f0-9]{32})/)?.[1];
      if (videoId && !foundIds.has(videoId)) {
        allEmbeds.push({
          id: videoId,
          title:
            link.textContent.trim() ||
            link.getAttribute("aria-label") ||
            `Loom Video ${videoId}`,
          url: link.href,
          element: link,
          platform: "Loom",
          source: "link",
          pageUrl: window.location.href,
          pageTitle: document.title,
        });
        foundIds.add(videoId);
      }
    });

    console.log(`🔍 Found ${allEmbeds.length} Loom embeds total`);
    return allEmbeds;
  }

  // =================================================================================
  // VIMEO EMBED DETECTION FUNCTIONS
  // =================================================================================

  /**
   * Finds Vimeo embeds on third-party websites
   * @returns {object|null} First Vimeo embed found or null
   */
  function findVimeoEmbed() {
    console.log("🔍 Searching for Vimeo embeds...");

    // Priority 1: Check for window.playerConfig (embedded Vimeo player)
    if (
      window.playerConfig &&
      window.playerConfig.video &&
      window.playerConfig.video.id
    ) {
      const playerConfig = window.playerConfig;
      console.log("✅ Found Vimeo playerConfig:", playerConfig.video.id);

      return {
        id: String(playerConfig.video.id),
        title:
          playerConfig.video.title || `Vimeo Video ${playerConfig.video.id}`,
        url: `https://vimeo.com/${playerConfig.video.id}`,
        duration: playerConfig.video.duration || null,
        thumbnail:
          playerConfig.video.thumbnail_url ||
          playerConfig.request?.thumb_preview?.url ||
          null,
        thumbPreview: playerConfig.request?.thumb_preview
          ? {
              url: playerConfig.request.thumb_preview.url,
              height: playerConfig.request.thumb_preview.height,
              width: playerConfig.request.thumb_preview.width,
              frameHeight: playerConfig.request.thumb_preview.frame_height,
              frameWidth: playerConfig.request.thumb_preview.frame_width,
              columns: playerConfig.request.thumb_preview.columns,
              frames: playerConfig.request.thumb_preview.frames,
            }
          : null,
        owner: playerConfig.video.owner?.name || null,
        platform: "Vimeo",
        source: "player_config",
        pageUrl: window.location.href,
        pageTitle: document.title,
      };
    }

    // Priority 2: Look for Vimeo player iframes
    const iframe = document.querySelector(
      'iframe[src*="player.vimeo.com"], iframe[src*="vimeo.com"]'
    );
    if (iframe && iframe.src) {
      const videoId = iframe.src.match(/video\/(\d+)/)?.[1];
      if (videoId) {
        console.log("✅ Found Vimeo iframe embed:", videoId);

        // Try to extract thumbnail from page meta tags
        let thumbnail = null;
        const ogImage = document.querySelector('meta[property="og:image"]');
        if (ogImage) thumbnail = ogImage.content;

        return {
          id: videoId,
          title: iframe.title || `Vimeo Video ${videoId}`,
          url: `https://vimeo.com/${videoId}`,
          embedSrc: iframe.src,
          element: iframe,
          thumbnail: thumbnail,
          platform: "Vimeo",
          source: "iframe_embed",
          pageUrl: window.location.href,
          pageTitle: document.title,
        };
      }
    }

    // Priority 3: Look for Vimeo video elements or data attributes
    const vimeoElements = document.querySelectorAll(
      '[data-vimeo-id], [data-video-id*="vimeo"], .vimeo-player'
    );
    for (const element of vimeoElements) {
      const vimeoId = element.dataset.vimeoId || element.dataset.videoId;
      if (vimeoId && /^\d+$/.test(vimeoId)) {
        console.log("✅ Found Vimeo data attribute:", vimeoId);
        return {
          id: vimeoId,
          title:
            element.getAttribute("title") ||
            element.getAttribute("aria-label") ||
            `Vimeo Video ${vimeoId}`,
          url: `https://vimeo.com/${vimeoId}`,
          element: element,
          platform: "Vimeo",
          source: "data_attribute",
          pageUrl: window.location.href,
          pageTitle: document.title,
        };
      }
    }

    console.log("❌ No Vimeo embeds found");
    return null;
  }

  /**
   * Extract video info from Vimeo pages (for direct vimeo.com visits)
   * @returns {object|null} Vimeo video info or null
   */
  function extractVimeoPageInfo() {
    const url = window.location.href;

    // Only run on actual Vimeo pages
    if (!url.includes("vimeo.com")) {
      return null;
    }

    console.log("🔍 Extracting Vimeo page info...");

    let videoInfo = {
      id: null,
      title: null,
      url: url,
      platform: "Vimeo",
      source: "vimeo_page",
      pageUrl: window.location.href,
      pageTitle: document.title,
    };

    // Priority 1: Use window.playerConfig if available
    if (window.playerConfig && window.playerConfig.video) {
      const playerConfig = window.playerConfig;
      videoInfo.id = String(playerConfig.video.id);
      videoInfo.title = playerConfig.video.title || "Vimeo Video";
      videoInfo.duration = playerConfig.video.duration;
      videoInfo.thumbnail =
        playerConfig.video.thumbnail_url ||
        playerConfig.request?.thumb_preview?.url;
      videoInfo.owner = playerConfig.video.owner?.name;
      videoInfo.source = "player_config";
      console.log("✅ Extracted from playerConfig:", videoInfo.id);
      return videoInfo;
    }

    // Priority 2: Extract from URL
    const videoId = url.match(/(?:video\/)?(\d+)/)?.[1];
    if (!videoId) {
      console.log("❌ No video ID found in URL");
      return null;
    }

    videoInfo.id = videoId;
    videoInfo.title =
      document.title.replace(" on Vimeo", "").trim() ||
      `Vimeo Video ${videoId}`;

    // Try to extract additional info from meta tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) videoInfo.title = ogTitle.content || videoInfo.title;

    const ogDescription = document.querySelector(
      'meta[property="og:description"]'
    );
    if (ogDescription) videoInfo.description = ogDescription.content;

    const ogImage = document.querySelector('meta[property="og:image"]');
    if (ogImage) videoInfo.thumbnail = ogImage.content;

    // Try to extract duration from video element
    const videoElement = document.querySelector("video");
    if (videoElement && videoElement.duration) {
      videoInfo.duration = Math.floor(videoElement.duration);
    }

    console.log("✅ Extracted from page:", videoInfo.id);
    return videoInfo;
  }

  // =================================================================================
  // WISTIA EMBED DETECTION FUNCTIONS
  // =================================================================================

  /**
   * Extract Wistia video ID from various sources
   */
  function findWistiaVideoId() {
    const currentUrl = window.location.href;

    // Method 1: Check if this is a direct Wistia URL
    const wistiaUrlMatch = currentUrl.match(
      /(?:^wistia:|https?:\/\/(?:\w+\.)?wistia\.(?:net|com)\/(?:embed\/)?(?:iframe|medias|playlists|channel)\/)([a-z0-9]{10})/
    );
    if (wistiaUrlMatch) {
      console.log("✅ Found Wistia ID in direct URL:", wistiaUrlMatch[1]);
      return wistiaUrlMatch[1];
    }

    // Method 2: Check URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const mediaIdFromUrl =
      urlParams.get("wmediaid") ||
      urlParams.get("wvideo") ||
      urlParams.get("wvideoid");
    if (mediaIdFromUrl && /^[a-z0-9]{10}$/.test(mediaIdFromUrl)) {
      console.log("✅ Found video ID in URL params:", mediaIdFromUrl);
      return mediaIdFromUrl;
    }

    // Method 3: Look for Wistia async embeds in DOM
    const asyncEmbeds = document.querySelectorAll('[class*="wistia_async_"]');
    for (const embed of asyncEmbeds) {
      const className = embed.className;
      const match = className.match(/wistia_async_([a-z0-9]{10})/);
      if (match) {
        console.log("✅ Found video ID in async embed:", match[1]);
        return match[1];
      }
    }

    // Method 4: Look for data-wistia-id attributes
    const wistiaElements = document.querySelectorAll(
      "[data-wistia-id], [data-wistia-video-id]"
    );
    for (const element of wistiaElements) {
      const id =
        element.getAttribute("data-wistia-id") ||
        element.getAttribute("data-wistia-video-id");
      if (id && /^[a-z0-9]{10}$/.test(id)) {
        console.log("✅ Found video ID in data attribute:", id);
        return id;
      }
    }

    // Method 5: Look in script tags for Wistia.embed calls
    const scripts = document.querySelectorAll("script");
    for (const script of scripts) {
      const content = script.textContent || script.innerHTML;
      const embedMatch = content.match(/Wistia\.embed\(["']([a-z0-9]{10})["']/);
      if (embedMatch) {
        console.log("✅ Found video ID in Wistia.embed call:", embedMatch[1]);
        return embedMatch[1];
      }

      // Also check for other Wistia ID patterns
      const idMatch = content.match(
        /(?:wmediaid|wvideo(?:id)?)['\"=\s]*([a-z0-9]{10})/
      );
      if (idMatch) {
        console.log("✅ Found video ID in script:", idMatch[1]);
        return idMatch[1];
      }
    }

    // Method 6: Check for Wistia iframes
    const iframes = document.querySelectorAll('iframe[src*="wistia"]');
    for (const iframe of iframes) {
      const src = iframe.src;
      const match = src.match(
        /(?:embed\/(?:iframe|medias)\/|wmediaid=)([a-z0-9]{10})/
      );
      if (match) {
        console.log("✅ Found video ID in iframe:", match[1]);
        return match[1];
      }
    }

    // Method 7: Look for Wistia URLs in source elements
    const sourceElements = document.querySelectorAll(
      'source[src*="wistia"], source[src*="fast.wistia"]'
    );
    for (const source of sourceElements) {
      const src = source.src;
      const match = src.match(
        /(?:https?:\/\/)?(?:fast\.)?wistia\.(?:net|com)\/embed\/medias\/([a-z0-9]{10})/
      );
      if (match) {
        console.log("✅ Found video ID in source element:", match[1]);
        return match[1];
      }
    }

    // Method 8: Look for window._wq (Wistia queue)
    if (window._wq && Array.isArray(window._wq)) {
      for (const item of window._wq) {
        if (
          Array.isArray(item) &&
          item.length >= 2 &&
          /^[a-z0-9]{10}$/.test(item[0])
        ) {
          console.log("✅ Found video ID in _wq:", item[0]);
          return item[0];
        }
      }
    }

    // Method 9: Look for Wistia IDs in any element's data attributes or IDs
    const elementsWithWistiaId = document.querySelectorAll(
      '[id*="wistia_"], [class*="wistia_"]'
    );
    for (const element of elementsWithWistiaId) {
      // Check ID attribute
      const id = element.id;
      if (id) {
        const match = id.match(/wistia[^_]*_([a-z0-9]{10})/);
        if (match) {
          console.log("✅ Found video ID in element ID:", match[1]);
          return match[1];
        }
      }

      // Check class attribute
      const className = element.className;
      if (className) {
        const match = className.match(/wistia[^_]*_([a-z0-9]{10})/);
        if (match) {
          console.log("✅ Found video ID in element class:", match[1]);
          return match[1];
        }
      }
    }

    console.log("❌ No Wistia video ID found");
    return null;
  }

  /**
   * Determine what type of Wistia content this is
   */
  function getWistiaContentType(url) {
    if (url.includes("/playlists/")) {
      return "playlist";
    } else if (url.includes("/channel/")) {
      return "channel";
    } else {
      return "video"; // default for individual videos
    }
  }

  /**
   * Extract title from DOM for Wistia
   */
  function extractWistiaTitleFromDOM() {
    // First try to get title from Wistia video element's aria-label (most accurate)
    const wistiaVideo = document.querySelector("video[aria-label]");
    if (wistiaVideo && wistiaVideo.getAttribute("aria-label")) {
      const ariaLabel = wistiaVideo.getAttribute("aria-label").trim();
      if (ariaLabel && !ariaLabel.toLowerCase().includes("play video")) {
        console.log("✅ Found title in video aria-label:", ariaLabel);
        return ariaLabel;
      }
    }

    // Try various selectors for title
    const titleSelectors = [
      'meta[property="og:title"]',
      'meta[name="twitter:title"]',
      "h1",
      "title",
    ];

    for (const selector of titleSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        const title = element.content || element.textContent;
        if (title && title.trim()) {
          return title.trim();
        }
      }
    }

    return null;
  }

  /**
   * Extract thumbnail from DOM for Wistia
   */
  function extractWistiaThumbnailFromDOM() {
    const thumbnailSelectors = [
      'meta[property="og:image"]',
      'meta[name="twitter:image"]',
      'img[alt*="thumbnail"]',
      'img[alt*="video"]',
      ".wistia_embed img",
      "video[poster]",
    ];

    for (const selector of thumbnailSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        const thumbnailUrl = element.content || element.poster || element.src;
        if (thumbnailUrl) {
          return thumbnailUrl;
        }
      }
    }

    return null;
  }

  /**
   * Finds Wistia embeds on third-party websites
   * @returns {object|null} First Wistia embed found or null
   */
  function findWistiaEmbed() {
    console.log("🔍 Searching for Wistia embeds...");

    const videoId = findWistiaVideoId();
    if (!videoId) {
      console.log("❌ No Wistia video found on this page");
      return null;
    }

    const url = window.location.href;
    const contentType = getWistiaContentType(url);

    console.log("✅ Found Wistia ID:", videoId, "Type:", contentType);

    let videoInfo = {
      id: videoId,
      title: null,
      url: url,
      platform: "Wistia",
      contentType: contentType,
      duration: null,
      thumbnail: null,
      description: null,
      owner: null,
      source: "wistia_detection",
      pageUrl: window.location.href,
      pageTitle: document.title,
    };

    // Try to extract additional information from DOM
    videoInfo.title = extractWistiaTitleFromDOM() || `Wistia Video ${videoId}`;
    videoInfo.thumbnail = extractWistiaThumbnailFromDOM();

    // Try to get description from meta tags
    const descriptionElement = document.querySelector(
      'meta[name="description"], meta[property="og:description"]'
    );
    if (descriptionElement && descriptionElement.content) {
      videoInfo.description = descriptionElement.content;
    }

    console.log("📝 Final Wistia video info:", videoInfo);
    return videoInfo;
  }

  /**
   * Extract Wistia page info when directly on Wistia
   */
  function extractWistiaPageInfo() {
    console.log("🔍 Extracting Wistia page info...");
    const url = window.location.href;

    const videoId = findWistiaVideoId();
    if (!videoId) {
      console.log("❌ No Wistia video ID found in URL");
      return null;
    }

    const videoInfo = {
      id: videoId,
      url: url,
      platform: "Wistia",
      contentType: getWistiaContentType(url),
      source: "wistia_page",
      pageUrl: window.location.href,
      pageTitle: document.title,
    };

    // Try to get title from page
    videoInfo.title = extractWistiaTitleFromDOM() || `Wistia Video ${videoId}`;
    videoInfo.thumbnail = extractWistiaThumbnailFromDOM();

    // Try to get description
    const descriptionElement = document.querySelector(
      'meta[name="description"]'
    );
    if (descriptionElement && descriptionElement.content) {
      videoInfo.description = descriptionElement.content;
    }

    console.log("✅ Extracted Wistia page info:", videoInfo.id);
    return videoInfo;
  }

  // =================================================================================
  // YOUTUBE EMBED DETECTION FUNCTIONS
  // =================================================================================

  /**
   * Extract YouTube video ID from URL
   */
  function extractYouTubeId(url) {
    const patterns = [
      // Standard watch URLs
      /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
      // Embed URLs
      /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      // YouTube Shorts
      /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
      // Mobile URLs
      /m\.youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
      // YouTube nocookie
      /youtube-nocookie\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        return match[1];
      }
    }

    return null;
  }

  /**
   * Finds YouTube embeds on third-party websites
   * @returns {object|null} First YouTube embed found or null
   */
  function findYouTubeEmbed() {
    console.log("🔍 Searching for YouTube embeds...");

    // Priority 1: Look for YouTube iframes (most reliable for embeds)
    const iframe = document.querySelector(
      'iframe[src*="youtube.com/embed"], iframe[src*="youtube-nocookie.com/embed"], iframe[src*="youtu.be"]'
    );
    if (iframe && iframe.src) {
      const videoId = extractYouTubeId(iframe.src);
      if (videoId) {
        console.log("✅ Found YouTube iframe embed:", videoId);
        return {
          id: videoId,
          videoId: videoId,
          title:
            iframe.title ||
            iframe.getAttribute("aria-label") ||
            `YouTube Video ${videoId}`,
          url: `https://www.youtube.com/watch?v=${videoId}`,
          iframeSrc: iframe.src,
          element: iframe,
          platform: "YouTube",
          source: "iframe_embed",
          pageUrl: window.location.href,
          pageTitle: document.title,
        };
      }
    }

    // Priority 2: Look for YouTube links
    const youtubeLink = document.querySelector(
      'a[href*="youtube.com/watch"], a[href*="youtu.be/"]'
    );
    if (youtubeLink && youtubeLink.href) {
      const videoId = extractYouTubeId(youtubeLink.href);
      if (videoId) {
        console.log("✅ Found YouTube link:", videoId);
        return {
          id: videoId,
          videoId: videoId,
          title:
            youtubeLink.textContent.trim() ||
            youtubeLink.getAttribute("aria-label") ||
            `YouTube Video ${videoId}`,
          url: youtubeLink.href,
          element: youtubeLink,
          platform: "YouTube",
          source: "link",
          pageUrl: window.location.href,
          pageTitle: document.title,
        };
      }
    }

    // Priority 3: Look for YouTube URLs in script tags
    const scripts = document.querySelectorAll("script");
    for (const script of scripts) {
      const content = script.textContent || script.innerHTML;
      if (content.includes("youtube.com") || content.includes("youtu.be")) {
        const match = content.match(
          /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/
        );
        if (match && match[1]) {
          const videoId = match[1];
          console.log("✅ Found YouTube in script:", videoId);
          return {
            id: videoId,
            videoId: videoId,
            title: `YouTube Video ${videoId}`,
            url: `https://www.youtube.com/watch?v=${videoId}`,
            platform: "YouTube",
            source: "script",
            pageUrl: window.location.href,
            pageTitle: document.title,
          };
        }
      }
    }

    // Priority 4: Check if we're on a YouTube page directly
    if (window.location.href.includes("youtube.com/watch")) {
      const videoId = extractYouTubeId(window.location.href);
      if (videoId) {
        console.log("✅ Found YouTube page:", videoId);
        return {
          id: videoId,
          videoId: videoId,
          title:
            document.title.replace(" - YouTube", "") ||
            `YouTube Video ${videoId}`,
          url: window.location.href,
          platform: "YouTube",
          source: "direct_page",
          pageUrl: window.location.href,
          pageTitle: document.title,
        };
      }
    }

    console.log("❌ No YouTube embeds found");
    return null;
  }

  /**
   * Extract YouTube page info when directly on YouTube
   */
  function extractYouTubePageInfo() {
    console.log("🔍 Extracting YouTube page info...");
    const url = window.location.href;

    const videoId = extractYouTubeId(url);
    if (!videoId) {
      console.log("❌ No YouTube video ID found in URL");
      return null;
    }

    const videoInfo = {
      id: videoId,
      videoId: videoId,
      url: url,
      platform: "YouTube",
      source: "youtube_page",
      pageUrl: window.location.href,
      pageTitle: document.title,
    };

    // Try to get title from page
    const titleElement = document.querySelector(
      "h1.title, .watch-title, [data-title]"
    );
    if (titleElement) {
      videoInfo.title = titleElement.textContent || titleElement.innerText;
    } else {
      videoInfo.title =
        document.title.replace(" - YouTube", "") || `YouTube Video ${videoId}`;
    }

    // Try to get thumbnail
    const thumbnailElement = document.querySelector(
      'meta[property="og:image"]'
    );
    if (thumbnailElement && thumbnailElement.content) {
      videoInfo.thumbnail = thumbnailElement.content;
    } else {
      videoInfo.thumbnail = `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;
    }

    // Try to get description
    const descriptionElement = document.querySelector(
      'meta[name="description"]'
    );
    if (descriptionElement && descriptionElement.content) {
      videoInfo.description = descriptionElement.content;
    }

    console.log("✅ Extracted YouTube page info:", videoInfo.id);
    return videoInfo;
  }

  // =================================================================================
  // SKOOL NATIVE VIDEO DETECTION FUNCTIONS
  // =================================================================================

  /**
   * Extract video information from Skool page props data (Next.js __NEXT_DATA__)
   * @returns {object|null} Video info extracted from props or null
   */
  function extractSkoolPagePropsData() {
    console.log("🔍 Extracting video data from Skool page props...");

    try {
      // Method 1: Check for __NEXT_DATA__ in window object
      if (window.__NEXT_DATA__ && window.__NEXT_DATA__.props) {
        console.log("✅ Found __NEXT_DATA__ in window object");
        const videoInfo = parseSkoolPropsForVideo(window.__NEXT_DATA__.props);
        if (videoInfo) return videoInfo;
      }

      // Method 2: Look for Next.js script tag with props data
      const nextDataScript = document.querySelector("script#__NEXT_DATA__");
      if (nextDataScript && nextDataScript.textContent) {
        console.log("✅ Found __NEXT_DATA__ script tag");
        try {
          const nextData = JSON.parse(nextDataScript.textContent);
          if (nextData.props) {
            const videoInfo = parseSkoolPropsForVideo(nextData.props);
            if (videoInfo) return videoInfo;
          }
        } catch (parseError) {}
      }

      // Method 3: Look for any script tag containing the props pattern
      const scriptTags = document.querySelectorAll("script");
      for (const script of scriptTags) {
        const content = script.textContent || script.innerHTML;
        if (
          content &&
          content.includes("videoStream") &&
          content.includes("videoLink")
        ) {
          console.log("✅ Found script with video data");
          try {
            // Try to extract JSON from the script content
            const jsonMatch = content.match(/\{[\s\S]*"videoStream"[\s\S]*\}/);
            if (jsonMatch) {
              const propsData = JSON.parse(jsonMatch[0]);
              const videoInfo = parseSkoolPropsForVideo({ props: propsData });
              if (videoInfo) return videoInfo;
            }
          } catch (parseError) {}
        }
      }

      console.log("❌ No Skool video props data found");
      return null;
    } catch (error) {
      console.error("❌ Error extracting Skool page props data:", error);
      return null;
    }
  }

  /**
   * Parse Skool props data structure to extract video information
   * @param {object} props - The props object from Next.js data
   * @returns {object|null} Parsed video info or null
   */
  function parseSkoolPropsForVideo(props) {
    console.log("🔍 Parsing props structure for video data...");

    try {
      // Navigate through the props structure to find video data
      const pageProps = props.pageProps;
      if (!pageProps) {
        console.log("❌ No pageProps found");
        return null;
      }

      // Check for selectedModule in course structure
      const selectedModule = pageProps.selectedModule;
      const course = pageProps.course;

      if (selectedModule && course && course.children) {
        console.log("✅ Found course structure with selectedModule");

        // Find the selected module in the course children
        const videoModule = findModuleInCourse(course.children, selectedModule);

        if (videoModule && videoModule.course && videoModule.course.metadata) {
          const metadata = videoModule.course.metadata;

          if (metadata.videoStream || metadata.videoLink) {
            console.log("✅ Found video data in selected module");

            return {
              id: videoModule.course.id,
              title: metadata.title || document.title || "Skool Video",
              videoStream: metadata.videoStream,
              videoLink: metadata.videoLink,
              thumbnail: metadata.videoThumbnail,
              duration: metadata.videoLenMs
                ? Math.round(metadata.videoLenMs / 1000)
                : null,
            };
          }
        }
      }

      // Fallback: Look for any video data in the course structure
      if (course && course.children) {
        console.log("🔍 Searching all modules for video data...");

        const videoModule = findAnyVideoInCourse(course.children);
        if (videoModule && videoModule.course && videoModule.course.metadata) {
          const metadata = videoModule.course.metadata;

          if (metadata.videoStream || metadata.videoLink) {
            console.log("✅ Found video data in course modules");

            return {
              id: videoModule.course.id,
              title: metadata.title || document.title || "Skool Video",
              videoStream: metadata.videoStream,
              videoLink: metadata.videoLink,
              thumbnail: metadata.videoThumbnail,
              duration: metadata.videoLenMs
                ? Math.round(metadata.videoLenMs / 1000)
                : null,
            };
          }
        }
      }

      console.log("❌ No video data found in props structure");
      return null;
    } catch (error) {
      console.error("❌ Error parsing props for video:", error);
      return null;
    }
  }

  /**
   * Find a specific module by ID in course structure
   * @param {array} children - Course children array
   * @param {string} moduleId - Module ID to find
   * @returns {object|null} Found module or null
   */
  function findModuleInCourse(children, moduleId) {
    for (const child of children) {
      if (child.course && child.course.id === moduleId) {
        return child;
      }

      if (child.children) {
        const found = findModuleInCourse(child.children, moduleId);
        if (found) return found;
      }
    }
    return null;
  }

  /**
   * Find any module with video data in course structure
   * @param {array} children - Course children array
   * @returns {object|null} First module with video data or null
   */
  function findAnyVideoInCourse(children) {
    for (const child of children) {
      if (child.course && child.course.metadata) {
        const metadata = child.course.metadata;
        if (metadata.videoStream || metadata.videoLink) {
          return child;
        }
      }

      if (child.children) {
        const found = findAnyVideoInCourse(child.children);
        if (found) return found;
      }
    }
    return null;
  }

  /**
   * Finds Skool native videos (mux-player elements) with authenticated URLs
   * @returns {object|null} First Skool native video found or null
   */
  function findSkoolNativeVideo() {
    console.log(
      "🔍 FINAL FIX: Searching for Skool native videos (all patterns)..."
    );
    console.log("🔍 FINAL FIX: This should show if the Loom fix took effect");
    console.log("🔍 DEBUG: Current URL is:", window.location.href);
    console.log("🔍 DEBUG: Time loaded:", new Date().toISOString());

    // PRIORITY -1: Check for Loom video elements specifically (highest priority)
    console.log("🔍 PRIORITY -1: Checking for Loom video elements...");
    const loomVideoElements = document.querySelectorAll(
      'video[id*="Loom"], video[data-loom-video-id]'
    );

    if (loomVideoElements.length > 0) {
      console.log(`✅ Found ${loomVideoElements.length} Loom video element(s)`);

      const loomElement = loomVideoElements[0];
      const loomVideoId = loomElement.getAttribute("data-loom-video-id");

      if (loomVideoId) {
        // Extract the full video ID from the page or construct the Loom URL
        const pagePropsInfo = extractSkoolPagePropsData();

        // Try to get video info from page props if available
        if (
          pagePropsInfo &&
          pagePropsInfo.videoLink &&
          pagePropsInfo.videoLink.includes("loom.com")
        ) {
          console.log(
            "🎬 Found Loom video with page props data:",
            pagePropsInfo.videoLink
          );
          return {
            id: pagePropsInfo.id,
            playbackId: pagePropsInfo.id,
            title: pagePropsInfo.title,
            url: pagePropsInfo.videoLink, // Use the Loom URL directly
            m3u8Url: pagePropsInfo.videoStream,
            thumbnail: pagePropsInfo.thumbnail,
            videoLink: pagePropsInfo.videoLink,
            element: loomElement,
            platform: "Loom", // Force Loom platform
            source: "loom_video_element",
            pageUrl: window.location.href,
            pageTitle: document.title,
            isSkoolNative: false,
            duration: pagePropsInfo.duration,
          };
        } else {
          // Fallback: construct Loom URL from the data-loom-video-id if it's a full ID
          console.log(
            "🎬 Found Loom video element without page props, using video ID:",
            loomVideoId
          );
          // Note: The data-loom-video-id might be truncated, so we'll try to get the full ID from page props
        }
      }
    }

    // PRIORITY 0: Check for native video elements with blob sources
    console.log(
      "🔍 PRIORITY 0: Checking for native video elements with blob sources..."
    );
    const videoElements = document.querySelectorAll('video[src^="blob:"]');

    if (videoElements.length > 0) {
      console.log(
        `✅ Found ${videoElements.length} native video element(s) with blob source`
      );

      // Try to extract video info from page props data
      const pagePropsInfo = extractSkoolPagePropsData();

      if (pagePropsInfo) {
        console.log("✅ Found video info in page props data");
        console.log(
          "🔍 DEBUG: pagePropsInfo.videoLink =",
          pagePropsInfo.videoLink
        );

        // Check if this is actually a different platform's video embedded in Skool
        let platform = null;
        let isSkoolNative = false;

        if (pagePropsInfo.videoLink) {
          console.log(
            "🔍 DEBUG: Checking videoLink for platform detection:",
            pagePropsInfo.videoLink
          );

          if (pagePropsInfo.videoLink.includes("loom.com")) {
            console.log(
              "🎬 DETECTED LOOM VIDEO EMBEDDED IN SKOOL:",
              pagePropsInfo.videoLink
            );
            console.log("🔍 DEBUG: Returning null - this is Loom, not Skool");
            return null; // This should be handled by Loom detection, not Skool
          } else if (pagePropsInfo.videoLink.includes("vimeo.com")) {
            console.log(
              "🎬 DETECTED VIMEO VIDEO EMBEDDED IN SKOOL:",
              pagePropsInfo.videoLink
            );
            console.log("🔍 DEBUG: Returning null - this is Vimeo, not Skool");
            return null; // This should be handled by Vimeo detection, not Skool
          } else if (
            pagePropsInfo.videoLink.includes("youtube.com") ||
            pagePropsInfo.videoLink.includes("youtu.be")
          ) {
            console.log(
              "🎬 DETECTED YOUTUBE VIDEO EMBEDDED IN SKOOL:",
              pagePropsInfo.videoLink
            );
            console.log(
              "🔍 DEBUG: Returning null - this is YouTube, not Skool"
            );
            return null; // This should be handled by YouTube detection, not Skool
          } else if (pagePropsInfo.videoLink.includes("wistia.com")) {
            console.log(
              "🎬 DETECTED WISTIA VIDEO EMBEDDED IN SKOOL:",
              pagePropsInfo.videoLink
            );
            console.log("🔍 DEBUG: Returning null - this is Wistia, not Skool");
            return null; // This should be handled by Wistia detection, not Skool
          } else if (
            pagePropsInfo.videoLink.includes("skool.com") ||
            pagePropsInfo.videoLink.includes("video.skool.com")
          ) {
            platform = "Skool";
            isSkoolNative = true;
            console.log(
              "🎓 DETECTED GENUINE SKOOL NATIVE VIDEO:",
              pagePropsInfo.videoLink
            );
          } else {
            console.log(
              "🔍 DEBUG: videoLink doesn't match any known platforms, returning null to allow other detection methods"
            );
            console.log("🔍 DEBUG: Returning null - no known platform match");
            return null; // Don't default to Skool - let other detection methods run
          }
        } else {
          console.log(
            "🔍 DEBUG: No videoLink found in pagePropsInfo, checking if this is truly a Skool native video"
          );

          // Only consider it a Skool native video if we have clear evidence:
          // 1. We're on a Skool domain AND
          // 2. We have actual native video URLs (blob: or skool.com video URLs) AND
          // 3. We have a videoStream that looks like an actual streaming URL
          const hasNativeVideoElement =
            videoElements.length > 0 &&
            Array.from(videoElements).some(
              (v) =>
                v.src &&
                (v.src.startsWith("blob:") || v.src.includes("skool.com"))
            );
          const hasValidVideoStream =
            pagePropsInfo.videoStream &&
            (pagePropsInfo.videoStream.includes("skool.com") ||
              pagePropsInfo.videoStream.includes(".m3u8") ||
              pagePropsInfo.videoStream.includes(".mpd"));

          if (
            window.location.hostname.includes("skool.com") &&
            hasNativeVideoElement &&
            hasValidVideoStream
          ) {
            platform = "Skool";
            isSkoolNative = true;
            console.log(
              "🎓 DETECTED SKOOL NATIVE VIDEO with proper native video sources"
            );
          } else {
            console.log(
              "🔍 DEBUG: No clear evidence this is a Skool native video"
            );
            console.log(
              "🔍 DEBUG: hasNativeVideoElement:",
              hasNativeVideoElement
            );
            console.log("🔍 DEBUG: hasValidVideoStream:", hasValidVideoStream);
            console.log(
              "🔍 DEBUG: Returning null - insufficient evidence of Skool native video"
            );
            return null; // Let other detection methods run
          }
        }

        console.log("🔍 DEBUG: Final platform detection result:", {
          platform: platform,
          isSkoolNative: isSkoolNative,
          videoLink: pagePropsInfo.videoLink,
        });

        return {
          id: pagePropsInfo.id,
          playbackId: pagePropsInfo.id,
          title: pagePropsInfo.title,
          url: pagePropsInfo.videoLink || pagePropsInfo.videoStream, // Use videoLink for Loom videos
          m3u8Url: pagePropsInfo.videoStream,
          thumbnail: pagePropsInfo.thumbnail,
          videoLink: pagePropsInfo.videoLink,
          element: videoElements[0],
          platform: platform,
          source: "native_video_props",
          pageUrl: window.location.href,
          pageTitle: document.title,
          isSkoolNative: isSkoolNative,
          duration: pagePropsInfo.duration,
        };
      }

      // Fallback if no props data found - only proceed if we're actually on Skool domain
      console.log(
        "⚠️ No page props data found, checking if this is truly a Skool video"
      );

      // Only treat as Skool video if we're actually on a Skool domain
      if (!window.location.hostname.includes("skool.com")) {
        console.log(
          "🔍 DEBUG: Not on Skool domain, returning null to allow other detection methods"
        );
        return null;
      }

      console.log("✅ On Skool domain, extracting info from DOM as fallback");
      const videoElement = videoElements[0];
      const title = document.title || "Skool Video";

      // Try to find thumbnail in DOM elements
      let thumbnail = null;

      // Method 1: Look for poster attribute on video element
      if (videoElement.poster) {
        thumbnail = videoElement.poster;
        console.log("✅ Found thumbnail from video poster attribute");
      }

      // Method 2: Look for thumbnail images in common Skool patterns
      if (!thumbnail) {
        const thumbnailSelectors = [
          'img[src*="thumbnail"]',
          'img[src*="thumb"]',
          'img[src*=".jpg"]',
          'img[src*=".webp"]',
          'img[src*=".png"]',
          '[style*="background-image"]',
        ];

        for (const selector of thumbnailSelectors) {
          const thumbnailElements = document.querySelectorAll(selector);
          for (const elem of thumbnailElements) {
            const src = elem.src || elem.getAttribute("src");
            const bgImage = elem.style.backgroundImage;

            if (src && (src.includes("thumbnail") || src.includes("thumb"))) {
              thumbnail = src;
              console.log("✅ Found thumbnail from DOM selector:", selector);
              break;
            } else if (bgImage && bgImage.includes("thumbnail")) {
              const urlMatch = bgImage.match(/url\(['"]?([^'"]+)['"]?\)/);
              if (urlMatch && urlMatch[1]) {
                thumbnail = urlMatch[1];
                console.log("✅ Found thumbnail from background-image");
                break;
              }
            }
          }
          if (thumbnail) break;
        }
      }

      // Method 3: Try to get any available props data even if video matching failed
      if (!thumbnail) {
        try {
          console.log("🔍 Trying fallback props extraction for thumbnail...");
          if (window.__NEXT_DATA__ && window.__NEXT_DATA__.props) {
            const anyPropsData = parseSkoolPropsForVideo(
              window.__NEXT_DATA__.props
            );
            if (anyPropsData && anyPropsData.thumbnail) {
              thumbnail = anyPropsData.thumbnail;
              console.log(
                "✅ Found thumbnail from fallback window props extraction"
              );
            }
          }
        } catch (error) {}
      }

      console.log(
        `🔍 Final thumbnail result: ${thumbnail ? "Found" : "Not found"}`
      );

      return {
        id: "skool-native-video",
        playbackId: "skool-native-video",
        title: title,
        url: videoElement.src,
        m3u8Url: null,
        thumbnail: thumbnail,
        element: videoElement,
        platform: "Skool",
        source: "native_video_blob",
        pageUrl: window.location.href,
        pageTitle: document.title,
        isSkoolNative: true,
      };
    }

    // PRIORITY 1: Check for video data in page props (Next.js data)
    console.log("🔍 PRIORITY 1: Checking for video data in page props...");
    const pagePropsInfo = extractSkoolPagePropsData();

    if (pagePropsInfo) {
      console.error(
        "🚨 TAKING PRIORITY 1 PATH - PLATFORM DETECTION HAPPENING HERE"
      );
      console.log("✅ Found video info in page props data (PRIORITY 1)");
      console.log("🔍 DEBUG PRIORITY 1: FULL pagePropsInfo =", pagePropsInfo);
      console.log(
        "🔍 DEBUG PRIORITY 1: pagePropsInfo.videoLink =",
        pagePropsInfo.videoLink
      );

      // Check if this is actually a different platform's video embedded in Skool
      let platform = null;
      let isSkoolNative = false;

      console.error(
        "🚨 FORCING PLATFORM CHECK - videoLink exists:",
        !!pagePropsInfo.videoLink
      );
      if (pagePropsInfo.videoLink) {
        console.log(
          "🔍 DEBUG PRIORITY 1: Checking videoLink for platform detection:",
          pagePropsInfo.videoLink
        );
        console.error(
          "🚨 videoLink contains loom.com:",
          pagePropsInfo.videoLink.includes("loom.com")
        );

        if (pagePropsInfo.videoLink.includes("loom.com")) {
          console.error("🚨🚨🚨 DETECTED LOOM VIDEO - NOT SKOOL NATIVE!");
          console.log(
            "🎬 PRIORITY 1: DETECTED LOOM VIDEO EMBEDDED IN SKOOL:",
            pagePropsInfo.videoLink
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: Returning null - this is Loom, not Skool"
          );
          return null; // This should be handled by Loom detection, not Skool
        } else if (pagePropsInfo.videoLink.includes("vimeo.com")) {
          console.log(
            "🎬 PRIORITY 1: DETECTED VIMEO VIDEO EMBEDDED IN SKOOL:",
            pagePropsInfo.videoLink
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: Returning null - this is Vimeo, not Skool"
          );
          return null; // This should be handled by Vimeo detection, not Skool
        } else if (
          pagePropsInfo.videoLink.includes("youtube.com") ||
          pagePropsInfo.videoLink.includes("youtu.be")
        ) {
          console.log(
            "🎬 PRIORITY 1: DETECTED YOUTUBE VIDEO EMBEDDED IN SKOOL:",
            pagePropsInfo.videoLink
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: Returning null - this is YouTube, not Skool"
          );
          return null; // This should be handled by YouTube detection, not Skool
        } else if (pagePropsInfo.videoLink.includes("wistia.com")) {
          console.log(
            "🎬 PRIORITY 1: DETECTED WISTIA VIDEO EMBEDDED IN SKOOL:",
            pagePropsInfo.videoLink
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: Returning null - this is Wistia, not Skool"
          );
          return null; // This should be handled by Wistia detection, not Skool
        } else if (
          pagePropsInfo.videoLink.includes("skool.com") ||
          pagePropsInfo.videoLink.includes("video.skool.com")
        ) {
          platform = "Skool";
          isSkoolNative = true;
          console.log(
            "🎓 PRIORITY 1: DETECTED GENUINE SKOOL NATIVE VIDEO:",
            pagePropsInfo.videoLink
          );
        } else {
          console.log(
            "🔍 DEBUG PRIORITY 1: videoLink doesn't match any known platforms, returning null to allow other detection methods"
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: Returning null - no known platform match"
          );
          return null; // Don't default to Skool - let other detection methods run
        }
      } else {
        console.log(
          "🔍 DEBUG PRIORITY 1: No videoLink found in pagePropsInfo, checking if this is truly a Skool native video"
        );

        // Only consider it a Skool native video if we have clear evidence:
        // 1. We're on a Skool domain AND
        // 2. We have actual native video URLs (blob: or skool.com video URLs) AND
        // 3. We have a videoStream that looks like an actual streaming URL
        const videoElements = document.querySelectorAll('video[src^="blob:"]');
        const hasNativeVideoElement =
          videoElements.length > 0 &&
          Array.from(videoElements).some(
            (v) =>
              v.src &&
              (v.src.startsWith("blob:") || v.src.includes("skool.com"))
          );
        const hasValidVideoStream =
          pagePropsInfo.videoStream &&
          (pagePropsInfo.videoStream.includes("skool.com") ||
            pagePropsInfo.videoStream.includes(".m3u8") ||
            pagePropsInfo.videoStream.includes(".mpd"));

        if (
          window.location.hostname.includes("skool.com") &&
          hasNativeVideoElement &&
          hasValidVideoStream
        ) {
          platform = "Skool";
          isSkoolNative = true;
          console.log(
            "🎓 PRIORITY 1: DETECTED SKOOL NATIVE VIDEO with proper native video sources"
          );
        } else {
          console.log(
            "🔍 DEBUG PRIORITY 1: No clear evidence this is a Skool native video"
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: hasNativeVideoElement:",
            hasNativeVideoElement
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: hasValidVideoStream:",
            hasValidVideoStream
          );
          console.log(
            "🔍 DEBUG PRIORITY 1: Returning null - insufficient evidence of Skool native video"
          );
          return null; // Let other detection methods run
        }
      }

      console.log("🔍 DEBUG PRIORITY 1: Final platform detection result:", {
        platform: platform,
        isSkoolNative: isSkoolNative,
        videoLink: pagePropsInfo.videoLink,
      });

      // Force correct platform detection based on URL - FINAL SAFETY CHECK
      const finalUrl = pagePropsInfo.videoLink || pagePropsInfo.videoStream;
      let finalPlatform = platform;
      let finalIsSkoolNative = isSkoolNative;

      if (finalUrl && finalUrl.includes("loom.com")) {
        finalPlatform = "Loom";
        finalIsSkoolNative = false;
        console.error("🚨 FINAL SAFETY CHECK: FORCING PLATFORM TO LOOM");
      } else if (finalUrl && finalUrl.includes("vimeo.com")) {
        finalPlatform = "Vimeo";
        finalIsSkoolNative = false;
        console.error("🚨 FINAL SAFETY CHECK: FORCING PLATFORM TO VIMEO");
      } else if (
        finalUrl &&
        (finalUrl.includes("youtube.com") || finalUrl.includes("youtu.be"))
      ) {
        finalPlatform = "YouTube";
        finalIsSkoolNative = false;
        console.error("🚨 FINAL SAFETY CHECK: FORCING PLATFORM TO YOUTUBE");
      } else if (finalUrl && finalUrl.includes("wistia.com")) {
        finalPlatform = "Wistia";
        finalIsSkoolNative = false;
        console.error("🚨 FINAL SAFETY CHECK: FORCING PLATFORM TO WISTIA");
      }

      console.log("🔍 FINAL PLATFORM DETECTION RESULT:", {
        originalPlatform: platform,
        finalPlatform: finalPlatform,
        url: finalUrl,
        wasChanged: finalPlatform !== platform,
      });

      return {
        id: pagePropsInfo.id,
        playbackId: pagePropsInfo.id,
        title: pagePropsInfo.title,
        url: finalUrl,
        m3u8Url: pagePropsInfo.videoStream,
        thumbnail: pagePropsInfo.thumbnail,
        videoLink: pagePropsInfo.videoLink,
        element: null,
        platform: finalPlatform, // Use the final platform
        source: "page_props",
        pageUrl: window.location.href,
        pageTitle: document.title,
        isSkoolNative: finalIsSkoolNative, // Use the final isSkoolNative
        duration: pagePropsInfo.duration,
      };
    }

    // PRIORITY 2: Look for mux-player elements in the DOM (existing logic)
    console.log(
      "🔍 PRIORITY 2: Searching for Skool native videos (mux-player)..."
    );
    const muxPlayerElements = document.querySelectorAll("mux-player");

    if (muxPlayerElements.length === 0) {
      console.log("❌ No mux-player elements found");
      return null;
    }

    for (const muxPlayer of muxPlayerElements) {
      try {
        // Extract playback ID from playback-id attribute (this is the key!)
        const playbackId = muxPlayer.getAttribute("playback-id");
        if (!playbackId) {
          continue;
        }

        console.log(
          "✅ Found Skool native video with playback ID:",
          playbackId
        );

        // PRIORITY 1: Look for authenticated URLs directly in active DOM elements FIRST
        let m3u8Url = null;
        let thumbnail = null;

        console.log(
          "🔍 PRIORITY 1: Scanning active DOM for authenticated URLs..."
        );

        // Check mux-video elements inside the current muxPlayer's Shadow DOM
        let muxVideoElements = [];

        // Try to access Shadow DOM first
        if (muxPlayer.shadowRoot) {
          muxVideoElements = muxPlayer.shadowRoot.querySelectorAll("mux-video");
          console.log(
            `🔍 Found ${muxVideoElements.length} mux-video elements in Shadow DOM`
          );
        } else {
          // Fallback to regular DOM (in case shadow DOM is not used)
          muxVideoElements = muxPlayer.querySelectorAll("mux-video");
          console.log(
            `🔍 Found ${muxVideoElements.length} mux-video elements in regular DOM (no shadow root)`
          );
        }

        for (const muxVideo of muxVideoElements) {
          const videoSrc = muxVideo.getAttribute("src") || muxVideo.src;
          const castSrc = muxVideo.getAttribute("cast-src");

          console.log("🔍 Checking mux-video element from Shadow DOM:");
          console.log("🔍 All mux-video attributes:");
          Array.from(muxVideo.attributes).forEach((attr) => {
            const value =
              attr.value.length > 150
                ? attr.value.substring(0, 150) + "..."
                : attr.value;
            console.log(`   ${attr.name}: ${value}`);
          });

          // Check both src and cast-src attributes for authenticated URLs
          if (
            videoSrc &&
            videoSrc.includes("token=") &&
            videoSrc.includes(playbackId)
          ) {
            m3u8Url = videoSrc;
            console.log(
              "✅ FOUND AUTHENTICATED M3U8 URL in Shadow DOM mux-video src:",
              m3u8Url.substring(0, 150) + "..."
            );
            break;
          } else if (
            castSrc &&
            castSrc.includes("token=") &&
            castSrc.includes(playbackId)
          ) {
            m3u8Url = castSrc;
            console.log(
              "✅ FOUND AUTHENTICATED M3U8 URL in Shadow DOM mux-video cast-src:",
              m3u8Url.substring(0, 150) + "..."
            );
            break;
          }

          console.log(
            `🔍 Current element check - src has token: ${!!(
              videoSrc && videoSrc.includes("token=")
            )}, cast-src has token: ${!!(
              castSrc && castSrc.includes("token=")
            )}`
          );
        }

        // Check all mux-player elements on page and search their Shadow DOM if not found in current player
        if (!m3u8Url) {
          const allMuxPlayers = document.querySelectorAll("mux-player");
          console.log(
            `🔍 Scanning all ${allMuxPlayers.length} mux-player elements on page for Shadow DOM content`
          );

          for (const otherPlayer of allMuxPlayers) {
            if (otherPlayer === muxPlayer) continue; // Skip the one we already checked

            let otherVideoElements = [];
            if (otherPlayer.shadowRoot) {
              otherVideoElements =
                otherPlayer.shadowRoot.querySelectorAll("mux-video");
            } else {
              otherVideoElements = otherPlayer.querySelectorAll("mux-video");
            }

            for (const muxVideo of otherVideoElements) {
              const videoSrc = muxVideo.getAttribute("src") || muxVideo.src;
              const castSrc = muxVideo.getAttribute("cast-src");

              if (
                videoSrc &&
                videoSrc.includes("token=") &&
                videoSrc.includes(playbackId)
              ) {
                m3u8Url = videoSrc;
                console.log(
                  "✅ FOUND AUTHENTICATED M3U8 URL in other mux-player Shadow DOM src:",
                  m3u8Url.substring(0, 150) + "..."
                );
                break;
              } else if (
                castSrc &&
                castSrc.includes("token=") &&
                castSrc.includes(playbackId)
              ) {
                m3u8Url = castSrc;
                console.log(
                  "✅ FOUND AUTHENTICATED M3U8 URL in other mux-player Shadow DOM cast-src:",
                  m3u8Url.substring(0, 150) + "..."
                );
                break;
              }
            }

            if (m3u8Url) break;
          }
        }

        // PRIORITY 2: Look for thumbnail URLs - Check media-poster-image first (most reliable for UI)
        console.log(
          "🔍 PRIORITY 2: Searching for thumbnail in DOM media-poster-image elements..."
        );

        // First check in the current muxPlayer's shadow DOM for media-poster-image
        let posterElements = [];
        if (muxPlayer.shadowRoot) {
          posterElements = muxPlayer.shadowRoot.querySelectorAll(
            "media-poster-image[src]"
          );
          console.log(
            `🔍 Found ${posterElements.length} media-poster-image elements in Shadow DOM`
          );
        } else {
          posterElements = muxPlayer.querySelectorAll(
            "media-poster-image[src]"
          );
          console.log(
            `🔍 Found ${posterElements.length} media-poster-image elements in regular DOM (no shadow root)`
          );
        }

        for (const posterElement of posterElements) {
          const posterSrc =
            posterElement.getAttribute("src") || posterElement.src;
          console.log(
            `🔍 Checking media-poster-image src: ${
              posterSrc ? posterSrc.substring(0, 100) + "..." : "null"
            }`
          );

          if (posterSrc && posterSrc.includes("thumbnail.webp")) {
            thumbnail = posterSrc;
            console.log(
              "✅ FOUND THUMBNAIL URL in Shadow DOM media-poster-image:",
              thumbnail.substring(0, 150) + "..."
            );
            break;
          }
        }

        // If not found in current player, check all mux-players on the page
        if (!thumbnail) {
          const allMuxPlayers = document.querySelectorAll("mux-player");
          console.log(
            `🔍 Searching all ${allMuxPlayers.length} mux-player elements for media-poster-image`
          );

          for (const otherPlayer of allMuxPlayers) {
            let otherPosterElements = [];
            if (otherPlayer.shadowRoot) {
              otherPosterElements = otherPlayer.shadowRoot.querySelectorAll(
                "media-poster-image[src]"
              );
            } else {
              otherPosterElements = otherPlayer.querySelectorAll(
                "media-poster-image[src]"
              );
            }

            for (const posterElement of otherPosterElements) {
              const posterSrc =
                posterElement.getAttribute("src") || posterElement.src;

              if (
                posterSrc &&
                posterSrc.includes("thumbnail.webp") &&
                posterSrc.includes(playbackId)
              ) {
                thumbnail = posterSrc;
                console.log(
                  "✅ FOUND THUMBNAIL URL in other mux-player media-poster-image:",
                  thumbnail.substring(0, 150) + "..."
                );
                break;
              }
            }

            if (thumbnail) break;
          }
        }

        // Fallback: Look for thumbnail URLs in track elements if media-poster-image not found
        if (!thumbnail) {
          console.log(
            "🔍 Fallback: Searching for thumbnail in Shadow DOM track elements..."
          );
          let trackElements = [];

          if (muxPlayer.shadowRoot) {
            trackElements = muxPlayer.shadowRoot.querySelectorAll(
              'track[src*="thumbnail"], track[src*="storyboard"]'
            );
          } else {
            trackElements = muxPlayer.querySelectorAll(
              'track[src*="thumbnail"], track[src*="storyboard"]'
            );
          }

          for (const track of trackElements) {
            const trackSrc = track.getAttribute("src");
            if (trackSrc && trackSrc.includes(playbackId)) {
              thumbnail = trackSrc;
              console.log(
                "✅ FOUND THUMBNAIL URL in Shadow DOM track element:",
                thumbnail.substring(0, 150) + "..."
              );
              break;
            }
          }
        }

        // Fallback: Search for generic poster images
        if (!thumbnail) {
          console.log(
            "🔍 Fallback: Searching for thumbnail in Shadow DOM generic poster elements..."
          );
          let genericPosterElements = [];

          if (muxPlayer.shadowRoot) {
            genericPosterElements = muxPlayer.shadowRoot.querySelectorAll(
              'img[src*="thumbnail"]'
            );
          } else {
            genericPosterElements = muxPlayer.querySelectorAll(
              'img[src*="thumbnail"]'
            );
          }

          for (const posterElement of genericPosterElements) {
            const posterSrc =
              posterElement.getAttribute("src") || posterElement.src;
            if (
              posterSrc &&
              (posterSrc.includes("thumbnail") || posterSrc.includes("token="))
            ) {
              thumbnail = posterSrc;
              console.log(
                "✅ FOUND THUMBNAIL URL in Shadow DOM generic poster element:",
                thumbnail.substring(0, 150) + "..."
              );
              break;
            }
          }
        }

        console.log(
          `🔍 DOM scanning complete - M3U8: ${!!m3u8Url}, Thumbnail: ${!!thumbnail}`
        );

        // ONLY IF DOM SCAN COMPLETELY FAILED, search in scripts as backup
        if (!m3u8Url) {
          console.log(
            "🔍 DOM scan failed completely, searching scripts as last resort..."
          );
          const scripts = document.querySelectorAll("script");

          for (const script of scripts) {
            const content = script.textContent || script.innerHTML;
            if (content && content.includes(playbackId)) {
              const m3u8Patterns = [
                new RegExp(
                  `https://[^"'\\s]*${playbackId}[^"'\\s]*\\.m3u8\\?[^"'\\s]*token=[^"'\\s]*`,
                  "g"
                ),
              ];

              for (const pattern of m3u8Patterns) {
                const matches = content.match(pattern);
                if (matches && matches.length > 0) {
                  m3u8Url = matches[0];
                  console.log(
                    "✅ Found authenticated M3U8 URL in script as backup:",
                    m3u8Url
                  );
                  break;
                }
              }
              if (m3u8Url) break;
            }
          }
        }

        // ERROR: If we get here without finding authenticated URLs in DOM, something is wrong
        if (!m3u8Url) {
          console.error(
            "❌ FAILED TO FIND AUTHENTICATED M3U8 URL IN ACTIVE DOM!"
          );
          console.error(
            "❌ This means the mux-video elements don't have the expected authenticated URLs"
          );
          console.error("❌ Context:", window.location.href);
          console.error("❌ PlaybackId:", playbackId);
          console.error(
            "❌ Available mux-video elements:",
            document.querySelectorAll("mux-video").length
          );

          // Only construct fallback as absolute last resort with clear error
          const customDomain =
            muxPlayer.getAttribute("custom-domain") || "stream.video.skool.com";
          m3u8Url = `https://${customDomain}/${playbackId}.m3u8`;
          console.error(
            "❌ Using UNAUTHENTICATED fallback URL - download will likely FAIL:",
            m3u8Url
          );
        } else {
          console.log(
            "✅ SUCCESS: Using authenticated M3U8 URL found in active DOM:",
            m3u8Url.substring(0, 100) + "..."
          );
        }

        if (!thumbnail) {
          const customDomain =
            muxPlayer.getAttribute("custom-domain") || "image.video.skool.com";
          thumbnail = `https://${customDomain}/${playbackId}/thumbnail.webp`;
        }

        console.log("🎓 Final URLs - M3U8:", m3u8Url.substring(0, 100) + "...");
        console.log(
          "🎓 Final URLs - Thumbnail:",
          thumbnail ? thumbnail.substring(0, 100) + "..." : "not found"
        );

        // Extract title from various sources
        const title =
          muxPlayer.getAttribute("title") ||
          muxPlayer.getAttribute("aria-label") ||
          document.title ||
          `Skool Video ${playbackId}`;

        console.log("🔍 Skool video detection result:", {
          playbackId,
          title: title.substring(0, 80) + "...",
          thumbnail: thumbnail
            ? thumbnail.substring(0, 80) + "..."
            : "not found",
          m3u8Url: m3u8Url.substring(0, 80) + "...",
        });

        return {
          id: playbackId,
          playbackId: playbackId,
          title: title,
          url: m3u8Url, // This is the constructed M3U8 URL
          m3u8Url: m3u8Url,
          thumbnail: thumbnail,
          element: muxPlayer,
          platform: "Skool",
          source: "native_mux_player",
          pageUrl: window.location.href,
          pageTitle: document.title,
          isSkoolNative: true,
        };
      } catch (error) {
        console.error("❌ Error processing mux-player element:", error);
        continue;
      }
    }

    console.log("❌ No valid Skool native videos found");
    return null;
  }

  /**
   * Finds all Skool native videos on the page with authenticated URLs
   * @returns {Array} Array of all Skool native videos found
   */
  function findAllSkoolNativeVideos() {
    const allVideos = [];
    const foundIds = new Set();

    const muxPlayerElements = document.querySelectorAll("mux-player");

    muxPlayerElements.forEach((muxPlayer) => {
      try {
        const playbackId = muxPlayer.getAttribute("playback-id");
        if (!playbackId) {
          return;
        }

        if (!foundIds.has(playbackId)) {
          // Search for authenticated URLs in page scripts (same logic as single video)
          let m3u8Url = null;
          let thumbnail = null;

          const scripts = document.querySelectorAll("script");
          for (const script of scripts) {
            const content = script.textContent || script.innerHTML;
            if (content && content.includes(playbackId)) {
              // Look for authenticated M3U8 URLs with tokens
              const m3u8Patterns = [
                new RegExp(
                  `https://[^"'\\s]*${playbackId}[^"'\\s]*\\.m3u8\\?[^"'\\s]*token=[^"'\\s]*`,
                  "g"
                ),
                new RegExp(
                  `https://[^"'\\s]*stream[^"'\\s]*${playbackId}[^"'\\s]*\\?[^"'\\s]*token=[^"'\\s]*`,
                  "g"
                ),
                new RegExp(
                  `https://[^"'\\s]*video[^"'\\s]*${playbackId}[^"'\\s]*\\?[^"'\\s]*`,
                  "g"
                ),
              ];

              for (const pattern of m3u8Patterns) {
                const matches = content.match(pattern);
                if (matches && matches.length > 0) {
                  m3u8Url = matches[0];
                  break;
                }
              }

              // Look for authenticated thumbnail URLs with tokens
              const thumbnailPatterns = [
                new RegExp(
                  `https://[^"'\\s]*image[^"'\\s]*${playbackId}[^"'\\s]*thumbnail[^"'\\s]*\\?[^"'\\s]*token=[^"'\\s]*`,
                  "g"
                ),
                new RegExp(
                  `https://[^"'\\s]*${playbackId}[^"'\\s]*thumbnail[^"'\\s]*\\?[^"'\\s]*token=[^"'\\s]*`,
                  "g"
                ),
                new RegExp(
                  `https://[^"'\\s]*thumbnail[^"'\\s]*${playbackId}[^"'\\s]*\\?[^"'\\s]*`,
                  "g"
                ),
              ];

              for (const pattern of thumbnailPatterns) {
                const matches = content.match(pattern);
                if (matches && matches.length > 0) {
                  thumbnail = matches[0];
                  break;
                }
              }

              if (m3u8Url && thumbnail) {
                break;
              }
            }
          }

          // Fallback: look in DOM elements
          if (!m3u8Url) {
            const muxVideoElements = muxPlayer.querySelectorAll("mux-video");
            for (const muxVideo of muxVideoElements) {
              const videoSrc = muxVideo.getAttribute("src") || muxVideo.src;
              if (videoSrc && videoSrc.includes("token=")) {
                m3u8Url = videoSrc;
                break;
              }
            }
          }

          if (!thumbnail) {
            const posterElements = muxPlayer.querySelectorAll(
              'media-poster-image, img[src*="thumbnail"]'
            );
            for (const posterElement of posterElements) {
              const posterSrc =
                posterElement.getAttribute("src") || posterElement.src;
              if (
                posterSrc &&
                (posterSrc.includes("thumbnail") ||
                  posterSrc.includes("token="))
              ) {
                thumbnail = posterSrc;
                break;
              }
            }
          }

          // Final fallbacks if no authenticated URLs found
          if (!m3u8Url) {
            const customDomain =
              muxPlayer.getAttribute("custom-domain") ||
              "stream.video.skool.com";
            m3u8Url = `https://${customDomain}/${playbackId}.m3u8`;
          }

          if (!thumbnail) {
            const customDomain =
              muxPlayer.getAttribute("custom-domain") ||
              "image.video.skool.com";
            thumbnail = `https://${customDomain}/${playbackId}/thumbnail.webp`;
          }

          const title =
            muxPlayer.getAttribute("title") ||
            muxPlayer.getAttribute("aria-label") ||
            document.title ||
            `Skool Video ${playbackId}`;

          allVideos.push({
            id: playbackId,
            playbackId: playbackId,
            title: title,
            url: m3u8Url,
            m3u8Url: m3u8Url,
            thumbnail: thumbnail,
            element: muxPlayer,
            platform: "Skool",
            source: "native_mux_player",
            pageUrl: window.location.href,
            pageTitle: document.title,
            isSkoolNative: true,
          });
          foundIds.add(playbackId);
        }
      } catch (error) {
        console.error("❌ Error processing mux-player element:", error);
      }
    });

    console.log(`🔍 Found ${allVideos.length} Skool native videos total`);
    return allVideos;
  }

  // =================================================================================
  // UNIFIED VIDEO DETECTION
  // =================================================================================

  /**
   * Finds the first available video (Loom, Vimeo, YouTube, Wistia, or Skool) on the page
   * @returns {object|null} First video found or null
   */
  async function findFirstAvailableVideo() {
    // Priority 0: Check for Skool native videos first (highest priority)
    const skoolNativeVideo = findSkoolNativeVideo();
    if (skoolNativeVideo) {
      console.log(
        "✅ Found video, returning with detected platform:",
        skoolNativeVideo.platform
      );
      return skoolNativeVideo; // Don't override the platform - use the detected one
    }

    // For third-party sites, prioritize embeds
    if (
      !window.location.href.includes("loom.com") &&
      !window.location.href.includes("vimeo.com") &&
      !window.location.href.includes("youtube.com") &&
      !window.location.href.includes("wistia.com") &&
      !window.location.href.includes("wistia.net") &&
      !window.location.href.includes("skool.com")
    ) {
      // Third-party site - look for embeds only
      const loomEmbed = findLoomEmbed();
      if (loomEmbed) {
        console.log("✅ Found Loom embed, returning with platform info");
        return { ...loomEmbed, platform: "Loom" };
      }

      const vimeoEmbed = findVimeoEmbed();
      if (vimeoEmbed) {
        console.log("✅ Found Vimeo embed, extracting detailed info...");
        // Try to get detailed info for Vimeo embeds
        const detailedVimeoInfo = await extractVimeoEmbedInfo(vimeoEmbed);
        if (detailedVimeoInfo) {
          console.log(
            "✅ Got detailed Vimeo embed info:",
            detailedVimeoInfo.title
          );
          return detailedVimeoInfo;
        }
        return { ...vimeoEmbed, platform: "Vimeo" };
      }

      const youtubeEmbed = findYouTubeEmbed();
      if (youtubeEmbed) {
        console.log("✅ Found YouTube embed, returning with platform info");
        return { ...youtubeEmbed, platform: "YouTube" };
      }

      const wistiaEmbed = findWistiaEmbed();
      if (wistiaEmbed) {
        console.log("✅ Found Wistia embed, returning with platform info");
        return { ...wistiaEmbed, platform: "Wistia" };
      }

      return null;
    }

    // Direct platform pages
    if (window.location.href.includes("loom.com")) {
      // On Loom pages, still check for embeds first, then direct content
      const loomEmbed = findLoomEmbed();
      if (loomEmbed) return { ...loomEmbed, platform: "Loom" };
    }

    if (window.location.href.includes("vimeo.com")) {
      // On Vimeo pages, extract page info
      const vimeoInfo = extractVimeoPageInfo();
      if (vimeoInfo) return { ...vimeoInfo, platform: "Vimeo" };
    }

    if (window.location.href.includes("youtube.com")) {
      // On YouTube pages, extract page info
      const youtubeInfo = extractYouTubePageInfo();
      if (youtubeInfo) return { ...youtubeInfo, platform: "YouTube" };
    }

    if (
      window.location.href.includes("wistia.com") ||
      window.location.href.includes("wistia.net")
    ) {
      // On Wistia pages, extract page info
      const wistiaInfo = extractWistiaPageInfo();
      if (wistiaInfo) return { ...wistiaInfo, platform: "Wistia" };
    }

    if (window.location.href.includes("skool.com")) {
      // On Skool pages, check for native videos
      const skoolInfo = findSkoolNativeVideo();
      if (skoolInfo) {
        console.log(
          "✅ Found video on Skool page, using detected platform:",
          skoolInfo.platform
        );
        return skoolInfo; // Don't override the platform - use the detected one
      }
    }

    return null;
  }

  // =================================================================================
  // SKOOL VIDEO DIRECT DOWNLOAD (AUTHENTICATED CONTENT SCRIPT APPROACH) - REFACTORED
  // =================================================================================

  // Global state for tracking active downloads
  const activeSkoolDownloads = new Map();
  let globalDownloadCancelled = false;

  class ConcurrencyLimiter {
    constructor(maxConcurrent = 20) {
      this.maxConcurrent = maxConcurrent;
      this.running = 0;
      this.queue = [];
    }

    async add(fn) {
      return new Promise((resolve, reject) => {
        this.queue.push({
          fn,
          resolve,
          reject,
        });
        this.process();
      });
    }

    async process() {
      if (this.running >= this.maxConcurrent || this.queue.length === 0) {
        return;
      }

      this.running++;
      const { fn, resolve, reject } = this.queue.shift();

      try {
        const result = await fn();
        resolve(result);
      } catch (error) {
        reject(error);
      } finally {
        this.running--;
        this.process();
      }
    }
  }

  async function getM3U8Segments(m3u8Url, abortController) {
    console.log(`🎓 Fetching M3U8 manifest...`);
    const manifestResponse = await fetch(m3u8Url, {
      signal: abortController.signal,
    });
    if (!manifestResponse.ok)
      throw new Error(
        `Failed to fetch M3U8 manifest: ${manifestResponse.status}`
      );
    const manifestText = await manifestResponse.text();

    const parseResult = parseM3U8Manifest(manifestText, m3u8Url);
    let segments;
    let totalDuration;
    let audioSegments;

    if (parseResult.isMasterPlaylist) {
      console.log(
        `🎓 Master playlist detected, fetching rendition manifest...`
      );
      const renditionResponse = await fetch(parseResult.renditionUrl, {
        signal: abortController.signal,
      });
      if (!renditionResponse.ok)
        throw new Error(
          `Failed to fetch rendition manifest: ${renditionResponse.status}`
        );
      const renditionText = await renditionResponse.text();
      const renditionResult = parseM3U8Manifest(
        renditionText,
        parseResult.renditionUrl
      );
      segments = renditionResult.segments;
      totalDuration = renditionResult.totalDuration;

      // Also fetch audio segments if audio track exists
      if (parseResult.audioTrack) {
        console.log(`🎓 🎵 Fetching audio track manifest...`);
        const audioResponse = await fetch(parseResult.audioTrack.url, {
          signal: abortController.signal,
        });
        if (!audioResponse.ok) {
          console.warn(`Failed to fetch audio manifest: ${audioResponse.status}`);
          audioSegments = [];
        } else {
          const audioText = await audioResponse.text();
          const audioResult = parseM3U8Manifest(
            audioText,
            parseResult.audioTrack.url
          );
          audioSegments = audioResult.segments;
          console.log(`🎓 🎵 Found ${audioSegments.length} audio segments`);
        }
      } else {
        audioSegments = [];
      }
    } else {
      segments = parseResult.segments;
      totalDuration = parseResult.totalDuration;
      audioSegments = [];
    }

    if (segments.length === 0)
      throw new Error("No video segments found in M3U8 manifest");

    return { segments, totalDuration, audioSegments, hasAudio: audioSegments.length > 0 };
  }

  /**
   * Downloads Skool video segments and stores them in IndexedDB for processing by the offscreen document.
   * @param {string} m3u8Url - The authenticated M3U8 URL
   * @param {string} fileName - The filename to use for the download
   * @returns {Object} Result object with success/failure info
   */
  async function downloadSkoolVideoFromContentScript(m3u8Url, fileName) {
    const downloadId = `skool_${Date.now()}`;
    const abortController = new AbortController();
    const concurrencyLimiter = new ConcurrencyLimiter(10);

    // Track this download for cancellation
    activeSkoolDownloads.set(downloadId, {
      abortController,
      fileName,
      startTime: Date.now(),
    });

    // Notify background script of new download
    try {
      await chrome.runtime.sendMessage({
        action: "registerSkoolDownload",
        downloadId: downloadId,
        fileName: fileName,
      });
    } catch (e) {}

    try {
      const { segments, totalDuration, audioSegments, hasAudio } = await getM3U8Segments(m3u8Url, abortController);
      const totalSegments = segments.length + audioSegments.length;

      console.log(`🎓 Found ${segments.length} segments to download.`);
      if (hasAudio) {
        console.log(`🎓 🎵 Mixed stream segments: ${segments.length} video + ${audioSegments.length} audio`);
      }
      console.log(`🎓 📊 DURATION RECEIVED: ${totalDuration ? totalDuration.toFixed(2) + 's' : 'undefined/null'}`);
      console.log(
        `🎓 Starting dynamic concurrent download of ${totalSegments} segments (max 10 concurrent). Download ID: ${downloadId}`
      );

      let completedSegments = 0;

      // Create a function to download a segment (reused for both video and audio)
      const downloadSegment = (segment, segmentIndex, segmentType = 'video') =>
        concurrencyLimiter.add(async () => {
          // Check for cancellation before each segment
          if (abortController.signal.aborted || globalDownloadCancelled) {
            throw new Error("Download cancelled by user");
          }

          // Also check with background script for global cancellation
          try {
            const response = await chrome.runtime.sendMessage({
              action: "checkDownloadStatus",
            });
            if (response && response.cancelled) {
              globalDownloadCancelled = true;
              abortController.abort();
              throw new Error("Download cancelled by user");
            }
          } catch (e) {
            // Ignore message errors but continue with local cancellation check
          }

          console.log(`🌐 SKOOL NETWORK REQUEST:`, {
            url: segment.url,
            segmentIndex: segmentIndex,
            segmentType: segmentType,
            method: "GET",
            headers: {},
            signal: "AbortController",
          });

          const response = await fetch(segment.url, {
            signal: abortController.signal,
          });

          console.log(`🌐 SKOOL NETWORK RESPONSE:`, {
            url: segment.url,
            segmentIndex: segmentIndex,
            segmentType: segmentType,
            status: response.status,
            statusText: response.statusText,
            headers: Object.fromEntries(response.headers.entries()),
            contentLength: response.headers.get("content-length"),
            contentType: response.headers.get("content-type"),
          });

          if (!response.ok) throw new Error(`HTTP ${response.status}`);

          const arrayBuffer = await response.arrayBuffer();
          const segmentKey = `skool_segment_${downloadId}_${segmentIndex}`;

          // Convert to Uint8Array for Chrome messaging (more efficient than Array.from but transferable)
          const uint8Array = new Uint8Array(arrayBuffer);

          // Send segment directly to background script for storage in extension context
          await chrome.runtime.sendMessage({
            action: "storeSkoolSegment",
            segmentKey: segmentKey,
            segmentData: uint8Array,
            downloadId: downloadId,
            segmentIndex: segmentIndex,
            segmentType: segmentType,
            totalSegments: totalSegments,
            isInit: segment.isInit || false,
          });

          completedSegments++;

          // Send progress update after each segment
          const progress = Math.round(
            (completedSegments / totalSegments) * 100
          );
          chrome.runtime
            .sendMessage({
              action: "skoolDownloadProgress",
              progress: progress,
              status: `Downloaded ${completedSegments}/${totalSegments} segments`,
            })
            .catch(() => {}); // Ignore errors in progress updates

          return { success: true, index: segmentIndex, type: segmentType };
        });

      // Download video segments
      const videoDownloadPromises = segments.map((segment, segmentIndex) =>
        downloadSegment(segment, segmentIndex, 'video')
      );

      // Download audio segments if they exist
      const audioDownloadPromises = audioSegments.map((segment, segmentIndex) =>
        downloadSegment(segment, segments.length + segmentIndex, 'audio')
      );

      // Combine all download promises
      const downloadPromises = [...videoDownloadPromises, ...audioDownloadPromises];

      await Promise.all(downloadPromises);

      console.log(
        `✅ All ${totalSegments} segments sent to background script for storage.`
      );

      // Step 4: Notify background script that download is complete and ready for processing
      console.log(`🎓 📊 SENDING TO BACKGROUND: totalDuration = ${totalDuration ? totalDuration.toFixed(2) + 's' : 'undefined/null'}`);
      await chrome.runtime.sendMessage({
        action: "skoolDownloadReadyForProcessing",
        downloadId: downloadId,
        fileName: fileName,
        totalDuration: totalDuration,
        totalSegments: totalSegments,
        videoSegments: segments.length,
        audioSegments: audioSegments.length,
        hasAudio: hasAudio,
      });

      // Notify background script of successful completion
      await chrome.runtime.sendMessage({
        action: "unregisterSkoolDownload",
        downloadId: downloadId,
        success: true,
      });

      return {
        success: true,
        message: "All segments sent to background for processing.",
      };
    } catch (error) {
      console.error("🎓 Content Script: Skool video download failed:", error);

      // Determine if this was a cancellation
      const wasCancelled =
        error.name === "AbortError" || error.message.includes("cancelled");

      // Notify background script of the failure/cancellation
      chrome.runtime.sendMessage({
        action: wasCancelled ? "skoolDownloadCancelled" : "skoolDownloadFailed",
        error: error.message,
        downloadId: downloadId,
      });

      // Also unregister from active downloads
      chrome.runtime.sendMessage({
        action: "unregisterSkoolDownload",
        downloadId: downloadId,
        success: false,
      });

      throw error;
    } finally {
      // Clean up tracking
      activeSkoolDownloads.delete(downloadId);
    }
  }

  /**
   * Parses M3U8 manifest and extracts segment URLs
   * @param {string} manifestText - The M3U8 manifest content
   * @param {string} baseUrl - The base URL to resolve relative URLs
   * @returns {Array} Array of segment objects with URLs
   */
  function parseM3U8Manifest(manifestText, baseUrl) {
    console.log(
      `🎓 Content Script: Parsing M3U8 manifest with base URL: ${baseUrl}`
    );
    
    // Log first 30 lines of manifest for debugging
    const allLines = manifestText.split("\n");
    console.log(`🎓 📜 M3U8 MANIFEST SAMPLE (first 30 lines of ${allLines.length} total):`);
    allLines.slice(0, 30).forEach((line, idx) => {
      console.log(`🎓 📜 Line ${idx}: ${line}`);
    });
    
    // Log the full manifest content for debugging
    console.log(`🎓 📜 FULL M3U8 MANIFEST CONTENT (${allLines.length} lines):`);
    console.log(manifestText);
    
    const lines = manifestText.split("\n").filter((line) => line.trim());
    const baseUrlObj = new URL(baseUrl);

    console.log(
      `🎓 Content Script: Found ${lines.length} total lines in manifest`
    );

    // Check if this is a master playlist (adaptive streaming)
    const isMasterPlaylist = manifestText.includes("#EXT-X-STREAM-INF");
    console.log(`🎓 Content Script: Is master playlist: ${isMasterPlaylist}`);

    if (isMasterPlaylist) {
      console.log(
        `🎓 Content Script: 🚨 MASTER PLAYLIST DETECTED - Need to download rendition manifest!`
      );

      // Parse audio tracks
      const audioTracks = [];
      const qualities = [];
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        // Parse audio track information
        if (line.startsWith("#EXT-X-MEDIA:")) {
          const typeMatch = line.match(/TYPE=(\w+)/);
          const uriMatch = line.match(/URI="([^"]+)"/);
          const groupIdMatch = line.match(/GROUP-ID="([^"]+)"/);
          const nameMatch = line.match(/NAME="([^"]+)"/);
          
          if (typeMatch && typeMatch[1] === "AUDIO" && uriMatch) {
            const audioTrack = {
              type: "AUDIO",
              groupId: groupIdMatch ? groupIdMatch[1] : null,
              name: nameMatch ? nameMatch[1] : "Default",
              url: new URL(uriMatch[1], baseUrl).href,
            };
            audioTracks.push(audioTrack);
            console.log(`🎓 Content Script: Found audio track: ${audioTrack.name} (${audioTrack.groupId}) - ${audioTrack.url}`);
          }
        }
        
        // Parse video quality levels
        if (line.startsWith("#EXT-X-STREAM-INF")) {
          const nextLine = lines[i + 1];
          if (nextLine && !nextLine.startsWith("#")) {
            const bandwidthMatch = line.match(/BANDWIDTH=(\d+)/);
            const resolutionMatch = line.match(/RESOLUTION=(\d+x\d+)/);
            const audioGroupMatch = line.match(/AUDIO="([^"]+)"/);

            qualities.push({
              bandwidth: bandwidthMatch ? parseInt(bandwidthMatch[1]) : 0,
              resolution: resolutionMatch ? resolutionMatch[1] : "unknown",
              audioGroup: audioGroupMatch ? audioGroupMatch[1] : null,
              url: new URL(nextLine.trim(), baseUrl).href, // Resolve URL immediately
            });
          }
        }
      }

      // Sort by bandwidth (highest first) and choose the best quality
      qualities.sort((a, b) => b.bandwidth - a.bandwidth);
      console.log(
        `🎓 Content Script: Found ${qualities.length} quality levels:`
      );
      qualities.forEach((q, idx) => {
        console.log(
          `🎓 Content Script: Quality ${idx + 1}: ${q.resolution} @ ${
            q.bandwidth
          } bps (audio: ${q.audioGroup}) - ${q.url}`
        );
      });

      if (qualities.length > 0) {
        const bestQuality = qualities[0];
        
        // Find matching audio track for this quality
        let audioTrack = null;
        if (bestQuality.audioGroup && audioTracks.length > 0) {
          audioTrack = audioTracks.find(track => track.groupId === bestQuality.audioGroup);
          if (!audioTrack) {
            audioTrack = audioTracks[0]; // Fallback to first audio track
          }
        }
        
        console.log(
          `🎓 Content Script: 🎯 Selected best quality: ${bestQuality.resolution} @ ${bestQuality.bandwidth} bps`
        );
        if (audioTrack) {
          console.log(`🎓 Content Script: 🎵 Selected audio track: ${audioTrack.name} - ${audioTrack.url}`);
        }

        return {
          isMasterPlaylist: true,
          renditionUrl: bestQuality.url,
          selectedQuality: bestQuality,
          audioTrack: audioTrack,
          hasAudio: !!audioTrack,
        };
      } else {
        throw new Error("No quality levels found in master playlist");
      }
    }

    // This is a rendition playlist - parse actual segments
    console.log(
      `🎓 Content Script: 📹RENDITION PLAYLIST - parsing video segments`
    );
    const segments = [];
    let totalDuration = 0;
    let currentSegmentDuration = 0;
    let segmentDurationSamples = [];
    let initSegmentUrl = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();

      // Parse init segment from #EXT-X-MAP tag
      if (line.startsWith("#EXT-X-MAP:")) {
        const uriMatch = line.match(/URI="([^"]+)"/);
        if (uriMatch) {
          initSegmentUrl = new URL(uriMatch[1], baseUrl).href;
          console.log(`🎓 Content Script: Found init segment: ${initSegmentUrl}`);
        }
      }
      // Parse segment duration from #EXTINF tag
      else if (line.startsWith("#EXTINF:")) {
        const durationMatch = line.match(/#EXTINF:([\d.]+)/);
        if (durationMatch) {
          currentSegmentDuration = parseFloat(durationMatch[1]);
          totalDuration += currentSegmentDuration;
          // Log first 5 segment durations as samples
          if (segmentDurationSamples.length < 5) {
            segmentDurationSamples.push(currentSegmentDuration);
          }
        }
      }
      // Parse segment URL (non-comment line after #EXTINF)
      else if (!line.startsWith("#") && line.length > 0) {
        const segmentUrl = new URL(line, baseUrl).href; // Resolve URL
        segments.push({
          url: segmentUrl,
          index: segments.length,
          duration: currentSegmentDuration,
        });
        currentSegmentDuration = 0; // Reset for next segment
      }
    }

    // Add init segment at the beginning if found
    if (initSegmentUrl) {
      segments.unshift({
        url: initSegmentUrl,
        index: -1, // Special index for init segment
        duration: 0,
        isInit: true,
      });
      console.log(`🎓 Content Script: Added init segment to beginning of segments array`);
    }

    console.log(
      `🎓 Content Script: M3U8 parsing complete - extracted ${segments.length} segments, total duration: ${totalDuration.toFixed(2)}s`
    );
    console.log(`🎓 📊 DURATION CHECK: Total calculated duration = ${totalDuration.toFixed(2)}s for ${segments.length} segments`);
    console.log(`🎓 📊 DURATION CHECK: Average segment duration = ${(totalDuration / segments.length).toFixed(2)}s`);
    console.log(`🎓 📊 DURATION CHECK: Sample segment durations (first 5): ${segmentDurationSamples.map(d => d.toFixed(3)).join(', ')}s`);
    return { isMasterPlaylist: false, segments, totalDuration };
  }

  // =================================================================================
  // MESSAGE LISTENER
  // =================================================================================

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Content script received message:", request.action);

    try {
      switch (request.action) {
        case "getVideoInfo":
          findFirstAvailableVideo().then((videoInfo) => {
            sendResponse({
              success: !!videoInfo,
              videoInfo: videoInfo,
              data: videoInfo,
            });
          });
          break;

        case "getAllLoomEmbeds":
          const allLoomEmbeds = findAllLoomEmbeds();
          sendResponse({
            success: true,
            embeds: allLoomEmbeds,
          });
          break;

        case "findLoomEmbed":
          const loomEmbed = findLoomEmbed();
          sendResponse({
            success: !!loomEmbed,
            embedInfo: loomEmbed,
          });
          break;

        case "findVimeoEmbed":
          const vimeoEmbed = findVimeoEmbed();
          sendResponse({
            success: !!vimeoEmbed,
            embedInfo: vimeoEmbed,
          });
          break;

        case "findYouTubeEmbed":
          const youtubeEmbed = findYouTubeEmbed();
          sendResponse({
            success: !!youtubeEmbed,
            embedInfo: youtubeEmbed,
          });
          break;

        case "findWistiaEmbed":
          const wistiaEmbed = findWistiaEmbed();
          sendResponse({
            success: !!wistiaEmbed,
            embedInfo: wistiaEmbed,
          });
          break;

        case "findSkoolNativeVideo":
          const skoolNativeVideo = findSkoolNativeVideo();
          sendResponse({
            success: !!skoolNativeVideo,
            embedInfo: skoolNativeVideo,
          });
          break;

        case "getAllSkoolNativeVideos":
          const allSkoolNativeVideos = findAllSkoolNativeVideos();
          sendResponse({
            success: true,
            embeds: allSkoolNativeVideos,
          });
          break;

        case "downloadSkoolVideoDirectly":
          console.log(
            "🎓 Content Script: Received downloadSkoolVideoDirectly message"
          );
          downloadSkoolVideoFromContentScript(request.m3u8Url, request.fileName)
            .then((result) => {
              console.log(
                "🎓 Content Script: Download process finished, sending response:",
                result
              );
              sendResponse(result);
            })
            .catch((error) => {
              console.error(
                "🎓 Content Script: Download failed with error:",
                error
              );
              sendResponse({
                success: false,
                error: error.message,
              });
            });
          break;

        case "cancelSkoolDownload":
          console.log(
            "🎓 Content Script: Received cancelSkoolDownload message"
          );

          // Set global cancellation flag for all downloads
          globalDownloadCancelled = true;

          // Cancel specific download if ID provided
          if (request.downloadId) {
            const downloadToCancel = activeSkoolDownloads.get(
              request.downloadId
            );
            if (downloadToCancel) {
              console.log(
                `🎓 Cancelling Skool download: ${request.downloadId}`
              );
              downloadToCancel.abortController.abort();
            }
          }

          // Cancel all active downloads
          for (const [id, download] of activeSkoolDownloads) {
            console.log(`🎓 Cancelling Skool download: ${id}`);
            download.abortController.abort();
          }

          sendResponse({
            success: true,
            message: "All Skool downloads cancelled",
          });
          break;

        case "resetSkoolCancellation":
          console.log("🎓 Content Script: Resetting Skool cancellation state");
          globalDownloadCancelled = false;
          sendResponse({ success: true });
          break;

        case "fetchThumbnail":
          console.log(
            "🖼️ Content Script: Received fetchThumbnail request for:",
            request.url
          );
          fetchThumbnailFromContentScript(request.url)
            .then((result) => {
              console.log(
                "🖼️ Content Script: Sending thumbnail response:",
                result.success ? "SUCCESS" : "FAILED"
              );
              sendResponse(result);
            })
            .catch((error) => {
              console.error(
                "❌ Content Script: Thumbnail fetch failed:",
                error
              );
              sendResponse({
                success: false,
                error: error.message,
              });
            });
          // Return true to indicate we'll send an async response
          return true;

        default:
          sendResponse({
            success: false,
            error: "Unknown action: " + request.action,
          });
      }
    } catch (error) {
      console.error("Error in content script:", error);
      sendResponse({
        success: false,
        error: {
          name: error.name || "Error",
          message: error.message || "Unknown error in content script",
          stack: error.stack,
        },
      });
    }

    return true; // Indicates async response
  });

  // =================================================================================
  // THUMBNAIL FETCHING (FROM CONTENT SCRIPT - NO CORS ISSUES)
  // =================================================================================

  /**
   * Fetches thumbnail from content script context to avoid CORS issues
   * @param {string} url - The thumbnail URL to fetch
   * @returns {Object} Result object with success/failure info and dataUrl
   */
  async function fetchThumbnailFromContentScript(url) {
    try {
      console.log("🖼️ Content Script: Fetching thumbnail from:", url);

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const blob = await response.blob();
      const reader = new FileReader();

      return new Promise((resolve, reject) => {
        reader.onload = () => {
          console.log(
            "✅ Content Script: Thumbnail successfully converted to data URL"
          );
          resolve({
            success: true,
            dataUrl: reader.result,
          });
        };

        reader.onerror = () => {
          console.error(
            "❌ Content Script: Failed to convert thumbnail blob to data URL"
          );
          reject(new Error("Failed to convert image to data URL"));
        };

        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error("❌ Content Script: Thumbnail fetch failed:", error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // =================================================================================
  // DYNAMIC CONTENT DETECTION
  // =================================================================================

  function checkForNewVideos() {
    findFirstAvailableVideo().then((videoInfo) => {
      if (videoInfo) {
        console.log(
          `🎬 Detected ${videoInfo.platform} video:`,
          videoInfo.title
        );
        try {
          chrome.runtime
            .sendMessage({ action: "videoDetected", videoInfo: videoInfo })
            .catch(() => {});
        } catch (e) {}
      }
    });
  }

  // Auto-detect when page loads
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      setTimeout(checkForNewVideos, 1500);
    });
  } else {
    setTimeout(checkForNewVideos, 1500);
  }

  // Monitor for dynamic content changes
  let lastVideoCheck = Date.now();

  const isSkoolPage = window.location.hostname.includes("skool.com");
  const throttleInterval = isSkoolPage ? 500 : 2000;

  console.log(
    `🎬 Content Script: Setting up MutationObserver with ${throttleInterval}ms throttle (Skool: ${isSkoolPage})`
  );

  const observer = new MutationObserver((mutations) => {
    const now = Date.now();
    if (now - lastVideoCheck > throttleInterval) {
      lastVideoCheck = now;

      if (isSkoolPage) {
        const hasNewMuxPlayer = mutations.some((mutation) =>
          Array.from(mutation.addedNodes).some(
            (node) =>
              node.nodeType === Node.ELEMENT_NODE &&
              (node.tagName === "MUX-PLAYER" ||
                node.querySelector?.("mux-player"))
          )
        );

        if (hasNewMuxPlayer) {
          console.log(
            "🎓 Content Script: New mux-player detected, checking immediately"
          );
          setTimeout(checkForNewVideos, 100);
        } else {
          setTimeout(checkForNewVideos, 500);
        }
      } else {
        setTimeout(checkForNewVideos, 500);
      }
    }
  });

  if (document.body) {
    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  window.addEventListener("beforeunload", () => {
    observer.disconnect();
  });
} // End of execution guard
