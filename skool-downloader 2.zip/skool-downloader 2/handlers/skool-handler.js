// =================================================================================
// SKOOL HANDLER
// =================================================================================

export class SkoolHandler {
  constructor(utils) {
    this.utils = utils;
  }

  async downloadVideo(videoInfo) {
    console.log(`🎓 Starting Skool download process for: "${videoInfo.title}"`);

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      downloadCancelled: false,
      activeDownloads: globalState.activeDownloads + 1,
    });

    try {
      const fileName = this.utils.sanitizeFileName(videoInfo.title) + ".mp4";

      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (!tab) throw new Error("No active tab found to start the download.");

      this.utils.sendProgressToPopup(0, "Starting segment download...");

      // Reset content script cancellation state before starting new download
      try {
        await chrome.tabs.sendMessage(tab.id, {
          action: "resetSkoolCancellation",
        });
      } catch (e) {
        console.warn("Failed to reset content script cancellation state:", e);
      }

      // Tell the content script to start its download-to-IndexedDB process.
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "downloadSkoolVideoDirectly",
        m3u8Url: videoInfo.m3u8Url,
        fileName: fileName,
      });

      if (!response || !response.success) {
        throw new Error(
          response.error || "Content script failed to start download."
        );
      }

      console.log(
        "🎓 Content script has acknowledged the download request and is now processing segments."
      );
    } catch (error) {
      console.error("❌ Skool download initiation failed:", error);
      this.utils.sendDownloadError(`Skool Download Failed: ${error.message}`);
      const globalState = this.utils.getGlobalState();
      this.utils.setGlobalState({
        activeDownloads: Math.max(0, globalState.activeDownloads - 1),
      });
      throw error;
    }
  }

  async storeSegment(request, sender, sendResponse) {
    try {
      const {
        segmentKey,
        segmentData,
        downloadId,
        segmentIndex,
        totalSegments,
      } = request;

      // Import IndexedDB utilities
      const DB_NAME = "LoomDownloaderDB";
      const STORE_NAME = "fileStore";
      const DB_VERSION = 1;

      const openDB = () => {
        return new Promise((resolve, reject) => {
          const request = indexedDB.open(DB_NAME, DB_VERSION);
          request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
              db.createObjectStore(STORE_NAME);
            }
          };
          request.onsuccess = (event) => resolve(event.target.result);
          request.onerror = (event) => reject(event.target.error);
        });
      };

      const db = await openDB();
      await new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, "readwrite");
        const store = transaction.objectStore(STORE_NAME);

        let segmentUint8Array;
        if (segmentData instanceof Uint8Array) {
          segmentUint8Array = segmentData;
          request.segmentData = null;
        } else if (segmentData instanceof ArrayBuffer) {
          segmentUint8Array = new Uint8Array(segmentData);
          request.segmentData = null;
        } else if (Array.isArray(segmentData)) {
          segmentUint8Array = new Uint8Array(segmentData);
          segmentData.length = 0;
          request.segmentData = null;
        } else if (typeof segmentData === "object" && segmentData !== null) {
          const values = Object.values(segmentData);
          segmentUint8Array = new Uint8Array(values);
          Object.keys(segmentData).forEach((key) => delete segmentData[key]);
          request.segmentData = null;
        } else {
          throw new Error(`Invalid segment data type: ${typeof segmentData}`);
        }

        const putRequest = store.put(segmentUint8Array, segmentKey);

        transaction.oncomplete = () => resolve();
        transaction.onerror = (event) => reject(event.target.error);
        putRequest.onerror = (event) => reject(event.target.error);
      });

      // Force garbage collection every 25 segments
      if (segmentIndex % 25 === 0 && typeof globalThis.gc === "function") {
        globalThis.gc();
      }

      // Log progress every 50 segments
      if (segmentIndex % 50 === 0 && segmentIndex > 0) {
        console.log(
          `✅ Stored ${
            segmentIndex + 1
          }/${totalSegments} segments in extension IndexedDB`
        );
      }

      if (sendResponse) {
        sendResponse({ success: true });
      }
    } catch (error) {
      console.error(
        `❌ Failed to store segment ${request.segmentIndex}:`,
        error
      );
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  handleProgress(request, sender, sendResponse) {
    this.utils.sendProgressToPopup(request.progress * 0.8, request.status);
    if (sendResponse) {
      sendResponse({ success: true });
    }
  }

  async handleReadyForProcessing(request, sender, sendResponse) {
    try {
      console.log(
        "🎓 All segments in IndexedDB. Starting merge process in offscreen document."
      );
      console.log(`🎓 📊 BACKGROUND RECEIVED: totalDuration = ${request.totalDuration ? request.totalDuration.toFixed(2) + 's' : 'undefined/null'}`);
      this.utils.sendProgressToPopup(
        80,
        "Segments downloaded. Verifying segments..."
      );

      const segmentsKey = `skool_segment_${request.downloadId}`;
      console.log(
        `✅ Content script verified all ${request.totalSegments} segments. Proceeding with merge...`
      );
      this.utils.sendProgressToPopup(85, "Starting merge process...");

      await this.utils.createOffscreenDocument();

      console.log(`🎓 📊 SENDING TO OFFSCREEN: totalDuration = ${request.totalDuration ? request.totalDuration.toFixed(2) + 's' : 'undefined/null'}`);
      
      // Check if we have separate audio/video tracks
      if (request.hasAudio && request.videoSegments && request.audioSegments) {
        console.log(`🎓 🎵 Using separate A/V processing: ${request.videoSegments} video + ${request.audioSegments} audio segments`);
        chrome.runtime.sendMessage({
          type: "MERGE_SEPARATE_AV_FASTSTREAM",
          requestId: request.downloadId,
          segmentsKey: segmentsKey,
          fileName: request.fileName,
          totalSegments: request.totalSegments,
          videoCount: request.videoSegments,
          audioCount: request.audioSegments,
          totalDuration: request.totalDuration,
          isDashStream: false, // Skool uses HLS, not DASH
          streamFormat: 'hls',
        });
      } else {
        // Legacy single-stream processing
        chrome.runtime.sendMessage({
          type: "MERGE_SEGMENTS_FASTSTREAM",
          requestId: request.downloadId,
          segmentsKey: segmentsKey,
          fileName: request.fileName,
          totalSegments: request.totalSegments,
          totalDuration: request.totalDuration,
        });
      }

      if (sendResponse) {
        sendResponse({ success: true });
      }
    } catch (error) {
      console.error("❌ Failed to start offscreen processing:", error);
      this.utils.sendDownloadError(`Merge failed: ${error.message}`);
      const globalState = this.utils.getGlobalState();
      this.utils.setGlobalState({
        activeDownloads: Math.max(0, globalState.activeDownloads - 1),
      });
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  handleDownloadFailed(request, sender, sendResponse) {
    console.error(
      "❌ Content script reported a download failure:",
      request.error
    );
    this.utils.sendDownloadError(request.error);
    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      activeDownloads: Math.max(0, globalState.activeDownloads - 1),
    });
    if (sendResponse) {
      sendResponse({ success: true });
    }
  }

  async initStreamingDownload(request, sender, sendResponse) {
    try {
      console.log(
        `🎓 Background Script: 🌊 INIT STREAMING DOWNLOAD for ${request.fileName}`
      );

      const {
        sessionId,
        fileName,
        totalSegments,
        manifestContent,
        renditionContent,
      } = request;

      const sessionData = {
        sessionId,
        fileName,
        totalSegments,
        manifestContent,
        renditionContent,
        receivedSegments: 0,
        segments: {},
        startTime: Date.now(),
        status: "receiving",
      };

      await this.utils.set(`skool_stream_${sessionId}`, sessionData);

      console.log(
        `🎓 Background Script: ✅ Streaming session initialized: ${sessionId}`
      );
      if (sendResponse) {
        sendResponse({ success: true, sessionId });
      }
    } catch (error) {
      console.error("❌ Error initializing streaming download:", error);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  async streamSegmentBatch(request, sender, sendResponse) {
    try {
      const { sessionId, batchNumber, batchData, isLastBatch } = request;

      console.log(
        `🎓 Background Script: 📦 Receiving batch ${batchNumber} with ${batchData.length} segments (last: ${isLastBatch})`
      );

      const sessionKey = `skool_stream_${sessionId}`;
      const sessionData = await this.utils.get(sessionKey);

      if (!sessionData) {
        throw new Error(`Session not found: ${sessionId}`);
      }

      batchData.forEach((segment, index) => {
        const segmentIndex = (batchNumber - 1) * 10 + index;
        sessionData.segments[segmentIndex] = segment;
      });

      sessionData.receivedSegments += batchData.length;

      const progress =
        (sessionData.receivedSegments / sessionData.totalSegments) * 100;
      this.utils.sendProgressToPopup(
        progress,
        `Streaming: ${sessionData.receivedSegments}/${sessionData.totalSegments} segments`
      );

      await this.utils.set(sessionKey, sessionData);

      console.log(
        `🎓 Background Script: ✅ Batch ${batchNumber} stored. Progress: ${sessionData.receivedSegments}/${sessionData.totalSegments}`
      );

      if (sendResponse) {
        sendResponse({
          success: true,
          receivedSegments: sessionData.receivedSegments,
        });
      }
    } catch (error) {
      console.error("❌ Error processing segment batch:", error);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  async finalizeStreamingDownload(request, sender, sendResponse) {
    try {
      const { sessionId } = request;

      console.log(
        `🎓 Background Script: 🏁 FINALIZING STREAMING DOWNLOAD for session ${sessionId}`
      );

      const sessionKey = `skool_stream_${sessionId}`;
      const sessionData = await this.utils.get(sessionKey);

      if (!sessionData) {
        throw new Error(`Session not found: ${sessionId}`);
      }

      if (sessionData.receivedSegments !== sessionData.totalSegments) {
        throw new Error(
          `Missing segments: received ${sessionData.receivedSegments}, expected ${sessionData.totalSegments}`
        );
      }

      console.log(
        `🎓 Background Script: 📦 Assembling ${sessionData.receivedSegments} segments into ${sessionData.fileName}`
      );

      const segmentsArray = [];
      for (let i = 0; i < sessionData.totalSegments; i++) {
        if (!sessionData.segments[i]) {
          throw new Error(`Missing segment at index ${i}`);
        }
        segmentsArray.push(sessionData.segments[i]);
      }

      const globalState = this.utils.getGlobalState();
      this.utils.setGlobalState({
        activeDownloads: globalState.activeDownloads + 1,
      });

      await this.utils.createOffscreenDocument();

      await this.assembleAndSaveSkoolVideo(
        segmentsArray,
        sessionData.fileName,
        sessionData.manifestContent,
        sessionData.renditionContent
      );

      await this.utils.remove(sessionKey);

      console.log(
        `🎓 Background Script: ✅ Streaming download completed: ${sessionData.fileName}`
      );
      // Don't send download complete here - let the actual Chrome download completion handle it
      console.log(
        "📥 Skool streaming processing completed, awaiting Chrome download completion"
      );

      if (sendResponse) {
        sendResponse({ success: true });
      }
    } catch (error) {
      console.error("❌ Error finalizing streaming download:", error);
      this.utils.sendDownloadError(
        `Streaming download failed: ${error.message}`
      );
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    } finally {
      const globalState = this.utils.getGlobalState();
      if (globalState.activeDownloads > 0) {
        this.utils.setGlobalState({
          activeDownloads: globalState.activeDownloads - 1,
        });
      }
      // Don't close offscreen here - let the Chrome download completion handle it
      console.log(
        `📊 Skool handler finished, activeDownloads: ${globalState.activeDownloads}, keeping offscreen open for Chrome download`
      );
    }
  }

  async abortStreamingDownload(request, sender, sendResponse) {
    try {
      const { sessionId } = request;

      console.log(
        `🎓 Background Script: ❌ ABORTING STREAMING DOWNLOAD for session ${sessionId}`
      );

      const sessionKey = `skool_stream_${sessionId}`;
      await this.utils.remove(sessionKey);

      console.log(
        `🎓 Background Script: ✅ Streaming download session aborted and cleaned up: ${sessionId}`
      );

      if (sendResponse) {
        sendResponse({ success: true });
      }
    } catch (error) {
      console.error("❌ Error aborting streaming download:", error);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  async assembleAndSaveSkoolVideo(segments, fileName) {
    try {
      segments.sort((a, b) => a.index - b.index);

      const totalSize = segments.reduce(
        (sum, segment) => sum + segment.size,
        0
      );
      console.log(
        `🎓 Assembling ${segments.length} segments, total size: ${totalSize} bytes`
      );

      segments.forEach((segment, idx) => {
        console.log(
          `🎓 Segment ${idx + 1}: index=${segment.index}, size=${
            segment.size
          } bytes`
        );
      });

      const videoData = new Uint8Array(totalSize);
      let offset = 0;

      for (let i = 0; i < segments.length; i++) {
        const segment = segments[i];
        const segmentData = new Uint8Array(segment.data);
        videoData.set(segmentData, offset);
        offset += segment.size;

        console.log(
          `🎓 Assembled segment ${i + 1}/${
            segments.length
          }, offset: ${offset}, total progress: ${offset}/${totalSize} bytes`
        );

        const progress = Math.round(85 + (i / segments.length) * 15);
        this.utils.sendProgressToPopup(
          progress,
          `Assembling segment ${i + 1}/${segments.length}...`
        );
      }

      console.log(
        `🎓 Video assembly complete, final size: ${videoData.byteLength} bytes`
      );

      const videoBlob = new Blob([videoData], { type: "video/mp4" });
      console.log(`🎓 Created video blob, size: ${videoBlob.size} bytes`);

      this.utils.sendProgressToPopup(95, "Converting to download format...");

      const arrayBuffer = await videoBlob.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);

      console.log(
        `🎓 Converting ${uint8Array.length} bytes to base64 data URL...`
      );

      let base64String = "";
      const chunkSize = 8192;

      for (let i = 0; i < uint8Array.length; i += chunkSize) {
        const chunk = uint8Array.slice(i, i + chunkSize);
        base64String += btoa(String.fromCharCode.apply(null, chunk));

        if (i % (chunkSize * 10) === 0) {
          const progress = Math.round((i / uint8Array.length) * 100);
          console.log(
            `🎓 Base64 conversion progress: ${progress}% (${i}/${uint8Array.length} bytes)`
          );
          this.utils.sendProgressToPopup(
            95 + progress * 0.03,
            `Converting to download format... ${progress}%`
          );
        }
      }

      const dataUrl = `data:video/mp4;base64,${base64String}`;
      console.log(`🎓 Data URL created successfully`);

      this.utils.sendProgressToPopup(98, "Saving video file...");

      try {
        await chrome.downloads.download({
          url: dataUrl,
          filename: fileName,
          saveAs: true,
        });

        console.log(`🎓 Download initiated successfully for ${fileName}`);
      } catch (downloadError) {
        console.error(`🎓 Download failed:`, downloadError);
        throw new Error(
          `Download failed: ${downloadError.message} (size: ${uint8Array.length} bytes, dataURL: ${dataUrl.length} chars)`
        );
      }

      console.log(`🎓 Video saved as: ${fileName}`);
    } catch (error) {
      console.error("🎓 Failed to assemble video:", error);
      throw new Error(`Failed to assemble video: ${error.message}`);
    }
  }

  async downloadDASH(request, sender, sendResponse) {
    try {
      const { dashUrl, fileName, isEmbedSplit } = request;
      console.log(`🎓 Starting DASH download for: ${fileName}`);
      console.log(`📄 DASH URL: ${dashUrl}`);

      this.utils.sendProgressToPopup(0, "Fetching DASH manifest...");

      const manifestResponse = await fetch(dashUrl);
      if (!manifestResponse.ok) {
        throw new Error(
          `Failed to fetch DASH manifest: ${manifestResponse.status}`
        );
      }

      const manifestText = await manifestResponse.text();
      console.log(`📄 DASH Manifest length: ${manifestText.length} characters`);

      this.utils.sendProgressToPopup(5, "Parsing DASH manifest...");

      const adaptationSets = this.parseXML(manifestText);
      console.log(`🎬 Found ${adaptationSets.length} adaptation sets`);

      if (!adaptationSets.length) {
        throw new Error("No adaptation sets found in DASH manifest");
      }

      const dashUrl_obj = new URL(dashUrl);
      const baseUrl = `${dashUrl_obj.protocol}//${
        dashUrl_obj.host
      }${dashUrl_obj.pathname.substring(
        0,
        dashUrl_obj.pathname.lastIndexOf("/") + 1
      )}`;
      const query = dashUrl_obj.search;

      console.log(`🌐 Base URL: ${baseUrl}`);
      console.log(`🔍 Query: ${query}`);

      let audioSegments = [];
      let videoSegments = [];

      this.utils.sendProgressToPopup(10, "Extracting segments...");

      for (const adaptationSet of adaptationSets) {
        console.log(
          `🎭 Processing ${adaptationSet.contentType} adaptation set with ${adaptationSet.representations.length} representations`
        );

        const bestRepresentation = adaptationSet.representations.reduce(
          (best, current) =>
            current.bandwidth > best.bandwidth ? current : best
        );

        console.log(
          `👑 Selected best ${adaptationSet.contentType} representation: ${bestRepresentation.bandwidth} bps`
        );

        const segments = this.extractSegments(
          bestRepresentation,
          baseUrl,
          query
        );
        console.log(
          `📦 Extracted ${segments.length} ${adaptationSet.contentType} segments`
        );

        if (adaptationSet.contentType === "audio") {
          audioSegments = segments;
        } else if (adaptationSet.contentType === "video") {
          videoSegments = segments;
        }
      }

      console.log(`🎵 Audio segments: ${audioSegments.length}`);
      console.log(`🎬 Video segments: ${videoSegments.length}`);

      if (audioSegments.length === 0 && videoSegments.length === 0) {
        throw new Error("No segments found in DASH manifest");
      }

      this.utils.sendProgressToPopup(15, "Starting segment downloads...");

      await this.downloadDASHSegments(
        audioSegments,
        videoSegments,
        fileName,
        isEmbedSplit
      );

      if (sendResponse) {
        sendResponse({ success: true });
      }
    } catch (error) {
      console.error("❌ DASH download failed:", error);
      this.utils.sendDownloadError(`DASH Download Failed: ${error.message}`);
      const globalState = this.utils.getGlobalState();
      this.utils.setGlobalState({
        activeDownloads: Math.max(0, globalState.activeDownloads - 1),
      });
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  parseXML(xmlString) {
    const adaptationSetRegex =
      /<AdaptationSet[^>]*?contentType="(audio|video)"[^>]*?>(.*?)<\/AdaptationSet>/gs;
    const matches = [...xmlString.matchAll(adaptationSetRegex)];

    const adaptationSets = matches.map((match) => {
      const contentType = match[1];
      const content = match[2];

      const representationRegex =
        /<Representation[^>]*?bandwidth="(\d+)"[^>]*?>(.*?)<\/Representation>/gs;
      const representationMatches = [...content.matchAll(representationRegex)];

      const representations = representationMatches.map((repMatch) => ({
        bandwidth: parseInt(repMatch[1], 10),
        innerHTML: repMatch[2],
      }));

      return {
        contentType,
        representations,
      };
    });

    console.log(`📋 Parsed ${adaptationSets.length} adaptation sets:`);
    adaptationSets.forEach((as, i) => {
      console.log(
        `   ${i + 1}. ${as.contentType}: ${
          as.representations.length
        } representations`
      );
      as.representations.forEach((rep, j) => {
        console.log(`      ${j + 1}. Bandwidth: ${rep.bandwidth}`);
      });
    });

    return adaptationSets;
  }

  extractSegments(representation, baseUrl, query) {
    const segments = [];

    const segmentTemplateRegex =
      /<SegmentTemplate[^>]*initialization="([^"]+)"[^>]*media="([^"]+)"(?:[^>]*startNumber="(\d+)")?/;
    const templateMatch = segmentTemplateRegex.exec(representation.innerHTML);

    if (templateMatch) {
      const initialization = templateMatch[1];
      const media = templateMatch[2];
      const startNumber = templateMatch[3] ? parseInt(templateMatch[3], 10) : 1;

      console.log(
        `🔧 Template - Init: ${initialization}, Media: ${media}, Start: ${startNumber}`
      );

      const initUrl = new URL(initialization, baseUrl);
      initUrl.search = query;
      segments.push({ uri: initUrl.href });
      console.log(`🚀 Init segment: ${initUrl.href}`);

      const segmentTimelineRegex =
        /<SegmentTimeline[^>]*>(.*?)<\/SegmentTimeline>/s;
      const timelineMatch =
        representation.innerHTML.match(segmentTimelineRegex);

      if (timelineMatch) {
        const timelineContent = timelineMatch[1];
        const sTagRegex = /<S\s*([^>]*)\/>/g;
        const sTagMatches = [...timelineContent.matchAll(sTagRegex)];

        console.log(`⏰ Found ${sTagMatches.length} timeline entries`);

        let segmentIndex = startNumber;
        for (const sMatch of sTagMatches) {
          const attrs = sMatch[1] || "";
          const rMatch = attrs.match(/r="(\d+)"/);
          const repeatCount = rMatch ? parseInt(rMatch[1], 10) : 0;

          let segmentUrl = new URL(
            media.replace(/\$Number\$/, segmentIndex),
            baseUrl
          );
          segmentUrl.search = query;
          segments.push({ uri: segmentUrl.href });
          segmentIndex++;

          for (let i = 0; i < repeatCount; i++) {
            segmentUrl = new URL(
              media.replace(/\$Number\$/, segmentIndex),
              baseUrl
            );
            segmentUrl.search = query;
            segments.push({ uri: segmentUrl.href });
            segmentIndex++;
          }
        }
      }
    } else {
      console.log("📦 Using SegmentURL fallback");
      const segmentRegex = /<SegmentURL[^>]*media="([^"]+)"/g;
      let match;
      while ((match = segmentRegex.exec(representation.innerHTML)) !== null) {
        const segmentUrl = new URL(match[1], baseUrl);
        segmentUrl.search = query;
        segments.push({ uri: segmentUrl.href });
      }
    }

    console.log(`📦 Extracted ${segments.length} segments`);
    return segments;
  }

  async downloadDASHSegments(
    audioSegments,
    videoSegments,
    fileName,
    isEmbedSplit = false
  ) {
    console.log(
      `🔽 Downloading DASH segments using FastStream approach - Audio: ${audioSegments.length}, Video: ${videoSegments.length}`
    );

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      downloadCancelled: false,
      activeDownloads: globalState.activeDownloads + 1,
    });

    try {
      // Combine all segments for download
      const allSegments = [];

      // Add audio segments with type identifier
      audioSegments.forEach((segment, index) => {
        allSegments.push({
          ...segment,
          segmentType: "audio",
          segmentIndex: index,
        });
      });

      // Add video segments with type identifier
      videoSegments.forEach((segment, index) => {
        allSegments.push({
          ...segment,
          segmentType: "video",
          segmentIndex: index,
        });
      });

      console.log(`📦 Total segments to download: ${allSegments.length}`);

      if (allSegments.length === 0) {
        throw new Error("No segments to download");
      }

      this.utils.sendProgressToPopup(75, "Preparing segment processor...");
      await this.utils.createOffscreenDocument();

      const requestId = this.utils.uuidv4();
      const segmentsKey = `skool_dash_segments_${requestId}`;

      // Download segments in batches and store in IndexedDB
      await this.downloadSegmentBatches(allSegments, segmentsKey);

      const currentGlobalState = this.utils.getGlobalState();
      if (currentGlobalState.downloadCancelled) {
        console.log("⏹️ Download cancelled, aborting processing");
        return;
      }

      this.utils.sendProgressToPopup(85, "Processing DASH segments...");

      // Send to offscreen for processing
      const response = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          chrome.runtime.onMessage.removeListener(responseListener);
          reject(new Error("Offscreen processing timeout"));
        }, 300000);

        const responseListener = (message) => {
          if (
            message.type === "MERGE_SEGMENTS_RESPONSE" &&
            message.requestId === requestId
          ) {
            clearTimeout(timeout);
            chrome.runtime.onMessage.removeListener(responseListener);
            if (message.success) {
              resolve(message);
            } else {
              reject(
                new Error(
                  message.error?.message || "Offscreen processing failed"
                )
              );
            }
          }
        };

        chrome.runtime.onMessage.addListener(responseListener);

        chrome.runtime.sendMessage({
          type: "MERGE_SEGMENTS_FASTSTREAM",
          requestId,
          segmentsKey,
          fileName,
          totalSegments: allSegments.length,
          segmentTypes: {
            audioCount: audioSegments.length,
            videoCount: videoSegments.length,
          },
          isDashStream: true,
          isEmbedSplit,
        });
      });

      if (response && response.success) {
        console.log("✅ Offscreen DASH processing completed");
        // Don't send download complete here - let the actual Chrome download completion handle it
        console.log(
          "📥 Skool DASH processing completed, awaiting Chrome download completion"
        );
      } else {
        throw new Error("Offscreen DASH processing failed");
      }
    } catch (error) {
      console.error("❌ DASH segments download failed:", error);
      this.utils.sendDownloadError(`DASH Download Failed: ${error.message}`);
      throw error;
    } finally {
      const currentGlobalState = this.utils.getGlobalState();
      this.utils.setGlobalState({
        activeDownloads: Math.max(0, currentGlobalState.activeDownloads - 1),
      });
      // Don't close offscreen here - let the Chrome download completion handle it
      console.log(
        `📊 Skool DASH handler finished, activeDownloads: ${currentGlobalState.activeDownloads}, keeping offscreen open for Chrome download`
      );
    }
  }

  async downloadSegmentBatches(segments, segmentsKey) {
    const batchSize = 10;
    let completedSegments = 0;

    for (let i = 0; i < segments.length; i += batchSize) {
      const currentGlobalState = this.utils.getGlobalState();
      if (currentGlobalState.downloadCancelled) {
        console.log("⏹️ Segment download cancelled by user");
        return;
      }

      const batch = segments.slice(i, i + batchSize);
      console.log(
        `📦 Downloading DASH batch ${Math.floor(i / batchSize) + 1}/${Math.ceil(
          segments.length / batchSize
        )} (${batch.length} segments)`
      );

      const batchPromises = batch.map(async (segment, batchIndex) => {
        const segmentNumber = i + batchIndex;

        try {
          const response = await fetch(segment.uri);
          if (!response.ok) {
            throw new Error(
              `Segment ${segmentNumber + 1} download failed: ${response.status}`
            );
          }

          const arrayBuffer = await response.arrayBuffer();
          console.log(
            `✅ ${segment.segmentType} segment ${segmentNumber + 1}/${
              segments.length
            } downloaded (${arrayBuffer.byteLength} bytes)`
          );

          // Store in IndexedDB with segment metadata
          const segmentKey = `${segmentsKey}_${segmentNumber}`;
          await this.utils.set(segmentKey, {
            data: arrayBuffer,
            segmentType: segment.segmentType,
            segmentIndex: segment.segmentIndex,
            globalIndex: segmentNumber,
          });

          return true;
        } catch (error) {
          console.error(`❌ Segment ${segmentNumber + 1} failed:`, error);
          throw error;
        }
      });

      await Promise.all(batchPromises);

      completedSegments += batch.length;
      const progress = 15 + (completedSegments / segments.length) * 60;
      this.utils.sendProgressToPopup(
        Math.min(progress, 80),
        `Downloaded ${completedSegments}/${segments.length} DASH segments`
      );

      // Garbage collection
      if (i % (batchSize * 4) === 0 && typeof globalThis.gc === "function") {
        console.log("🗑️ Running garbage collection");
        globalThis.gc();
      }
    }

    console.log(
      `✅ All ${segments.length} DASH segments downloaded and stored`
    );
  }

  async mergeAudioVideo(audioData, videoData, fileName, isEmbedSplit) {
    try {
      if (audioData.length === 0 && videoData.length === 0) {
        throw new Error("No data to merge");
      }

      if (audioData.length === 0) {
        console.log("📹 Video-only DASH stream");
        const videoBlob = this.concatenateSegments(videoData);
        await this.saveBlob(videoBlob, fileName);
        return;
      }

      if (videoData.length === 0) {
        console.log("🎵 Audio-only DASH stream");
        const audioBlob = this.concatenateSegments(audioData);
        const audioFileName = fileName.replace(".mp4", ".m4a");
        await this.saveBlob(audioBlob, audioFileName);
        return;
      }

      console.log(
        "⚠️ DASH streams with separate audio and video cannot be properly merged without FFmpeg"
      );
      console.log("🔄 Saving separate audio and video files instead");

      const audioBlob = this.concatenateSegments(audioData);
      const videoBlob = this.concatenateSegments(videoData);

      console.log(`🎵 Audio blob size: ${audioBlob.size} bytes`);
      console.log(`📹 Video blob size: ${videoBlob.size} bytes`);

      // Save separate files since we can't properly merge without FFmpeg
      if (isEmbedSplit) {
        const audioFileName = fileName.replace(".mp4", "_audio.m4a");
        const videoFileName = fileName.replace(".mp4", "_video.mp4");

        await Promise.all([
          this.saveBlob(audioBlob, audioFileName),
          this.saveBlob(videoBlob, videoFileName),
        ]);

        console.log(
          `✅ Saved separate files: ${audioFileName} and ${videoFileName}`
        );
      } else {
        await this.saveBlob(videoBlob, fileName);
        const audioFileName = fileName.replace(".mp4", "_audio.m4a");
        await this.saveBlob(audioBlob, audioFileName);

        console.log(
          `✅ Saved separate files: ${fileName} and ${audioFileName}`
        );
      }
    } catch (error) {
      console.error("❌ Merge failed:", error);
      throw error;
    }
  }

  concatenateSegments(segments) {
    if (!segments || segments.length === 0) {
      throw new Error("No segments to concatenate");
    }

    const totalSize = segments.reduce(
      (sum, segment) => sum + segment.byteLength,
      0
    );
    const concatenated = new Uint8Array(totalSize);

    let offset = 0;
    for (const segment of segments) {
      concatenated.set(segment, offset);
      offset += segment.byteLength;
    }

    return new Blob([concatenated]);
  }

  async saveBlob(blob, fileName) {
    try {
      this.utils.sendProgressToPopup(95, "Saving file...");

      const arrayBuffer = await blob.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);

      let base64String = "";
      const chunkSize = 8192;

      for (let i = 0; i < uint8Array.length; i += chunkSize) {
        const chunk = uint8Array.slice(i, i + chunkSize);
        base64String += btoa(String.fromCharCode.apply(null, chunk));

        if (i % (chunkSize * 10) === 0) {
          const progress = Math.round((i / uint8Array.length) * 100);
          this.utils.sendProgressToPopup(
            95 + progress * 0.03,
            `Converting... ${progress}%`
          );
        }
      }

      const dataUrl = `data:video/mp4;base64,${base64String}`;

      await chrome.downloads.download({
        url: dataUrl,
        filename: fileName,
        saveAs: true,
      });

      console.log(`✅ File saved: ${fileName}`);
    } catch (error) {
      console.error("❌ Save failed:", error);
      throw error;
    }
  }

  async findVideo(request, sender, sendResponse) {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      // Use content script messaging instead of executeScript to get updated platform detection
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "findSkoolNativeVideo",
      });

      const skoolVideo = response?.success ? response.embedInfo : null;
      console.log("🎓 Skool native video result:", skoolVideo);

      if (skoolVideo) {
        // Ensure thumbnail information is properly preserved in response
        const videoResponse = {
          ...skoolVideo,
          thumbnail: skoolVideo.thumbnail || null,
        };

        console.log(
          `🎓 Skool video found with thumbnail: ${
            videoResponse.thumbnail ? "Available" : "Not available"
          }`
        );

        if (sendResponse) {
          sendResponse({
            success: true,
            embedInfo: videoResponse,
            videoInfo: videoResponse,
          });
        }
      } else {
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No Skool native video found on this page.",
          });
        }
      }
    } catch (error) {
      console.error("❌ Error in findSkoolNativeVideo:", error);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  async getAllVideos(request, sender, sendResponse) {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          if (typeof findAllSkoolNativeVideos === "function") {
            return findAllSkoolNativeVideos();
          } else {
            console.error("findAllSkoolNativeVideos function not available");
            return [];
          }
        },
      });

      const allSkoolVideos = results?.[0]?.result || [];

      // Ensure thumbnail information is properly preserved for all videos
      const videosWithThumbnails = allSkoolVideos.map((video) => ({
        ...video,
        thumbnail: video.thumbnail || null,
      }));

      console.log("🎓 All Skool native videos result:", videosWithThumbnails);
      console.log(
        `🎓 Found ${videosWithThumbnails.length} videos, ${
          videosWithThumbnails.filter((v) => v.thumbnail).length
        } with thumbnails`
      );

      if (sendResponse) {
        sendResponse({
          success: true,
          embeds: videosWithThumbnails,
          videoInfo:
            videosWithThumbnails.length > 0 ? videosWithThumbnails[0] : null,
        });
      }
    } catch (error) {
      console.error("❌ Error in getAllSkoolNativeVideos:", error);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message, embeds: [] });
      }
    }
  }
}
