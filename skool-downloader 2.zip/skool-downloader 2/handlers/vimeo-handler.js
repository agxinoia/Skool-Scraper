// =================================================================================
// VIMEO HANDLER - COMPLETE IMPLEMENTATION
// =================================================================================

// Global debug log that should always show when file is loaded
console.log("VIMEO HANDLER FILE LOADED WITH FMP4 TESTING CODE");

export class VimeoHandler {
  constructor(utils) {
    this.utils = utils;

    // Testing configuration for format forcing - SINGLE SOURCE OF TRUTH
    this.TESTING_CONFIG = {
      FORCE_FMP4_FORMAT: false, // Set to true to force sf=fmp4 for testing
    };

    // Debug: Always log when handler is created
    console.log(
      `VIMEO HANDLER CREATED - FORCE_FMP4_FORMAT: ${this.TESTING_CONFIG.FORCE_FMP4_FORMAT}`
    );

    this.CLIENT_CONFIG = {
      CACHE_KEY: null,
      CACHE_ONLY: false,
      VIEWER_JWT: true,
      REQUIRES_AUTH: true,
      USER_AGENT: null,
      VIDEOS_FIELDS: [
        "config_url",
        "created_time",
        "description",
        "license",
        "metadata.connections.comments.total",
        "metadata.connections.likes.total",
        "release_time",
        "stats.plays",
      ],
    };
    this.CLIENT_HEADERS = {
      Accept: "application/vnd.vimeo.*+json; version=3.4.10",
      "Accept-Language": "en",
    };
  }

  getBestThumbnail(pictures) {
    if (!pictures?.sizes || pictures.sizes.length === 0) {
      return null;
    }

    let targetThumbnail = pictures.sizes.find(
      (size) => size.width === 1280 && size.height === 720
    );

    if (!targetThumbnail) {
      targetThumbnail = pictures.sizes.reduce((largest, current) => {
        const largestArea = (largest.width || 0) * (largest.height || 0);
        const currentArea = (current.width || 0) * (current.height || 0);
        return currentArea > largestArea ? current : largest;
      });
    }

    console.log(
      `🖼️ Selected thumbnail: ${targetThumbnail?.width}x${targetThumbnail?.height} - ${targetThumbnail?.link}`
    );
    return targetThumbnail?.link;
  }

  async isAuthenticated() {
    try {
      const cookie = await chrome.cookies.get({
        url: "https://vimeo.com",
        name: "vimeo",
      });
      return !!cookie;
    } catch (error) {
      console.warn("Could not check Vimeo authentication:", error);
      return false;
    }
  }

  async getOAuthToken() {
    console.log(`🔄 Fetching JWT for web client...`);

    try {
      const viewerResponse = await fetch("https://vimeo.com/_next/viewer", {
        headers: { Accept: "application/json" },
      });

      if (viewerResponse.ok) {
        const viewerInfo = await viewerResponse.json();
        if (viewerInfo.jwt) {
          console.log(`✅ Got JWT token for web client`);
          return `jwt ${viewerInfo.jwt}`;
        }
      } else {
        const errorText = await viewerResponse.text();
        const isRateLimited =
          viewerResponse.status === 429 ||
          errorText.includes("rate limit") ||
          errorText.includes("quota exceeded") ||
          errorText.includes("Too Many Requests") ||
          errorText.includes("try again");

        if (isRateLimited) {
          console.warn("⚠️ Rate limit detected during JWT token request");
          throw new Error("JWT request rate limited");
        }
      }
    } catch (error) {
      console.warn("⚠️ Failed to get JWT:", error);
      if (error.message.includes("rate limit")) {
        throw error;
      }
    }

    return null;
  }

  async extractVideoInfoFromPage(url) {
    console.log("🔍 Extracting video info from page:", url);

    return new Promise((resolve) => {
      chrome.tabs.query({}, (tabs) => {
        let targetTab = tabs.find((tab) => tab.url === url);

        if (!targetTab) {
          const baseUrl = url.split("?")[0];
          targetTab = tabs.find(
            (tab) => tab.url && tab.url.startsWith(baseUrl)
          );
        }

        if (!targetTab) {
          targetTab = tabs.find((tab) => tab.active && tab.currentWindow);
        }

        if (targetTab) {
          console.log(
            `📋 Sending message to tab: ${targetTab.id} (${targetTab.url})`
          );
          chrome.tabs.sendMessage(
            targetTab.id,
            { action: "getVideoInfo" },
            (response) => {
              if (chrome.runtime.lastError || !response) {
                const error = chrome.runtime.lastError;
                const errorMessage = error
                  ? error.message || JSON.stringify(error)
                  : "No response from content script";
                console.error(
                  "Failed to get video info from content script:",
                  errorMessage
                );
                resolve(null);
                return;
              }

              if (!response.success) {
                const errorDetails = response.error
                  ? `${response.error.name}: ${response.error.message}`
                  : "Content script returned error without details";
                console.error("Content script returned error:", errorDetails);
                if (response.error && response.error.stack) {
                  console.error("Error stack:", response.error.stack);
                }
                resolve(null);
                return;
              }

              resolve(response.data);
            }
          );
        } else {
          console.error("No suitable tab found for URL:", url);
          resolve(null);
        }
      });
    });
  }

  async extractVideoInfoFromOnDemandPage(url) {
    try {
      console.log("🔍 Fetching on-demand page:", url);
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`On-demand page request failed: ${response.status}`);
      }

      const webpage = await response.text();

      const configUrlMatch = webpage.match(/data-config-url="([^"]+)"/);
      if (configUrlMatch && configUrlMatch[1]) {
        const configUrl = configUrlMatch[1].replace(/&amp;/g, "&");
        console.log("✅ Found config URL in on-demand page:", configUrl);

        const configInfo = await this.extractVideoInfoFromConfig(configUrl);
        if (configInfo) {
          return { ...configInfo, method: "ondemand" };
        }
      }

      const vimeoConfigMatch = webpage.match(/vimeo\.config\s*=\s*({.+?});/);
      if (vimeoConfigMatch && vimeoConfigMatch[1]) {
        const config = JSON.parse(vimeoConfigMatch[1]);
        if (config && config.video) {
          const videoId = config.video.id;
          return await this.extractVideoInfoFromAPI(videoId);
        }
      }

      const playerUrlMatch = webpage.match(
        /"(https:\/\/player\.vimeo\.com\/video\/\d+[^"]*)"/
      );
      if (playerUrlMatch && playerUrlMatch[1]) {
        return this.extractInfo(playerUrlMatch[1]);
      }

      throw new Error("Could not find video information on on-demand page");
    } catch (error) {
      console.error(
        "❌ Failed to extract video info from on-demand page:",
        error
      );
      return null;
    }
  }

  async extractVideoInfoFromReviewPage(url) {
    const match = url.match(/vimeo\.com\/([^/]+)\/review\/(\d+)\/([\da-f]+)/);
    if (!match) {
      return null;
    }

    const [, user, videoId, hash] = match;
    const dataUrl = `https://vimeo.com/${user}/review/data/${videoId}/${hash}`;

    try {
      console.log("🔍 Fetching review data from:", dataUrl);
      const dataResponse = await fetch(dataUrl);
      if (!dataResponse.ok) {
        throw new Error(`Review data request failed: ${dataResponse.status}`);
      }

      const data = await dataResponse.json();

      if (data.clipData && data.clipData.configUrl) {
        console.log(
          "✅ Found config URL in review data:",
          data.clipData.configUrl
        );

        const configInfo = await this.extractVideoInfoFromConfig(
          data.clipData.configUrl
        );
        if (configInfo) {
          return { ...configInfo, method: "review" };
        }
        return null;
      } else {
        throw new Error("Could not find config URL in review data");
      }
    } catch (error) {
      console.error("❌ Failed to extract video info from review page:", error);
      return null;
    }
  }

  async extractVideoInfoFromEventPage(url) {
    const match = url.match(/vimeo\.com\/event\/(\d+)(?:\/videos\/(\d+))?/);
    if (!match) {
      return null;
    }

    const [, eventId, videoId] = match;

    try {
      console.log("🔍 Extracting video info from event page:", url);

      const viewerResponse = await fetch("https://vimeo.com/_next/viewer");
      if (!viewerResponse.ok) {
        throw new Error(`Failed to get viewer info: ${viewerResponse.status}`);
      }

      const viewerInfo = await viewerResponse.json();

      const eventsApiUrl = `https://api.vimeo.com/live_events/${eventId}`;
      const query = new URLSearchParams({
        fields:
          "title,uri,clip_to_play.name,clip_to_play.uri,clip_to_play.config_url,clip_to_play.live.status,streamable_clip.name,streamable_clip.uri,streamable_clip.config_url,streamable_clip.live.status",
        clip_to_play_id: videoId || "0",
      });

      const eventResponse = await fetch(`${eventsApiUrl}?${query}`, {
        headers: {
          Authorization: `jwt ${viewerInfo.jwt}`,
          Accept: "application/json",
        },
      });

      if (!eventResponse.ok) {
        throw new Error(`Events API request failed: ${eventResponse.status}`);
      }

      const eventData = await eventResponse.json();
      console.log("✅ Event API response:", eventData);

      const clipData = eventData.clip_to_play || eventData.streamable_clip;
      if (!clipData || !clipData.config_url) {
        throw new Error("Could not find config URL in event data");
      }

      const configInfo = await this.extractVideoInfoFromConfig(
        clipData.config_url
      );
      if (configInfo) {
        let pageThumbnail = null;
        try {
          const pageInfo = await this.extractVideoInfoFromPage(url);
          if (pageInfo && pageInfo.thumbnail) {
            pageThumbnail = pageInfo.thumbnail;
            console.log(
              "✅ Extracted thumbnail from event page DOM via content script:",
              pageThumbnail
            );
          } else {
            console.log("🔄 Trying direct HTML parsing as fallback...");
            const response = await fetch(url);
            if (response.ok) {
              const html = await response.text();

              const thumbnailSelectors = [
                /class="ContentAreaBackground_module_img__[^"]*"[^>]*src="([^"]+)"/,
                /<meta property="og:image"[^>]*content="([^"]+)"/,
                /<meta name="twitter:image"[^>]*content="([^"]+)"/,
              ];

              for (const selector of thumbnailSelectors) {
                const match = html.match(selector);
                if (match && match[1]) {
                  pageThumbnail = match[1];
                  console.log(
                    "✅ Extracted thumbnail from event page HTML:",
                    pageThumbnail
                  );
                  break;
                }
              }
            }
          }
        } catch (error) {
          console.log("⚠️ Could not extract thumbnail from event page:", error);
        }

        return {
          ...configInfo,
          title: clipData.name || eventData.title || configInfo.title,
          thumbnail: pageThumbnail || configInfo.thumbnail,
          method: "event",
          live_status:
            clipData.live?.status === "done" ? "was_live" : "is_live",
        };
      }

      return null;
    } catch (error) {
      console.error("❌ Failed to extract video info from event page:", error);
      return null;
    }
  }

  async extractVideoInfoFromAPI(videoId, unlistedHash = null) {
    console.log(
      `🔍 Extracting video info from API for videoId: ${videoId} using web client`,
      unlistedHash ? `with unlisted hash: ${unlistedHash}` : ""
    );

    const videoPath = unlistedHash ? `${videoId}:${unlistedHash}` : videoId;
    const apiUrl = `https://api.vimeo.com/videos/${videoPath}`;

    const authToken = await this.getOAuthToken();
    const headers = {
      "User-Agent": this.CLIENT_CONFIG.USER_AGENT,
      ...this.CLIENT_HEADERS,
    };

    if (authToken) {
      headers.Authorization = authToken;
    }

    const queryParams = new URLSearchParams({
      fields: this.CLIENT_CONFIG.VIDEOS_FIELDS.join(","),
    });

    try {
      const response = await fetch(`${apiUrl}?${queryParams}`, { headers });
      if (!response.ok) {
        const errorText = await response.text();

        const isRateLimited =
          response.status === 429 ||
          errorText.includes("rate limit") ||
          errorText.includes("quota exceeded") ||
          errorText.includes("Too Many Requests") ||
          errorText.includes("try again");

        if (isRateLimited) {
          console.warn(
            `⚠️ Rate limit detected with web client - will rely on fallback approaches`
          );
        }

        let errorDetails = errorText;
        try {
          const errorJson = JSON.parse(errorText);
          if (errorJson.error) {
            errorDetails = errorJson.error;
          }

          if (errorJson.error_code === 5460) {
            throw new Error(
              "Authentication may be needed due to your location or video restrictions. If your IP address is located in Europe, you might need to use a VPN/proxy, or the video may require login."
            );
          }

          if (response.status === 404 && errorJson.error_code) {
            throw new Error(
              `Video not found or not accessible: ${errorDetails}`
            );
          }

          if (
            response.status === 400 &&
            errorJson.invalid_parameters?.some((p) => p.field === "password")
          ) {
            throw new Error(
              "This video is password protected. Password-protected video download is not currently supported by this extension."
            );
          }
        } catch (parseError) {
          // Use original text if JSON parsing fails
        }

        console.error(
          `❌ API request failed: ${response.status} ${response.statusText}`,
          errorText
        );
        throw new Error(
          `API request failed: ${response.status} ${response.statusText} - ${errorDetails}`
        );
      }

      const data = await response.json();
      console.log("✅ API response:", data);

      if (data.config_url) {
        const configInfo = await this.extractVideoInfoFromConfig(
          data.config_url
        );
        if (configInfo) {
          const progressive = configInfo.config?.request?.files?.progressive;
          if (progressive) {
            data.files = (data.files || []).concat(progressive);
          }

          const apiThumbnail = data.thumbnail_url;
          const configThumbnail = configInfo.thumbnail;
          const picturesThumbnail = this.getBestThumbnail(data.pictures);
          const finalThumbnail =
            apiThumbnail || configThumbnail || picturesThumbnail;

          return {
            ...configInfo,
            ...data,
            thumbnail: finalThumbnail,
            method: "config_from_api",
          };
        }
      }

      const bestThumbnail = this.getBestThumbnail(data.pictures);

      return {
        title: data.name || "Untitled Video",
        id: videoId,
        duration: data.duration,
        thumbnail: bestThumbnail,
        description: data.description,
        owner: data.user?.name,
        width: data.width,
        height: data.height,
        config_url: data.config_url,
        embed_player_config_url: data.embed_player_config_url,
        files: data.files,
        download: data.download,
        method: "api",
      };
    } catch (error) {
      console.error("❌ API request failed:", error);
      return null;
    }
  }

  async extractVideoInfoFromConfig(configUrl) {
    console.log("🔍 Extracting video info from config:", configUrl);

    try {
      const response = await fetch(configUrl);
      if (!response.ok) {
        throw new Error(
          `Config request failed: ${response.status} ${response.statusText}`
        );
      }

      const config = await response.json();
      console.log("✅ Config response:", config);

      const video = config.video || {};

      let files = [];
      const progressive = config.request?.files?.progressive;
      if (progressive && Array.isArray(progressive)) {
        files = progressive;
        console.log("✅ Found progressive files in config:", files.length);
      }

      let thumbnail =
        video.thumbnail_url ||
        video.thumbs?.base ||
        config.request?.thumb_preview?.url ||
        null;

      return {
        title: video.title || "Untitled Video",
        id: video.id,
        duration: video.duration,
        thumbnail: thumbnail,
        description: video.description,
        owner: video.owner?.name,
        width: video.width,
        height: video.height,
        files: files,
        config: config,
        method: "config",
      };
    } catch (error) {
      console.error("❌ Config request failed:", error);
      return null;
    }
  }

  async extractVideoInfoFromThirdPartyEmbed(embedInfo) {
    console.log("🔍 Extracting video info from third-party embed:", embedInfo);

    if (!embedInfo || !embedInfo.videoId) {
      return null;
    }

    try {
      console.log("🚀 Attempting to get full DOM from content script.");
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: () => document.documentElement.outerHTML,
      });

      if (results && results.length > 0) {
        for (const result of results) {
          if (result.result && result.result.includes("window.playerConfig")) {
            const html = result.result;
            console.log(
              `✅ Got DOM HTML from a frame, length: ${html.length}. Now parsing for config.`
            );

            try {
              chrome.runtime
                .sendMessage({ action: "saveDOM", domContent: html })
                .catch(() => {});
            } catch (error) {}

            const playerConfigMatch = html.match(
              /window\.playerConfig\s*=\s*({.*})/s
            );
            if (playerConfigMatch && playerConfigMatch[1]) {
              let configString = playerConfigMatch[1];
              let openBraces = 0;
              let endIndex = -1;

              for (let i = 0; i < configString.length; i++) {
                if (configString[i] === "{") {
                  openBraces++;
                } else if (configString[i] === "}") {
                  openBraces--;
                }

                if (openBraces === 0) {
                  endIndex = i;
                  break;
                }
              }

              if (endIndex !== -1) {
                configString = configString.substring(0, endIndex + 1);
              }

              try {
                const config = JSON.parse(configString);
                console.log(
                  "✅ Successfully extracted playerConfig from DOM:",
                  config
                );

                const video = config.video || {};

                let thumbnail =
                  video.thumbnail_url ||
                  video.thumbs?.base ||
                  config.request?.thumb_preview?.url ||
                  null;

                let thumbPreview = null;
                if (config.request?.thumb_preview) {
                  thumbPreview = {
                    url: config.request.thumb_preview.url,
                    height: config.request.thumb_preview.height,
                    width: config.request.thumb_preview.width,
                    frameHeight: config.request.thumb_preview.frame_height,
                    frameWidth: config.request.thumb_preview.frame_width,
                    columns: config.request.thumb_preview.columns,
                    frames: config.request.thumb_preview.frames,
                  };
                }

                return {
                  title: video.title || embedInfo.pageTitle || "Untitled Video",
                  id: String(video.id || embedInfo.videoId),
                  duration: video.duration,
                  thumbnail: thumbnail,
                  thumbPreview: thumbPreview,
                  description: video.description,
                  owner: video.owner?.name,
                  width: video.width,
                  height: video.height,
                  config: config,
                  method: "third_party_embed_dom_parse",
                  embedUrl: embedInfo.iframeSrc,
                  pageUrl: embedInfo.pageUrl,
                  referer: embedInfo.pageUrl,
                };
              } catch (e) {
                console.error("Error parsing playerConfig JSON", e);
              }
            }
          }
        }
        console.warn("⚠️ Could not find playerConfig in any of the frames.");
      } else {
        console.warn("⚠️ Could not get DOM from any frame.");
      }
    } catch (error) {
      console.error(
        "❌ Failed to execute script in frames or parse config:",
        error
      );
    }

    console.log(
      "🔍 Falling back to original extraction methods for third-party embed."
    );

    try {
      const pageUrl = new URL(embedInfo.pageUrl);
      let pageCookies = [];
      let vimeoCookies = [];

      try {
        pageCookies = await chrome.cookies.getAll({ domain: pageUrl.hostname });
      } catch (cookieError) {
        console.warn("⚠️ Could not get page cookies:", cookieError);
      }

      try {
        vimeoCookies = await chrome.cookies.getAll({ domain: ".vimeo.com" });
      } catch (cookieError) {
        console.warn("⚠️ Could not get Vimeo cookies:", cookieError);
      }

      const allCookies = [...vimeoCookies, ...pageCookies];
      const cookieHeader = allCookies
        .map((cookie) => `${cookie.name}=${encodeURIComponent(cookie.value)}`)
        .join("; ");

      const headers = {
        Referer: embedInfo.pageUrl,
        Origin: pageUrl.origin,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      };

      if (cookieHeader) {
        headers.Cookie = cookieHeader;
      }

      try {
        const configUrl = `https://player.vimeo.com/video/${embedInfo.videoId}/config`;
        const configResponse = await fetch(configUrl, {
          headers: {
            ...headers,
            "X-Requested-With": "XMLHttpRequest",
            Accept: "application/json",
          },
          credentials: "include",
        });

        if (configResponse.ok) {
          const config = await configResponse.json();
          const video = config.video || {};

          return {
            title: video.title || embedInfo.pageTitle || "Untitled Video",
            id: embedInfo.videoId,
            duration: video.duration,
            thumbnail: video.thumbs?.base,
            config: config,
            method: "third_party_embed",
            pageUrl: embedInfo.pageUrl,
            referer: embedInfo.pageUrl,
          };
        }
      } catch (configError) {
        console.warn("⚠️ Direct config URL failed:", configError);
      }

      const apiInfo = await this.extractVideoInfoFromAPI(embedInfo.videoId);
      if (apiInfo) {
        return {
          ...apiInfo,
          method: "third_party_embed_api_fallback",
          pageUrl: embedInfo.pageUrl,
          referer: embedInfo.pageUrl,
        };
      }

      throw new Error("All extraction methods failed for third-party embed.");
    } catch (error) {
      console.error("❌ Failed to extract video info from embed:", error);
      return null;
    }
  }

  async extractInfo(url) {
    console.log("🔍 extractVimeoInfo called with URL:", url);

    if (url.includes("/review/")) {
      const videoInfo = await this.extractVideoInfoFromReviewPage(url);
      if (videoInfo) {
        console.log(
          "✅ Video info extracted successfully from review page:",
          videoInfo
        );
        return {
          platform: "Vimeo",
          url: url,
          ...videoInfo,
        };
      }
    }

    if (url.includes("/ondemand/")) {
      const videoInfo = await this.extractVideoInfoFromOnDemandPage(url);
      if (videoInfo) {
        console.log(
          "✅ Video info extracted successfully from on-demand page:",
          videoInfo
        );
        return {
          platform: "Vimeo",
          url: url,
          ...videoInfo,
        };
      }
    }

    if (url.includes("/event/")) {
      const videoInfo = await this.extractVideoInfoFromEventPage(url);
      if (videoInfo) {
        console.log(
          "✅ Video info extracted successfully from event page:",
          videoInfo
        );
        return {
          platform: "Vimeo",
          url: url,
          ...videoInfo,
        };
      }
    }

    const vimeoPattern =
      /https?:\/\/(?:(?:www|player)\.)?vimeo\.com\/(?:(?:(?!(?:channels|album|showcase)\/[^/?#]+\/?(?:$|[?#])|[^/]+\/review\/|ondemand\/)(?:(?!event\/).*?\/)??(?:(?:play_redirect_hls|moogaloop\.swf)\?clip_id=)?(?:videos?\/)?)(\d+)(?:\/?([\da-f]{10}))?|(?:channels|groups)\/[^/?#]+\/videos\/(\d+)|album\/\d+\/video\/(\d+)|event\/(\d+)(?:\/videos\/(\d+))?)/;

    const match = url.match(vimeoPattern);
    let videoId = null;
    let unlistedHash = null;

    if (match) {
      videoId = match[1] || match[3] || match[4] || match[5] || match[6];
      unlistedHash = match[2];
      console.log("🔍 URL parsing results:", {
        videoId,
        unlistedHash,
        fullMatch: match[0],
      });
    }

    if (!videoId) {
      console.error("❌ Could not extract video ID from URL:", url);
      return null;
    }

    console.log("✅ Extracted video ID:", videoId);

    console.log("🔄 Trying web client API...");
    try {
      const videoInfo = await this.extractVideoInfoFromAPI(
        videoId,
        unlistedHash
      );
      if (videoInfo) {
        console.log(
          "✅ Video info extracted successfully with web client:",
          videoInfo
        );
        return {
          platform: "Vimeo",
          url: url,
          ...videoInfo,
        };
      } else {
        console.warn("⚠️ Web client returned null");
      }
    } catch (error) {
      console.warn("⚠️ Web client failed with error:", error);
    }

    console.error("❌ All extraction approaches failed");
    return null;
  }

  async downloadVideo(url, videoInfo = null, selectedQualityIndex = null) {
    console.log(`🎬 Starting VIMEO download for: ${url}`);

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      downloadCancelled: false,
      activeDownloads: globalState.activeDownloads + 1,
    });

    try {
      if (!videoInfo) {
        console.log("🔍 Extracting video info for download...");
        this.utils.sendProgressToPopup(
          5,
          "Extracting Vimeo video information..."
        );

        videoInfo = await this.extractInfo(url);
        if (!videoInfo) {
          throw new Error(
            "Could not extract video information for this Vimeo URL."
          );
        }
      }

      console.log("✅ Using video info for download:", videoInfo);
      console.log("📋 Selected quality index:", selectedQualityIndex);

      const fileName = this.utils.sanitizeFileName(videoInfo.title) + ".mp4";

      const downloadApproaches = [];

      if (
        videoInfo.method === "third_party_embed" ||
        videoInfo.method === "third_party_embed_api_fallback" ||
        videoInfo.method === "third_party_embed_dom_parse"
      ) {
        downloadApproaches.push(() =>
          this.downloadFromThirdPartyEmbed(videoInfo)
        );
        downloadApproaches.push(() =>
          this.downloadFromConfig(videoInfo, selectedQualityIndex)
        );
        downloadApproaches.push(() =>
          this.downloadFromAPI(videoInfo, selectedQualityIndex)
        );
      } else if (
        videoInfo.method === "review" ||
        videoInfo.method === "ondemand" ||
        videoInfo.method === "config"
      ) {
        downloadApproaches.push(() =>
          this.downloadFromConfig(videoInfo, selectedQualityIndex)
        );
        downloadApproaches.push(() =>
          this.downloadFromAPI(videoInfo, selectedQualityIndex)
        );
      } else {
        downloadApproaches.push(() =>
          this.downloadFromAPI(videoInfo, selectedQualityIndex)
        );
        downloadApproaches.push(() =>
          this.downloadFromConfig(videoInfo, selectedQualityIndex)
        );
      }

      if (videoInfo.url && videoInfo.method === "video_element") {
        downloadApproaches.push(() => this.downloadFromVideoElement(videoInfo));
      }

      for (const approach of downloadApproaches) {
        const globalState = this.utils.getGlobalState();
        if (globalState.downloadCancelled) {
          console.log("❌ Download cancelled - stopping fallback attempts");
          throw new Error("Download cancelled by user");
        }

        try {
          await approach();
          console.log(
            "✅ Vimeo processing completed successfully, Chrome download will follow!"
          );
          return;
        } catch (error) {
          if (
            error.message === "Download cancelled by user" ||
            error.name === "AbortError"
          ) {
            console.log("❌ Download cancelled - stopping fallback attempts");
            throw error;
          }
          console.warn("⚠️ Download approach failed, trying next:", error);
        }
      }

      throw new Error("All download approaches failed");
    } catch (error) {
      console.error("❌ Vimeo download failed:", error);
      this.utils.sendDownloadError(`Vimeo Download Failed: ${error.message}`);
      throw error;
    } finally {
      const globalState = this.utils.getGlobalState();
      if (globalState.activeDownloads > 0) {
        this.utils.setGlobalState({
          activeDownloads: globalState.activeDownloads - 1,
        });
      }
      if (globalState.downloadCancelled) {
        this.utils.setGlobalState({ downloadCancelled: false });
        console.log("🔄 Reset downloadCancelled flag after completion");
      }
      // Don't close offscreen here - let the Chrome download completion handle it
      console.log(
        `📊 Vimeo handler finished, activeDownloads: ${globalState.activeDownloads}, keeping offscreen open for Chrome download`
      );
    }
  }

  // Download from API response
  async downloadFromAPI(videoInfo, selectedQualityIndex = null) {
    console.log("📥 Attempting download from API data");

    // Prioritize files array with user-selected quality over download array
    if (videoInfo.files && videoInfo.files.length > 0) {
      let selectedFile = null;

      // Use selected quality if provided and valid
      if (
        selectedQualityIndex !== null &&
        selectedQualityIndex !== "" &&
        videoInfo.files[selectedQualityIndex] &&
        videoInfo.files[selectedQualityIndex].link
      ) {
        selectedFile = videoInfo.files[selectedQualityIndex];
        console.log(
          `🎯 Using user-selected quality: ${
            selectedFile.rendition || "Unknown"
          } (${selectedFile.width}x${selectedFile.height})`
        );
      } else {
        // Find the best quality file as fallback
        selectedFile = videoInfo.files.reduce((best, file) => {
          return (file.width || 0) > (best.width || 0) ? file : best;
        });
        console.log(
          `📊 Using best quality as fallback: ${
            selectedFile.rendition || "Unknown"
          } (${selectedFile.width}x${selectedFile.height})`
        );
      }

      if (selectedFile && selectedFile.link) {
        const fileName = this.utils.sanitizeFileName(videoInfo.title) + ".mp4";
        console.log(`🔽 Downloading from files URL: ${selectedFile.link}`);
        await this.utils.downloadFile(selectedFile.link, fileName);
        return;
      }
    }

    // Fallback to download array if files array didn't work
    if (videoInfo.download && videoInfo.download.length > 0) {
      const downloadUrl = videoInfo.download[0].link;
      const fileName = this.utils.sanitizeFileName(videoInfo.title) + ".mp4";
      console.log(`🔽 Fallback: Downloading from API URL: ${downloadUrl}`);
      await this.utils.downloadFile(downloadUrl, fileName);
      return;
    }

    throw new Error("No download URLs found in API response");
  }

  // Download from config URL
  async downloadFromConfig(videoInfo, selectedQualityIndex = null) {
    console.log("⚙️ Attempting download from config");

    let config = videoInfo.config;
    if (!config && videoInfo.config_url) {
      const configInfo = await this.extractVideoInfoFromConfig(
        videoInfo.config_url
      );
      if (configInfo) {
        config = configInfo.config;
      }
    }

    if (config) {
      // Look for progressive download URLs
      const progressive = config.request?.files?.progressive;
      if (progressive && progressive.length > 0) {
        let selectedQuality = null;

        // Try to match the selected quality with progressive files
        if (
          selectedQualityIndex !== null &&
          selectedQualityIndex !== "" &&
          videoInfo.files &&
          videoInfo.files[selectedQualityIndex]
        ) {
          const selectedFile = videoInfo.files[selectedQualityIndex];
          // Find progressive file that matches the selected quality
          selectedQuality = progressive.find(
            (file) =>
              file.width === selectedFile.width &&
              file.height === selectedFile.height
          );

          if (selectedQuality) {
            console.log(
              `🎯 Using user-selected progressive quality: ${selectedQuality.width}x${selectedQuality.height}`
            );
          }
        }

        // Fallback to best quality if no match found
        if (!selectedQuality) {
          selectedQuality = progressive.reduce((best, file) => {
            return (file.width || 0) > (best.width || 0) ? file : best;
          });
          console.log(
            `📊 Using best progressive quality as fallback: ${selectedQuality.width}x${selectedQuality.height}`
          );
        }

        if (selectedQuality.url) {
          const fileName =
            this.utils.sanitizeFileName(videoInfo.title) + ".mp4";
          console.log(
            `🔽 Downloading from config progressive: ${selectedQuality.url}`
          );
          await this.utils.downloadFile(selectedQuality.url, fileName);
          return;
        }
      }

      // Look for HLS streams
      const hls = config.request?.files?.hls;
      if (hls && hls.cdns) {
        let hlsUrl = Object.values(hls.cdns)[0]?.url;

        // Debug: Always log when we reach this point
        console.log(
          `DEBUG: About to check FORCE_FMP4_FORMAT: ${this.TESTING_CONFIG?.FORCE_FMP4_FORMAT}`
        );

        // Testing feature: Force FMP4 format for testing
        if (this.TESTING_CONFIG.FORCE_FMP4_FORMAT) {
          console.log(`TESTING: Original URL: ${hlsUrl}`);
          console.log(
            `TESTING: FORCE_FMP4_FORMAT is ${this.TESTING_CONFIG.FORCE_FMP4_FORMAT}`
          );

          const originalUrl = hlsUrl;
          hlsUrl = hlsUrl.replace(/([&?])sf=ts/g, "$1sf=fmp4");

          if (originalUrl !== hlsUrl) {
            console.log(`TESTING: Successfully replaced sf=ts with sf=fmp4`);
            console.log(`TESTING: Modified URL: ${hlsUrl}`);
          } else {
            console.log(`TESTING: No sf=ts found to replace in URL`);
            // Force add sf=fmp4 if sf=ts wasn't found
            if (hlsUrl.includes("?")) {
              hlsUrl += "&sf=fmp4";
            } else {
              hlsUrl += "?sf=fmp4";
            }
            console.log(`TESTING: Added sf=fmp4 to URL: ${hlsUrl}`);
          }
        }

        if (hlsUrl) {
          const fileName =
            this.utils.sanitizeFileName(videoInfo.title) + ".mp4";
          console.log(`🔽 Downloading from HLS: ${hlsUrl}`);

          console.log(
            `🔄 Audio stream detected in master manifest - using separate A/V download`
          );
          console.log(`TESTING MODE: FILE CHANGES ARE WORKING!`);
          await this.downloadHLSVideoWithSeparateAudio(
            hlsUrl,
            fileName,
            hls,
            videoInfo
          );
          return;
        }
      }
    }

    throw new Error("No download URLs found in config");
  }

  // Download from video element URL
  async downloadFromVideoElement(videoInfo) {
    console.log("🎥 Attempting download from video element");

    if (videoInfo.url && videoInfo.method === "video_element") {
      const fileName = this.utils.sanitizeFileName(videoInfo.title) + ".mp4";
      console.log(`🔽 Downloading from video element: ${videoInfo.url}`);
      await this.utils.downloadFile(videoInfo.url, fileName);
      return;
    }

    throw new Error("No video element URL available");
  }

  // Download from third-party embed
  async downloadFromThirdPartyEmbed(videoInfo) {
    console.log("🌐 Attempting download from third-party embed");

    if (videoInfo.config) {
      // Use config-based download with referer headers
      return this.downloadFromConfig(videoInfo);
    }

    throw new Error("No config available for third-party embed");
  }

  // Download HLS video with separate audio/video streams
  async downloadHLSVideoWithSeparateAudio(
    hlsUrl,
    fileName,
    hlsConfig,
    videoInfo = null
  ) {
    console.log(`🔽 Downloading HLS video with separate audio: ${hlsUrl}`);

    try {
      const response = await fetch(hlsUrl);
      if (!response.ok) {
        throw new Error(`Failed to fetch HLS manifest: ${response.status}`);
      }

      const manifestContent = await response.text();
      const manifest = this.parseM3U8(manifestContent);

      if (manifest.isMasterPlaylist && manifest.variants.length > 0) {
        // Find the best video quality variant
        const videoVariant = manifest.variants[0]; // Usually the best quality
        const videoVariantUrl = new URL(videoVariant.uri, hlsUrl).toString();

        // Get video segments
        const videoResponse = await fetch(videoVariantUrl);
        const videoContent = await videoResponse.text();
        const videoManifest = this.parseM3U8(videoContent);

        const videoSegments = videoManifest.segments.map((segment) => ({
          uri: new URL(segment.uri, videoVariantUrl).toString(),
          type: "video",
        }));

        // Add initialization segment for video if present
        if (videoManifest.initializationSegment) {
          const initSegmentUrl = new URL(
            videoManifest.initializationSegment,
            videoVariantUrl
          ).toString();
          console.log(
            "🔧 Adding video initialization segment:",
            initSegmentUrl
          );
          videoSegments.unshift({
            uri: initSegmentUrl,
            type: "video",
            isInitializationSegment: true,
          });
        }

        // Find audio stream - look for audio-only variant or separate audio URL
        let audioSegments = [];

        // Extract audio URL from EXT-X-MEDIA line with TYPE=AUDIO
        const masterLines = manifestContent.split("\n");
        let audioVariantUrl = null;

        console.log("🔍 DEBUG: Looking for TYPE=AUDIO in master manifest...");
        for (let i = 0; i < masterLines.length; i++) {
          const line = masterLines[i];
          if (line.includes("EXT-X-MEDIA") && line.includes("TYPE=AUDIO")) {
            console.log("🎵 DEBUG: Found EXT-X-MEDIA TYPE=AUDIO line:", line);
            // Extract URI from within the EXT-X-MEDIA line
            const uriMatch = line.match(/URI="([^"]+)"/);
            if (uriMatch && uriMatch[1]) {
              audioVariantUrl = new URL(uriMatch[1], hlsUrl).toString();
              console.log("🎵 DEBUG: Extracted audio URL:", audioVariantUrl);
              break;
            }
          }
        }

        // If no separate audio URL found, try using patterns
        if (!audioVariantUrl) {
          console.log(
            "🔍 Looking for audio segments in video manifest or trying audio-specific URL patterns"
          );

          // Try to construct audio URL from video URL pattern
          const audioPatterns = [
            // Replace av/primary with audio/primary in the base URL
            hlsUrl.replace("/av/primary/", "/audio/primary/"),
            // Replace av/ with audio/ in the path
            hlsUrl.replace("/av/", "/audio/"),
            // Try video variant URL with av replaced by audio
            videoVariantUrl.replace("/av/", "/audio/"),
            videoVariantUrl.replace("av/primary", "audio/primary"),
            // Also try replacing st=video with st=audio in query params
            videoVariantUrl.replace("st=video", "st=audio"),
            videoVariantUrl
              .replace("/video/", "/audio/")
              .replace("st=video", "st=audio"),
          ];

          for (const audioPattern of audioPatterns) {
            try {
              console.log(`🔍 Trying audio URL pattern: ${audioPattern}`);
              const audioTestResponse = await fetch(audioPattern);
              if (audioTestResponse.ok) {
                const testContent = await audioTestResponse.text();
                // Verify this is actually an audio manifest by checking it's different from video
                if (
                  testContent.includes("#EXTM3U") &&
                  testContent !== videoContent
                ) {
                  audioVariantUrl = audioPattern;
                  console.log(`✅ Found audio stream at: ${audioVariantUrl}`);
                  break;
                }
              }
            } catch (e) {
              // Continue to next pattern
            }
          }
        }

        if (audioVariantUrl) {
          console.log(`🎵 Found separate audio stream: ${audioVariantUrl}`);
          const audioResponse = await fetch(audioVariantUrl);
          const audioContent = await audioResponse.text();
          const audioManifest = this.parseM3U8(audioContent);

          audioSegments = audioManifest.segments.map((segment) => ({
            uri: new URL(segment.uri, audioVariantUrl).toString(),
            type: "audio",
          }));

          // Add initialization segment for audio if present
          if (audioManifest.initializationSegment) {
            const initSegmentUrl = new URL(
              audioManifest.initializationSegment,
              audioVariantUrl
            ).toString();
            console.log(
              "🔧 Adding audio initialization segment:",
              initSegmentUrl
            );
            audioSegments.unshift({
              uri: initSegmentUrl,
              type: "audio",
              isInitializationSegment: true,
            });
          }

          console.log(`🎵 Audio segments found: ${audioSegments.length}`);
        } else {
          console.warn(
            "⚠️ Could not find separate audio stream, downloading video-only"
          );
          audioSegments = [];
        }

        // Combine video and audio segments for download
        const allSegments = [...videoSegments, ...audioSegments];
        console.log(
          `📦 Total segments to download: ${allSegments.length} (${videoSegments.length} video, ${audioSegments.length} audio)`
        );

        if (audioSegments.length > 0) {
          // Download both audio and video segments, then merge with ffmpeg
          console.log(
            "🎵 Found audio segments, downloading both streams for ffmpeg merge"
          );
          await this.downloadHLSSeparateAVSegments(
            allSegments,
            fileName,
            videoSegments.length,
            audioSegments.length,
            videoInfo,
            hlsUrl
          );
        } else {
          // Fallback to video-only
          console.log("⚠️ No audio segments found, downloading video-only");
          await this.downloadHLSSegments(videoSegments, fileName);
        }

        return;
      }

      // Fallback to regular HLS download if not a master playlist
      await this.downloadHLSVideo(hlsUrl, fileName);
    } catch (error) {
      console.error("❌ HLS separate AV download failed:", error);
      console.log("❌ Download failed. Not attempting any fallback or retry.");
      throw error;
    }
  }

  // Parse M3U8 manifest
  parseM3U8(content) {
    console.log("🔍 Parsing M3U8 content:", content.substring(0, 200) + "...");

    const lines = content
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line);

    const result = {
      isMasterPlaylist: false,
      variants: [],
      segments: [],
      audioTracks: [],
      initializationSegment: null,
    };

    if (content.includes("#EXT-X-STREAM-INF")) {
      result.isMasterPlaylist = true;
      console.log("📋 Detected master playlist");

      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith("#EXT-X-MEDIA:TYPE=AUDIO")) {
          const line = lines[i];
          const uriMatch = line.match(/URI="([^"]+)"/);
          if (uriMatch) {
            result.audioTracks.push({ uri: uriMatch[1] });
            console.log("🎵 Found audio track:", uriMatch[1]);
          }
        }
      }

      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith("#EXT-X-STREAM-INF")) {
          const nextLine = lines[i + 1];
          if (nextLine && !nextLine.startsWith("#")) {
            result.variants.push({ uri: nextLine });
          }
        }
      }
    } else {
      console.log("📋 Detected media playlist");
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith("#EXT-X-MAP:URI=")) {
          const mapMatch = lines[i].match(/URI="([^"]+)"/);
          if (mapMatch) {
            result.initializationSegment = mapMatch[1];
            console.log(
              "🔧 Found initialization segment:",
              result.initializationSegment
            );
          }
        } else if (lines[i].startsWith("#EXTINF")) {
          const nextLine = lines[i + 1];
          if (nextLine && !nextLine.startsWith("#")) {
            result.segments.push({ uri: nextLine });
          }
        }
      }
    }

    console.log("✅ Parsed M3U8:", {
      isMasterPlaylist: result.isMasterPlaylist,
      variantCount: result.variants.length,
      segmentCount: result.segments.length,
      audioTrackCount: result.audioTracks.length,
      hasInitializationSegment: !!result.initializationSegment,
    });

    return result;
  }

  // Download HLS video
  async downloadHLSVideo(hlsUrl, fileName) {
    console.log(`🔽 Downloading HLS video: ${hlsUrl}`);

    try {
      const response = await fetch(hlsUrl);
      if (!response.ok) {
        throw new Error(`Failed to fetch HLS manifest: ${response.status}`);
      }

      const manifestContent = await response.text();
      const manifest = this.parseM3U8(manifestContent);

      if (manifest.isMasterPlaylist && manifest.variants.length > 0) {
        // Get the first variant (usually best quality)
        const variantUrl = new URL(manifest.variants[0].uri, hlsUrl).toString();
        const variantResponse = await fetch(variantUrl);
        const variantContent = await variantResponse.text();
        const variantManifest = this.parseM3U8(variantContent);

        if (variantManifest.segments.length > 0) {
          const absoluteSegments = variantManifest.segments.map((segment) => ({
            uri: new URL(segment.uri, variantUrl).toString(),
          }));

          // Add initialization segment if present
          if (variantManifest.initializationSegment) {
            const initSegmentUrl = new URL(
              variantManifest.initializationSegment,
              variantUrl
            ).toString();
            console.log("🔧 Adding initialization segment:", initSegmentUrl);
            absoluteSegments.unshift({
              uri: initSegmentUrl,
              isInitializationSegment: true,
            });
          }

          await this.downloadHLSSegments(absoluteSegments, fileName);
          return;
        }
      }

      if (manifest.segments.length > 0) {
        const absoluteSegments = manifest.segments.map((segment) => ({
          uri: new URL(segment.uri, hlsUrl).toString(),
        }));

        await this.downloadHLSSegments(absoluteSegments, fileName);
        return;
      }

      throw new Error("No playable segments found in HLS manifest");
    } catch (error) {
      console.error("❌ HLS download failed:", error);
      throw error;
    }
  }

  // Download HLS segments (reusing Loom implementation)
  async downloadHLSSegments(segments, fileName) {
    console.log(`🔽 Downloading ${segments.length} HLS segments`);

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      activeDownloads: globalState.activeDownloads + 1,
    });
    console.log(`📊 Active downloads: ${globalState.activeDownloads + 1}`);

    // Create a unique ID for this HLS download to track it
    const hlsDownloadId = `hls_${Date.now()}_${Math.random()
      .toString(36)
      .substr(2, 9)}`;
    this.utils.addActiveDownloadId(hlsDownloadId);
    console.log(`📦 HLS download ID: ${hlsDownloadId}`);

    this.utils.sendProgressToPopup(30, "Downloading video segments...");

    // Check for cancellation
    if (this.utils.getGlobalState().downloadCancelled) {
      console.log("❌ Download cancelled during HLS segment preparation");
      const globalState = this.utils.getGlobalState();
      this.utils.setGlobalState({
        activeDownloads: globalState.activeDownloads - 1,
      });
      throw new Error("Download cancelled");
    }

    try {
      console.log(
        "📦 HLS video detected - downloading segments directly to offscreen document for processing"
      );

      this.utils.sendProgressToPopup(
        0,
        `Starting to download ${segments.length} video segments...`
      );

      this.utils.sendProgressToPopup(5, "Preparing segment processor...");
      await this.utils.createOffscreenDocument();

      const BATCH_SIZE = 10;
      const MAX_CONCURRENT_BATCHES = 1;
      const BATCH_DELAY_MS = 1;

      const requestId = this.utils.uuidv4();
      const segmentsKey = `segments_${requestId}`;

      const abortController = new AbortController();

      this.utils.sendProgressToPopup(10, "Starting segment downloads...");

      const batches = [];
      for (let i = 0; i < segments.length; i += BATCH_SIZE) {
        batches.push({
          startIndex: i,
          segments: segments.slice(i, i + BATCH_SIZE),
        });
      }

      console.log(
        `📦 Processing ${batches.length} batches of ~${BATCH_SIZE} segments each with ${MAX_CONCURRENT_BATCHES} concurrent batches (${BATCH_DELAY_MS}ms delay between batches)`
      );

      let completedSegments = 0;
      const progressLock = { current: 0 };

      const processBatch = async (batch) => {
        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        const { startIndex, segments: batchSegments } = batch;

        const segmentPromises = batchSegments.map(async (segment, index) => {
          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          const segmentNumber = startIndex + index;

          const downloadSegmentWithRetry = async () => {
            const maxRetries = 5;
            const baseRetryDelay = 1000;
            const startTime = Date.now();
            const maxDuration = 60000;

            for (let attempt = 1; attempt <= maxRetries; attempt++) {
              if (Date.now() - startTime > maxDuration) {
                throw new Error(
                  `Segment ${
                    segmentNumber + 1
                  } download timed out after 60 seconds`
                );
              }

              if (this.utils.getGlobalState().downloadCancelled) {
                console.log("🚫 Aborting all segment downloads");
                abortController.abort();
                throw new Error("Download cancelled by user");
              }

              try {
                const response = await fetch(segment.uri, {
                  signal: abortController.signal,
                });

                if (this.utils.getGlobalState().downloadCancelled) {
                  console.log("🚫 Aborting all segment downloads");
                  abortController.abort();
                  throw new Error("Download cancelled by user");
                }

                if (!response.ok) {
                  throw new Error(`HTTP ${response.status}`);
                }

                return response;
              } catch (error) {
                console.log(
                  `⚠️ Segment ${
                    segmentNumber + 1
                  } download attempt ${attempt}/${maxRetries} failed:`,
                  error.message
                );

                if (
                  this.utils.getGlobalState().downloadCancelled ||
                  error.message === "Download cancelled by user" ||
                  (error.name === "AbortError" &&
                    abortController.signal.aborted)
                ) {
                  console.log("🚫 User cancelled download - not retrying");
                  throw error;
                }

                if (Date.now() - startTime > maxDuration) {
                  throw new Error(
                    `Segment ${
                      segmentNumber + 1
                    } download timed out after 60 seconds`
                  );
                }

                if (attempt === maxRetries) {
                  throw new Error(
                    `Segment ${
                      segmentNumber + 1
                    } download failed after ${maxRetries} attempts: ${
                      error.message
                    }`
                  );
                }

                let waitTime = baseRetryDelay * Math.pow(2, attempt - 1);

                if (
                  error.message.includes("429") ||
                  error.message.includes("Too Many Requests")
                ) {
                  waitTime = Math.min(15000, waitTime);
                  console.log(
                    `⏱️ Rate limit detected, waiting ${waitTime}ms before retry...`
                  );
                } else if (
                  error.name === "AbortError" ||
                  error.message.includes("network") ||
                  error.message.includes("timeout") ||
                  error.message.includes("connection")
                ) {
                  const jitter = Math.random() * 0.3;
                  waitTime = Math.min(10000, waitTime * (1 + jitter));
                  console.log(
                    `🔄 Network error detected, waiting ${Math.round(
                      waitTime
                    )}ms before retry...`
                  );
                } else {
                  waitTime = Math.min(8000, waitTime);
                  console.log(`⏳ Retrying in ${waitTime}ms...`);
                }

                await new Promise((resolve) => setTimeout(resolve, waitTime));
              }
            }
          };

          const response = await downloadSegmentWithRetry();

          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          return {
            key: `${segmentsKey}_${segmentNumber}`,
            data: await response.arrayBuffer(),
          };
        });

        const batchData = await Promise.all(segmentPromises);

        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        await Promise.all(
          batchData.map((item) => this.utils.set(item.key, item.data))
        );

        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        completedSegments += batchSegments.length;
        const progressPercent = (completedSegments / segments.length) * 85;
        const currentBatch = Math.ceil(completedSegments / BATCH_SIZE);
        const totalBatches = batches.length;

        progressLock.current = progressPercent;
        this.utils.sendProgressToPopup(
          progressPercent,
          `Downloaded batch ${currentBatch}/${totalBatches} - ${completedSegments}/${segments.length} segments`
        );

        console.log(
          `✅ Batch ${currentBatch}/${totalBatches} completed: ${batchSegments.length} segments (${completedSegments}/${segments.length} total)`
        );
      };

      let batchIndex = 0;
      const processNextBatch = async () => {
        while (
          batchIndex < batches.length &&
          !this.utils.getGlobalState().downloadCancelled
        ) {
          const currentBatchIndex = batchIndex++;
          if (currentBatchIndex >= batches.length) break;

          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("❌ Download cancelled by user");
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          console.log(
            `🔄 Processing batch ${currentBatchIndex + 1}/${batches.length}...`
          );
          await processBatch(batches[currentBatchIndex]);

          if (
            currentBatchIndex < batches.length - 1 &&
            !this.utils.getGlobalState().downloadCancelled
          ) {
            console.log(`⏳ Waiting ${BATCH_DELAY_MS}ms before next batch...`);
            await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY_MS));
          }
        }
      };

      const concurrentProcessors = Array.from(
        { length: MAX_CONCURRENT_BATCHES },
        () => processNextBatch()
      );
      await Promise.all(concurrentProcessors);

      console.log(
        `✅ All ${segments.length} segments downloaded and stored in IndexedDB`
      );

      if (this.utils.getGlobalState().downloadCancelled) {
        console.log("❌ Download cancelled before merging phase");
        throw new Error("Download cancelled by user");
      }

      this.utils.sendProgressToPopup(88, "Merging video segments...");

      const response = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          chrome.runtime.onMessage.removeListener(responseListener);
          clearInterval(cancelCheck);
          reject(new Error("Offscreen processing timeout"));
        }, 300000);

        const cancelCheck = setInterval(() => {
          if (this.utils.getGlobalState().downloadCancelled) {
            clearTimeout(timeout);
            clearInterval(cancelCheck);
            chrome.runtime.onMessage.removeListener(responseListener);
            reject(new Error("Download cancelled by user"));
          }
        }, 500);

        const responseListener = (message) => {
          if (
            message.type === "MERGE_SEGMENTS_RESPONSE" &&
            message.requestId === requestId
          ) {
            clearTimeout(timeout);
            clearInterval(cancelCheck);
            chrome.runtime.onMessage.removeListener(responseListener);
            if (message.success) {
              resolve(message);
            } else {
              reject(
                new Error(
                  message.error?.message || "Offscreen processing failed"
                )
              );
            }
          }
        };

        chrome.runtime.onMessage.addListener(responseListener);

        chrome.runtime.sendMessage({
          type: "MERGE_SEGMENTS_FASTSTREAM",
          requestId,
          segmentsKey,
          fileName,
          totalSegments: segments.length,
          sourceUrl: hlsUrl, // Add source URL for format detection
        });
      });

      if (response && response.success) {
        console.log("✅ Offscreen processing completed");
        const { downloadInitiated, results } = response;

        if (!downloadInitiated) {
          console.error("❌ Download was not initiated by offscreen document");
          throw new Error("Download failed to initiate");
        }

        console.log("✅ Download initiated by background script");

        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} completed successfully, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
        this.utils.sendDownloadComplete(
          `HLS video download completed: ${fileName}`
        );
      } else {
        throw new Error("Offscreen processing failed");
      }

      console.log(`✅ Merged HLS download completed: ${fileName}`);
    } catch (error) {
      console.error("❌ HLS segment download failed:", error);

      if (
        error.message === "Download cancelled by user" ||
        error.name === "AbortError"
      ) {
        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} cancelled, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
        console.log(
          "🔄 Keeping downloadCancelled flag true to prevent fallback approaches"
        );
        this.utils.sendDownloadError("Download cancelled by user");
      } else {
        this.utils.sendDownloadError(`HLS download failed: ${error.message}`);
      }

      throw error;
    } finally {
      if (
        this.utils.getGlobalState().activeDownloadIds.has &&
        this.utils.getGlobalState().activeDownloadIds.has(hlsDownloadId)
      ) {
        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} cleanup in finally, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
      }
    }
  }

  // Download HLS segments with separate audio/video handling
  async downloadHLSSeparateAVSegments(
    segments,
    fileName,
    videoCount,
    audioCount,
    videoInfo = null,
    hlsUrl = null
  ) {
    console.log(
      `🔽 Downloading ${segments.length} HLS segments (${videoCount} video, ${audioCount} audio)`
    );

    const globalState = this.utils.getGlobalState();
    this.utils.setGlobalState({
      activeDownloads: globalState.activeDownloads + 1,
    });
    console.log(`📊 Active downloads: ${globalState.activeDownloads + 1}`);

    // Create a unique ID for this HLS download to track it
    const hlsDownloadId = `hls_${Date.now()}_${Math.random()
      .toString(36)
      .substr(2, 9)}`;
    this.utils.addActiveDownloadId(hlsDownloadId);
    console.log(`📦 HLS download ID: ${hlsDownloadId}`);

    try {
      console.log(
        "📦 HLS video with separate A/V detected - downloading segments directly to offscreen document for ffmpeg processing"
      );

      // Send progress update IMMEDIATELY to show user feedback
      this.utils.sendProgressToPopup(
        0,
        `Starting to download ${segments.length} video+audio segments...`
      );

      // Create offscreen document (won't block UI anymore)
      this.utils.sendProgressToPopup(5, "Preparing FFmpeg processor...");
      await this.utils.createOffscreenDocument();

      // Download and store segments with optimized batches for rate limit handling
      const BATCH_SIZE = 10; // Larger batches to reduce total number of batches
      const MAX_CONCURRENT_BATCHES = 1; // Reduced concurrency to avoid rate limits
      const BATCH_DELAY_MS = 1; // 1 second delay between batch completions

      const requestId = this.utils.uuidv4();
      const segmentsKey = `segments_${requestId}`;

      // Create AbortController to cancel all ongoing fetch operations
      const abortController = new AbortController();

      this.utils.sendProgressToPopup(10, "Starting segment downloads...");

      // Create all batches upfront
      const batches = [];
      for (let i = 0; i < segments.length; i += BATCH_SIZE) {
        batches.push({
          startIndex: i,
          segments: segments.slice(i, i + BATCH_SIZE),
        });
      }

      console.log(
        `📦 Processing ${batches.length} batches of ~${BATCH_SIZE} segments each with ${MAX_CONCURRENT_BATCHES} concurrent batches (${BATCH_DELAY_MS}ms delay between batches)`
      );

      let completedSegments = 0;
      const progressLock = { current: 0 };

      // Process a single batch
      const processBatch = async (batch) => {
        // Check for cancellation before processing each batch
        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        const { startIndex, segments: batchSegments } = batch;

        // Download all segments in this batch concurrently
        const segmentPromises = batchSegments.map(async (segment, index) => {
          // Check for cancellation before starting each segment download
          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          const segmentNumber = startIndex + index;

          // Retry logic for segment download with 60 second timeout
          const downloadSegmentWithRetry = async () => {
            const maxRetries = 5; // Increased retries for better reliability
            const baseRetryDelay = 1000; // Start with 1 second
            const startTime = Date.now();
            const maxDuration = 60000; // Increased to 60 seconds

            for (let attempt = 1; attempt <= maxRetries; attempt++) {
              // Check timeout before each attempt
              if (Date.now() - startTime > maxDuration) {
                throw new Error(
                  `Segment ${
                    segmentNumber + 1
                  } download timed out after 60 seconds`
                );
              }

              // Check for cancellation before each attempt
              if (this.utils.getGlobalState().downloadCancelled) {
                console.log("🚫 Aborting all segment downloads");
                abortController.abort();
                throw new Error("Download cancelled by user");
              }

              try {
                const response = await fetch(segment.uri, {
                  signal: abortController.signal,
                });

                // Check for cancellation after fetch but before processing response
                if (this.utils.getGlobalState().downloadCancelled) {
                  console.log("🚫 Aborting all segment downloads");
                  abortController.abort();
                  throw new Error("Download cancelled by user");
                }

                if (!response.ok) {
                  throw new Error(`HTTP ${response.status}`);
                }

                return response;
              } catch (error) {
                console.log(
                  `⚠️ Segment ${
                    segmentNumber + 1
                  } (A/V) download attempt ${attempt}/${maxRetries} failed:`,
                  error.message
                );

                // Check if this is user cancellation - don't retry these
                if (
                  this.utils.getGlobalState().downloadCancelled ||
                  error.message === "Download cancelled by user" ||
                  (error.name === "AbortError" &&
                    abortController.signal.aborted)
                ) {
                  console.log("🚫 User cancelled download - not retrying");
                  throw error;
                }

                // Don't retry if we've exceeded the 60 second timeout
                if (Date.now() - startTime > maxDuration) {
                  throw new Error(
                    `Segment ${
                      segmentNumber + 1
                    } download timed out after 60 seconds`
                  );
                }

                // If this was the last attempt, throw the error
                if (attempt === maxRetries) {
                  throw new Error(
                    `Segment ${
                      segmentNumber + 1
                    } download failed after ${maxRetries} attempts: ${
                      error.message
                    }`
                  );
                }

                // Calculate exponential backoff with jitter
                let waitTime = baseRetryDelay * Math.pow(2, attempt - 1);

                // Special handling for specific error types
                if (
                  error.message.includes("429") ||
                  error.message.includes("Too Many Requests")
                ) {
                  waitTime = Math.min(15000, waitTime); // Cap at 15s for rate limits
                  console.log(
                    `⏱️ Rate limit detected, waiting ${waitTime}ms before retry...`
                  );
                } else if (
                  error.name === "AbortError" ||
                  error.message.includes("network") ||
                  error.message.includes("timeout") ||
                  error.message.includes("connection")
                ) {
                  // Network issues - use exponential backoff with jitter
                  const jitter = Math.random() * 0.3; // 0-30% jitter
                  waitTime = Math.min(10000, waitTime * (1 + jitter)); // Cap at 10s
                  console.log(
                    `🔄 Network error detected, waiting ${Math.round(
                      waitTime
                    )}ms before retry...`
                  );
                } else {
                  // Other errors - use standard exponential backoff
                  waitTime = Math.min(8000, waitTime); // Cap at 8s for other errors
                  console.log(`⏳ Retrying in ${waitTime}ms...`);
                }

                // Wait before retrying
                await new Promise((resolve) => setTimeout(resolve, waitTime));
              }
            }
          };

          const response = await downloadSegmentWithRetry();

          // Check for cancellation before converting to arrayBuffer
          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          return {
            key: `${segmentsKey}_${segmentNumber}`,
            data: await response.arrayBuffer(),
            type: segment.type, // Store whether this is video or audio
          };
        });

        const batchData = await Promise.all(segmentPromises);

        // Check for cancellation after batch download completes
        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        // Store all segments in this batch concurrently
        await Promise.all(
          batchData.map((item) => this.utils.set(item.key, item.data))
        );

        // Final cancellation check after storing data
        if (this.utils.getGlobalState().downloadCancelled) {
          console.log("🚫 Aborting all segment downloads");
          abortController.abort();
          throw new Error("Download cancelled by user");
        }

        // Update progress atomically
        completedSegments += batchSegments.length;
        const progressPercent = (completedSegments / segments.length) * 85; // 85% for download, 15% for merging
        const currentBatch = Math.ceil(completedSegments / BATCH_SIZE);
        const totalBatches = batches.length;

        // Update progress after each batch completion
        progressLock.current = progressPercent;
        this.utils.sendProgressToPopup(
          progressPercent,
          `Downloaded batch ${currentBatch}/${totalBatches} - ${completedSegments}/${segments.length} segments (video+audio)`
        );

        console.log(
          `✅ Batch ${currentBatch}/${totalBatches} completed: ${batchSegments.length} segments (${completedSegments}/${segments.length} total)`
        );
      };

      // Process batches with controlled concurrency using semaphore pattern
      let batchIndex = 0;
      const processNextBatch = async () => {
        while (
          batchIndex < batches.length &&
          !this.utils.getGlobalState().downloadCancelled
        ) {
          const currentBatchIndex = batchIndex++;
          if (currentBatchIndex >= batches.length) break;

          // Check for cancellation before processing each batch
          if (this.utils.getGlobalState().downloadCancelled) {
            console.log("❌ Download cancelled by user");
            console.log("🚫 Aborting all segment downloads");
            abortController.abort();
            throw new Error("Download cancelled by user");
          }

          console.log(
            `🔄 Processing batch ${currentBatchIndex + 1}/${batches.length}...`
          );
          await processBatch(batches[currentBatchIndex]);

          // Add delay between batch completions to help with rate limiting
          if (
            currentBatchIndex < batches.length - 1 &&
            !this.utils.getGlobalState().downloadCancelled
          ) {
            console.log(`⏳ Waiting ${BATCH_DELAY_MS}ms before next batch...`);
            await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY_MS));
          }
        }
      };

      // Start concurrent batch processing
      const concurrentProcessors = Array.from(
        { length: MAX_CONCURRENT_BATCHES },
        () => processNextBatch()
      );
      await Promise.all(concurrentProcessors);

      console.log(
        `✅ All ${segments.length} segments downloaded and stored in IndexedDB`
      );

      // Check for cancellation before starting merge phase
      if (this.utils.getGlobalState().downloadCancelled) {
        console.log("❌ Download cancelled before merging phase");
        throw new Error("Download cancelled by user");
      }

      this.utils.sendProgressToPopup(88, "Merging video and audio segments...");

      // Create a promise that will be resolved when we receive the response
      const response = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          chrome.runtime.onMessage.removeListener(responseListener);
          clearInterval(cancelCheck);
          reject(new Error("Offscreen processing timeout"));
        }, 300000); // 5 minutes

        // Periodically check for cancellation during merge
        const cancelCheck = setInterval(() => {
          if (this.utils.getGlobalState().downloadCancelled) {
            clearTimeout(timeout);
            clearInterval(cancelCheck);
            chrome.runtime.onMessage.removeListener(responseListener);
            reject(new Error("Download cancelled by user"));
          }
        }, 500); // Check every 500ms

        // Set up listener for response
        const responseListener = (message) => {
          if (
            message.type === "MERGE_SEPARATE_AV_RESPONSE" &&
            message.requestId === requestId
          ) {
            clearTimeout(timeout);
            clearInterval(cancelCheck);
            chrome.runtime.onMessage.removeListener(responseListener);
            if (message.success) {
              resolve(message);
            } else {
              reject(
                new Error(
                  message.error?.message || "Offscreen processing failed"
                )
              );
            }
          }
        };

        chrome.runtime.onMessage.addListener(responseListener);

        // Send message without callback to avoid the error
        const mergeMessage = {
          type: "MERGE_SEPARATE_AV_FASTSTREAM",
          requestId,
          segmentsKey,
          fileName,
          totalSegments: segments.length,
          videoCount,
          audioCount,
          totalDuration: videoInfo?.duration,
          videoInfo: videoInfo,
          sourceUrl: hlsUrl, // Add source URL for format detection
        };

        console.log(
          `🔍 DEBUG: Sending merge message to offscreen:`,
          mergeMessage
        );

        try {
          chrome.runtime.sendMessage(mergeMessage).catch(() => {
            // Silently ignore if message channel is closed
          });
        } catch (error) {
          // Silently ignore if runtime context is invalid
        }
      });

      if (response && response.success) {
        console.log("✅ Offscreen processing completed");
        const { downloadInitiated, results } = response;

        if (!downloadInitiated) {
          console.error("❌ Download was not initiated by offscreen document");
          throw new Error("Download failed to initiate");
        }

        // Download will be handled by DOWNLOAD_PROCESSED_FILE message from offscreen

        console.log("✅ Download initiated by background script");

        // Successfully completed - clean up tracking but keep activeDownloads for Chrome download
        this.utils.deleteActiveDownloadId(hlsDownloadId);
        console.log(
          `📊 HLS download ${hlsDownloadId} completed successfully, Chrome download will handle activeDownloads decrement`
        );
        // Don't send download complete here - let the actual Chrome download completion handle it
        console.log(
          `📥 HLS processing completed, awaiting Chrome download completion for: ${fileName}`
        );
      } else {
        throw new Error("Offscreen processing failed");
      }

      console.log(`✅ Merged HLS download completed: ${fileName}`);
    } catch (error) {
      console.error("❌ HLS segment download failed:", error);

      if (
        error.message === "Download cancelled by user" ||
        error.name === "AbortError"
      ) {
        // Clean up tracking for cancelled HLS download
        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} cancelled, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
        console.log(
          "🔄 Keeping downloadCancelled flag true to prevent fallback approaches"
        );
        this.utils.sendDownloadError("Download cancelled by user");
      } else {
        this.utils.sendDownloadError(`HLS download failed: ${error.message}`);
      }

      throw error;
    } finally {
      // Clean up HLS download tracking (in case it wasn't cleaned up in success path)
      if (
        this.utils.getGlobalState().activeDownloadIds.has &&
        this.utils.getGlobalState().activeDownloadIds.has(hlsDownloadId)
      ) {
        this.utils.deleteActiveDownloadId(hlsDownloadId);
        const globalState = this.utils.getGlobalState();
        this.utils.setGlobalState({
          activeDownloads: Math.max(0, globalState.activeDownloads - 1),
        });
        console.log(
          `📊 HLS download ${hlsDownloadId} cleanup in finally, active downloads: ${
            globalState.activeDownloads - 1
          }`
        );
      }
    }
  }

  getVideoInfo(request, sender, sendResponse) {
    this.extractInfo(request.url)
      .then((videoInfo) => {
        if (videoInfo) {
          if (sendResponse) {
            sendResponse({
              success: true,
              videoInfo: videoInfo,
            });
          }
        } else {
          if (sendResponse) {
            sendResponse({
              success: false,
              error:
                "Could not extract video information. Please make sure this is a valid Vimeo video URL. If you recently made multiple requests, you may have hit the rate limit - wait 15 minutes and try again. Try login out and downloading if the video doesn't require you to be logged in.",
            });
          }
        }
      })
      .catch((error) => {
        console.error("❌ Error in getVideoInfo:", error);
        if (
          error.message.includes("429") ||
          error.message.includes("Too Many Requests")
        ) {
          if (sendResponse) {
            sendResponse({
              success: false,
              error:
                "⏱️ Vimeo API rate limit exceeded. The extension automatically tried fallback methods, but all failed. Please try again later or consider using a proxy/VPN.",
            });
          }
        } else {
          if (sendResponse) {
            sendResponse({ success: false, error: error.message });
          }
        }
      });
  }

  

  async findEmbed(request, sender, sendResponse) {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      if (!tab) {
        console.error("No active tab found");
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No active tab found",
          });
        }
        return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          console.log("🔍 Searching for Vimeo embeds in page...");

          const findVimeoEmbed = () => {
            let iframe = document.querySelector(
              'iframe[src*="player.vimeo.com"]'
            );
            if (iframe) {
              console.log("✅ Found standard Vimeo iframe:", iframe.src);
              return {
                type: "iframe",
                src: iframe.src,
                element: iframe,
              };
            }

            iframe = document.querySelector('iframe[src*="vimeo.com"]');
            if (iframe) {
              console.log("✅ Found Vimeo iframe:", iframe.src);
              return {
                type: "iframe",
                src: iframe.src,
                element: iframe,
              };
            }

            if (
              window.playerConfig &&
              window.playerConfig.video &&
              window.playerConfig.video.id
            ) {
              console.log(
                "✅ Found window.playerConfig:",
                window.playerConfig.video.id
              );
              return {
                type: "playerConfig",
                src: window.location.href,
                element: null,
                playerConfig: window.playerConfig,
              };
            }

            const vimeoElements = document.querySelectorAll(
              '[data-vimeo-id], [data-video-id*="vimeo"], .vimeo-player'
            );
            for (const element of vimeoElements) {
              const vimeoId =
                element.dataset.vimeoId || element.dataset.videoId;
              if (vimeoId) {
                console.log("✅ Found Vimeo data attribute:", vimeoId);
                return {
                  type: "data-attribute",
                  src: window.location.href,
                  element: element,
                  vimeoId: vimeoId,
                };
              }
            }

            console.log("❌ No Vimeo embeds found");
            return null;
          };

          const embedInfo = findVimeoEmbed();

          if (embedInfo) {
            let videoId = null;
            let iframeSrc = embedInfo.src;

            if (embedInfo.type === "iframe" && embedInfo.src) {
              const videoIdMatch = embedInfo.src.match(/video\/(\d+)/);
              videoId = videoIdMatch ? videoIdMatch[1] : null;
            } else if (
              embedInfo.type === "playerConfig" &&
              embedInfo.playerConfig
            ) {
              videoId = String(embedInfo.playerConfig.video.id);
            } else if (
              embedInfo.type === "data-attribute" &&
              embedInfo.vimeoId
            ) {
              videoId = embedInfo.vimeoId.replace(/\D/g, "");
            }

            return {
              iframeSrc: iframeSrc,
              videoId: videoId,
              pageUrl: window.location.href,
              pageTitle: document.title,
              embedType: embedInfo.type,
            };
          }

          return null;
        },
      });

      if (results && results[0] && results[0].result) {
        console.log("✅ Found Vimeo embed:", results[0].result);
        const embedInfo = results[0].result;
        const videoInfo = await this.extractVideoInfoFromThirdPartyEmbed(
          embedInfo
        );
        if (sendResponse) {
          sendResponse({
            success: true,
            embedInfo: embedInfo,
            videoInfo: videoInfo,
          });
        }
      } else {
        console.log("❌ No Vimeo embed found on page after retry");
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No Vimeo embed found on this page.",
          });
        }
      }
    } catch (error) {
      console.error("❌ Error in findVimeoEmbed:", error);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  extractVideoInfo(request, sender, sendResponse) {
    // For non-Vimeo URLs, return error
    if (!request.url.includes("vimeo.com")) {
      if (sendResponse) {
        sendResponse({
          success: false,
          error: "Not a Vimeo URL",
        });
      }
      return;
    }

    this.extractInfo(request.url)
      .then((videoInfo) => {
        if (videoInfo) {
          if (sendResponse) {
            sendResponse({
              success: true,
              videoInfo: videoInfo,
            });
          }
        } else {
          if (sendResponse) {
            sendResponse({
              success: false,
              error: "Could not extract Vimeo video information.",
            });
          }
        }
      })
      .catch((error) => {
        console.error("❌ Error in extractVideoInfo:", error);
        if (sendResponse) {
          sendResponse({ success: false, error: error.message });
        }
      });
  }
}
