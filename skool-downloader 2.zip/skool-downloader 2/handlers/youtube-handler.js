// =================================================================================
// YOUTUBE HANDLER
// =================================================================================

export class YouTubeHandler {
  constructor(utils) {
    this.utils = utils;
  }

  extractYouTubeId(url) {
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
      /m\.youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
      /youtube-nocookie\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        return match[1];
      }
    }
    return null;
  }

  async downloadVideo(url, videoInfo = null) {
    console.log(`🎯 YouTube video detected: ${url}`);

    try {
      const videoId = this.extractYouTubeId(url);
      if (!videoId) {
        throw new Error("Could not extract YouTube video ID from URL");
      }

      let title = "YouTube Video";
      let thumbnail = `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;

      if (videoInfo && videoInfo.title) {
        title = videoInfo.title;
      }
      if (videoInfo && videoInfo.thumbnail) {
        thumbnail = videoInfo.thumbnail;
      }

      this.utils.sendProgressToPopup(20, "Processing YouTube video info...");

      try {
        const oembedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`;
        const response = await fetch(oembedUrl);

        if (response.ok) {
          const data = await response.json();
          title = data.title || title;
          console.log(`✅ Got YouTube title from oEmbed: ${title}`);
        }
      } catch (error) {
        console.log("⚠️ YouTube oEmbed failed, using fallback title");
      }

      this.utils.sendProgressToPopup(
        50,
        "YouTube video information extracted..."
      );

      const message = `YouTube Video Detected:\n\nTitle: ${title}\n\nYouTube videos are displayed for reference only. This extension does not download YouTube videos.\n\nTo access the video, use the original YouTube URL:\n${url}`;

      this.utils.sendProgressToPopup(80, "Preparing YouTube video info...");

      setTimeout(() => {
        this.utils.sendProgressToPopup(100, "YouTube video info ready");
        this.utils.sendDownloadComplete(message);

        chrome.notifications.create({
          type: "basic",
          iconUrl: "/icons/icon48.png",
          title: "YouTube Video Detected",
          message: `"${title}" - Use the original YouTube URL to access this video.`,
        });
      }, 500);

      console.log(`✅ YouTube video info provided for: ${title}`);
    } catch (error) {
      console.error("❌ YouTube info extraction failed:", error);
      this.utils.sendDownloadError(
        `Failed to extract YouTube video info: ${error.message}`
      );
      throw error;
    }
  }

  async findEmbed(request, sender, sendResponse) {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      if (!tab) {
        console.error("No active tab found");
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No active tab found",
          });
        }
        return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          console.log("🔍 Searching for YouTube embeds in page...");

          const extractYouTubeId = (url) => {
            const patterns = [
              /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
              /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
              /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
              /m\.youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
              /youtube-nocookie\.com\/embed\/([a-zA-Z0-9_-]{11})/,
            ];

            for (const pattern of patterns) {
              const match = url.match(pattern);
              if (match) {
                return match[1];
              }
            }
            return null;
          };

          // Look for YouTube iframes
          const iframe = document.querySelector(
            'iframe[src*="youtube.com/embed"], iframe[src*="youtube-nocookie.com/embed"], iframe[src*="youtu.be"]'
          );
          if (iframe && iframe.src) {
            const videoId = extractYouTubeId(iframe.src);
            if (videoId) {
              console.log("✅ Found YouTube iframe embed:", videoId);
              return {
                type: "iframe",
                src: iframe.src,
                videoId: videoId,
                id: videoId,
                title:
                  iframe.title ||
                  iframe.getAttribute("aria-label") ||
                  `YouTube Video ${videoId}`,
                url: `https://www.youtube.com/watch?v=${videoId}`,
                iframeSrc: iframe.src,
                element: iframe,
                platform: "YouTube",
                source: "iframe_embed",
                pageUrl: window.location.href,
                pageTitle: document.title,
              };
            }
          }

          // Look for YouTube links
          const youtubeLink = document.querySelector(
            'a[href*="youtube.com/watch"], a[href*="youtu.be/"]'
          );
          if (youtubeLink && youtubeLink.href) {
            const videoId = extractYouTubeId(youtubeLink.href);
            if (videoId) {
              console.log("✅ Found YouTube link:", videoId);
              return {
                type: "link",
                src: youtubeLink.href,
                videoId: videoId,
                id: videoId,
                title:
                  youtubeLink.textContent.trim() ||
                  youtubeLink.getAttribute("aria-label") ||
                  `YouTube Video ${videoId}`,
                url: youtubeLink.href,
                element: youtubeLink,
                platform: "YouTube",
                source: "link",
                pageUrl: window.location.href,
                pageTitle: document.title,
              };
            }
          }

          // Check if we're on a YouTube page directly
          if (window.location.href.includes("youtube.com/watch")) {
            const videoId = extractYouTubeId(window.location.href);
            if (videoId) {
              console.log("✅ Found YouTube page:", videoId);
              return {
                type: "page",
                src: window.location.href,
                videoId: videoId,
                id: videoId,
                title:
                  document.title.replace(" - YouTube", "") ||
                  `YouTube Video ${videoId}`,
                url: window.location.href,
                platform: "YouTube",
                source: "direct_page",
                pageUrl: window.location.href,
                pageTitle: document.title,
              };
            }
          }

          console.log("❌ No YouTube embeds found");
          return null;
        },
      });

      if (results && results[0] && results[0].result) {
        const embedInfo = results[0].result;
        console.log("✅ Found YouTube embed:", embedInfo);

        try {
          const videoId = embedInfo.videoId || embedInfo.id;
          const oembedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`;
          const response = await fetch(oembedUrl);

          let videoInfo = {
            id: videoId,
            title: embedInfo.title || `YouTube Video ${videoId}`,
            thumbnail: `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${videoId}`,
            platform: "youtube",
            isYouTubeVideo: true,
            files: [],
            message:
              "YouTube videos are displayed for reference only. Use the original YouTube URL to access the video.",
          };

          if (response.ok) {
            const data = await response.json();
            videoInfo = {
              ...videoInfo,
              title: data.title || videoInfo.title,
              author: data.author_name || "Unknown Channel",
              width: data.width,
              height: data.height,
            };
          }

          if (sendResponse) {
            sendResponse({
              success: true,
              embedInfo: embedInfo,
              videoInfo: videoInfo,
            });
          }
        } catch (error) {
          console.error("❌ Error extracting YouTube video info:", error);
          if (sendResponse) {
            sendResponse({
              success: false,
              error: "Could not extract YouTube video information.",
            });
          }
        }
      } else {
        if (sendResponse) {
          sendResponse({
            success: false,
            error: "No YouTube embed found on this page.",
          });
        }
      }
    } catch (error) {
      console.error("❌ Error in findYouTubeEmbed:", error);
      if (sendResponse) {
        sendResponse({ success: false, error: error.message });
      }
    }
  }

  extractVideoInfo(request, sender, sendResponse) {

    const videoId = this.extractYouTubeId(request.url);
    if (!videoId) {
      if (sendResponse) {
        sendResponse({
          success: false,
          error: "Could not extract YouTube video ID from URL.",
        });
      }
      return;
    }

    console.log("✅ Extracted YouTube video ID:", videoId);

    // Get YouTube video info from oEmbed API
    fetch(
      `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
    )
      .then((response) => response.json())
      .then((data) => {
        const videoInfo = {
          id: videoId,
          title: data.title || `YouTube Video ${videoId}`,
          thumbnail: `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`,
          author: data.author_name || "Unknown Channel",
          url: `https://www.youtube.com/watch?v=${videoId}`,
          platform: "youtube",
          isYouTubeVideo: true,
          files: [],
          message:
            "YouTube videos are displayed for reference only. Use the original YouTube URL to access the video.",
        };

        if (sendResponse) {
          sendResponse({
            success: true,
            videoInfo: videoInfo,
          });
        }
      })
      .catch((error) => {
        console.error("❌ YouTube oEmbed API error:", error);
        // Fallback with basic info
        const videoInfo = {
          id: videoId,
          title: `YouTube Video ${videoId}`,
          thumbnail: `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`,
          url: `https://www.youtube.com/watch?v=${videoId}`,
          platform: "youtube",
          isYouTubeVideo: true,
          files: [],
          message:
            "YouTube videos are displayed for reference only. Use the original YouTube URL to access the video.",
        };

        if (sendResponse) {
          sendResponse({
            success: true,
            videoInfo: videoInfo,
          });
        }
      });
  }
}
